#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════════════════════════
# ONE COMMAND BEFORE ANY BUILD SHIPS — 29bd.
#
# ⚠⚠⚠ WHY THIS EXISTS: 29bb and 29bc shipped `injuries is not defined` on the HOME PAGE — every signed-in
#   user got "Something hiccuped". plan29ba would have caught it (falsified: 4 FAIL on the broken build)
#   and it was never run: I ran the node suites, saw them green, and packaged. A checklist you can do
#   half of gets done half. This runs ALL of it, in order, and stops at the first red.
#
#   bash verify.sh        from /home/claude/work
# ═══════════════════════════════════════════════════════════════════════════════════════════════════
set -e
cd "$(dirname "$0")"
W=web/fdc-web
step () { echo; echo "━━ $1"; }

step "1/6 build gates (icons, css, screens, hooks, GLOBALS) + both bundles"
( cd $W && npm run build:test 2>&1 | grep -E "✓|✖|error|Error" | grep -v "^  ✓ src/" )

step "2/6 model unit checks (injuries, form)"
( cd $W && node src/injuries.js --test | tail -1 && node src/form.js --test | tail -1 )

step "3/6 node library build (App.jsx importable by node)"
( cd $W && npx vite build -c vite.lib.config.js >/dev/null 2>&1 && echo "  lib built" )
ln -sfn ../web/fdc-web/node_modules probe/node_modules
ln -sfn ../web/fdc-web/node_modules hubstub/node_modules
( node hubstub/gen-hub-fixture.mjs | tail -1 )   # the league-hub fixture is generated from the app's own board

step "4/6 node suites against the real scorer"
( cd probe && node plan29bb-cascade.mjs | tail -1 && node plan29bb-team.mjs | tail -1 && node plan29be-form.mjs | tail -1 && node plan29bf-grade.mjs | tail -1 && node plan29bh-dst.mjs | tail -1 )

step "5/6 backend"
( cd api/fdc-backend && out=$(npm test 2>&1); p=$(echo "$out" | grep -cE '^  PASS' || true); f=$(echo "$out" | grep -ciE '^  FAIL' || true); echo "  $p PASS / $f FAIL"; [ "$f" = 0 ] )

step "6/6 browser suites (rig + plan29ba + plan29be hub + plan29bf trade/home + plan29bg ideas + plan29bh + plan29bi + plan29bj + plan29bk + plan29bl + plan29bm) — ⚠ the step that was skipped in 29bb/29bc"
bash rig.sh | tail -1
node plan29ba.mjs | tail -1 | tee /tmp/verify-browser.log
grep -q " 0 FAIL" /tmp/verify-browser.log
node plan29be.mjs | tail -1 | tee /tmp/verify-hub.log
grep -q " 0 FAIL" /tmp/verify-hub.log
node plan29bf.mjs | tail -1 | tee /tmp/verify-trade.log          # 29bf — calculator prediction = outcome
grep -q " 0 FAIL" /tmp/verify-trade.log
node plan29bf-home.mjs | tail -1 | tee /tmp/verify-home.log      # 29bf — home page loading states
grep -q " 0 FAIL" /tmp/verify-home.log
node plan29bg.mjs | tail -1 | tee /tmp/verify-ideas.log         # 29bg — a grade on every trade idea
grep -q " 0 FAIL" /tmp/verify-ideas.log
node plan29bh.mjs | tail -1 | tee /tmp/verify-bh.log            # 29bh — no K/DEF, Ideas, trade grades, picks
grep -q " 0 FAIL" /tmp/verify-bh.log
node plan29bi.mjs | tail -1 | tee /tmp/verify-bi.log            # 29bi — ideas quality, position ideas, outlook hover, Game Day popup
grep -q " 0 FAIL" /tmp/verify-bi.log
node plan29bj.mjs | tail -1 | tee /tmp/verify-bj.log            # 29bj — Yahoo greyed until approved
grep -q " 0 FAIL" /tmp/verify-bj.log
node plan29bk.mjs | tail -1 | tee /tmp/verify-bk.log            # 29bk — gold rows, redraft picks, Rosters card
grep -q " 0 FAIL" /tmp/verify-bk.log
node plan29bl.mjs | tail -1 | tee /tmp/verify-bl.log            # 29bl — the waiver wire in the calculator
grep -q " 0 FAIL" /tmp/verify-bl.log
node plan29bm.mjs | tail -1 | tee /tmp/verify-bm.log            # 29bm — records, QB holes, activity grades, projected Game Day, review hovers
grep -q " 0 FAIL" /tmp/verify-bm.log

echo; echo "━━ ALL GREEN — safe to package. Then check the zip's top folder is fdc-web/ (see fdc-delivery)."
