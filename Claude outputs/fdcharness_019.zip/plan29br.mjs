/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   TREY'S 29br NOTES — plan29br (setup copied from plan29bq)
     §1 "The loading mechanism stopped on the 'this week' section... It's also taking 10-15 seconds to load."
     §2 "I also want to change 'my week' to 'my teams'"
     §3 "I also want to think about 'fairness' of a deal as a secondary consideration... I want to see that it
        makes sense for both teams, both teams improve, AND they might not do it because the value in a
        vacuum might not make sense."
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29bq header follows)
   TREY'S 29bq NOTES — plan29bq (setup copied from plan29bp)
     "I think the Mevis problem still exists. He isn't listed as a replacement despite the following facts:
      Mevis 6.7 / 6.92 / 6.92, Spencer Shrader 7.12 / 7.32 / 7.32, Tyler Loop 7.04 / 6.72 / 6.72, Harrison
      Butker 6.93 / 6.32 / BYE (but he is also the K3 in the league and put up 7 and 16 in the first 2)."
     §1 a kicker who is ahead in EVERY week, by a fraction each time, is a recommendation
     §2 the row says what the case is (the three-week gain), and a kicker who is only ahead this week is not
        promoted over him
     §3 the card carries what each man has ACTUALLY scored per game this season
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29bp header follows)
   TREY'S 29bp NOTES — plan29bp (setup copied from plan29bo)
     §1 "On the 'starter out' ones, I also want to see alternatives on there."
     §2 "Harrison Mevis is my kicker in a league and in the last update it was recommending an upgrade... after
        this update, nothing is coming up for that league" — a starter with NO projection
     §3 "I see a lot of defense and kicker recommendations, but not a ton of position players... I do want to
        ultimately compare against the starting lineup, but we should also compare against the bench too."
     §4 "For the review, you can just combine the head to head and median if it's a median league."
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29bo header follows)
   TREY'S 29bo NOTES — plan29bo (setup copied from plan29bn)
     §1 the "Pos upgrade" hover: my own player in the list, highlighted, and the next three weeks beside this
        one — "I see +7 for DST, but I don't see my defense in there to compare them... it might also be
        helpful to see the next 3 weeks... particularly important for defenses for matchups"
     §2 the Review tab: my season record per league and across every league, "the macro view mixed with the
        weekly view"
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29bn header follows)
   TREY'S 29bn NOTES — plan29bn (setup copied from plan29bm; the 29bm header below is kept for the helpers)
     §1 home This week: a Power column, record and power coloured by how I'm doing
     §2 the projected hover: a total under each team, the benches, arrows for who should move
     §3 Matchup: "start Bucky Irving (RB) for Harrison Mevis (K)" — an RB goes into the empty RB slot
     §4 calculator: a free-agent QB better than the QB I'm trading for still shows as "pick him up instead"
     §5 My Week free agents: a kicker outscored on waivers, one row + alternatives on hover; the player you'd
        start over AND the one you'd release
     §6 Review: hover vs median / vs field for every team's score, highest first, with the median line
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29bm header follows)
   TREY'S 29bm NOTES — plan29bm
     §1 Home "This week": "it isn't showing my record for each league", "my combined record through every
        league", "what do the red, yellow, and green dots... mean", "when you hover the projected score, I'd
        like to see a side by side of each team and the projected score".
     §2 Matchup: a starter traded away last week still in the lineup (Sleeper seeds the new week from the
        old one) must not show.
     §3 Hub free agents: "Higgins is on my IR... We should just ignore IR players for FA purposes."
     §4 My Week free agents: "I just lost... my 2 QBs... At a very minimum, that league should be
        recommending I pick up a QB."
     §5 My Week league activity: "show the trade grades next to each trade", the same letter the hub gives.
     §6 Game Day: "0-0-10... change these numbers to reflect the projections (and make it clear...)".
     §7 Review: hover the verdict chip for why; hover the result for both lineups side by side.
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import { chromium } from 'playwright';
import fs from 'node:fs';
const APP = 'http://localhost:4174/', STUB = 'http://localhost:5055';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { console.log(`  ${c ? 'PASS' : 'FAIL'}  ${n}${x !== '' ? `   [${x}]` : ''}`); c ? pass++ : fail++; };
const post = (p, b) => fetch(STUB + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b || {}) }).then((r) => r.json()).catch(() => null);
const CFG = { teams: 12, rounds: 15, slot: 1, type: 'redraft', sf: false, tePremMult: 0, order: 'snake',
  start: { QB: 1, RB: 2, WR: 2, TE: 1, FLEX: 1, SUPER: 0, K: 1, DST: 1 }, scoring: { rec: 1 }, caps: {}, keepers: [] };
const lg = (id, name, lid) => { const c = { platform: 'sleeper', leagueId: lid, username: 'trey', ownerUsername: 'trey' };
  return { id, name, created: 'x', cfg: { ...CFG, name, connect: c }, picks: [], preds: [], mocks: [], connect: c, sleeperLeagueId: lid }; };
const fsx = fs;
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const errs = [];
const open = async (leagues, route, vp = { width: 1450, height: 1100 }) => {
  const page = await (await b.newContext({ viewport: vp })).newPage();
  page.on('pageerror', (e) => errs.push(String(e)));
  await page.goto(APP, { waitUntil: 'domcontentloaded' });
  await page.evaluate(([l, r]) => { localStorage.clear(); localStorage.setItem('fdc:token', 't'); localStorage.setItem('fdcTourSeen', '1');
    localStorage.setItem('fdc:gs-state', JSON.stringify({ user: { email: 'trey.rose@pirates.com', paid: true, admin: true, rankSets: [], sleeperUsername: 'trey', sleeperUserId: 's1', homeView: 'season' }, leagues: l, funMocks: [] }));
    sessionStorage.setItem('gs-nav', JSON.stringify(r)); }, [leagues, route]);
  await page.reload({ waitUntil: 'domcontentloaded' });
  return page;
};
/* My Week / Game Day / Review are not restored from the session, so walk in through the home menu. */
const inSeason = async (page, tab) => {
  await page.waitForSelector('button.menuitem', { state: 'attached', timeout: 30000 }); await page.waitForTimeout(800);
  await page.evaluate(() => {
    const btn = Array.from(document.querySelectorAll('button.menuitem')).find((e) => /my (week|teams)/i.test((e.innerText || '').trim()))
      || Array.from(document.querySelectorAll('button')).find((e) => /^\s*My (week|teams)\s*$/i.test(e.innerText || ''));
    if (btn) btn.click();
  });
  await page.waitForSelector('[data-inseasontabs]', { timeout: 30000 });
  if (tab) { await page.click(`button[data-inseasontab="${tab}"]`); }
  await page.waitForTimeout(1500);
};
const cardText = (page) => page.$eval('[data-wkcard]', (x) => x.innerText).catch(() => '');
const LK = lg('HK', 'Blank Kicker League', 'hub-lg-nk');
const LM = lg('HM', 'Kicker Margins League', 'hub-lg-mev');
const L1 = lg('H1', 'Hub Fixture League', 'hub-lg-1'), L2 = lg('H2', 'Superflex 3WR League', 'hub-lg-2'), LQ = lg('HQ', 'QB Crisis League', 'hub-lg-qb');


const PACK = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-pack.json', import.meta.url), 'utf8'));
const HUB = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-hub.json', import.meta.url), 'utf8'));



const HUBF = JSON.parse(fsx.readFileSync(new URL('./hubstub/fixture-hub.json', import.meta.url), 'utf8'));
const PACKF = JSON.parse(fsx.readFileSync(new URL('./hubstub/fixture-pack.json', import.meta.url), 'utf8'));
const STDF = JSON.parse(fsx.readFileSync(new URL('./hubstub/fixture-std.json', import.meta.url), 'utf8'));

/* ══ §1 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §1 the look-ahead table has a loading state ==');
await post('/stub/reset'); await post('/stub/live', { mode: 'pregame' }); await post('/stub/latency', { ms: 2500 });
{
  const page = await open([L1, L2], { route: 'home' });
  await page.waitForSelector('[data-homeloading="week"]', { timeout: 30000 });
  const sk = await page.$eval('[data-homeloading="week"]', (x) => ({ t: x.innerText.replace(/\s+/g, ' '), busy: x.getAttribute('aria-busy') }));
  ok('1 · ⭐⭐⭐⭐⭐ the week-ahead view shows the shimmering skeleton while it reads, not one line of grey text',
    /Loading this week across your 2 leagues/i.test(sk.t) && sk.busy === 'true', sk.t.slice(0, 90));
  await page.waitForSelector('[data-homeaheadrow]', { timeout: 40000 });
  ok('1a · and it gives way to the table when the leagues land', !(await page.$('[data-homeloading="week"]')));
  await page.context().close();
}
await post('/stub/latency', { ms: 0 });

/* ══ §2 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §2 "My Week" is "My Teams" ==');
await post('/stub/reset');
{
  const page = await open([L1], { route: 'home' });
  await page.waitForSelector('button.menuitem', { state: 'attached', timeout: 30000 }); await page.waitForTimeout(800);
  const menu = await page.$$eval('button.menuitem', (xs) => xs.map((x) => x.innerText.replace(/\s+/g, ' ').trim()));
  ok('2 · ⭐⭐⭐⭐⭐ the home door says My Teams', menu.some((m) => /^My Teams/.test(m)) && !menu.some((m) => /^My Week/.test(m)), menu.filter((m) => /team|week/i.test(m)).join(' | '));
  await inSeason(page);
  const tabs = await page.$$eval('[data-inseasontab]', (xs) => xs.map((x) => x.innerText.replace(/\s+/g, ' ').trim()).filter(Boolean));
  ok('2a · ⭐⭐⭐⭐ and so does the tab on the screen it opens', tabs.some((t) => /My Teams/i.test(t)) && !tabs.some((t) => /My Week/i.test(t)), tabs.join(' | '));
  await page.context().close();
}

/* ══ §3 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §3 the fairness check: both teams improve, and the market may still disagree ==');
await post('/stub/reset'); await post('/stub/std', { mode: 'on' });
{
  const byId = new Map(PACKF.players.map((p) => [p.id, p]));
  const me = HUBF.teams.find((t) => t.rosterId === HUBF.myRosterId);
  const cold = me.players.map((id) => byId.get(id)).find((p) => p && p.name === STDF._cold);
  const t2 = HUBF.teams.find((t) => t.rosterId === 2);
  const hotThem = t2.players.map((id) => byId.get(id)).find((p) => p && p.name === STDF._hotThem);
  ok('3 · (fixture) I am sending a man who has been under his projection for one who has been over it',
    !!cold && !!hotThem, `${cold && cold.name} (cold) for ${hotThem && hotThem.name} (hot)`);
  const page = await open([L1], { route: 'teamHub', activeId: null, hubLeagueId: 'hub-lg-1' });
  await page.waitForSelector('[data-hubnav]', { timeout: 30000 }); await page.waitForTimeout(2500);
  await page.click('[data-hubgroup="moves"]'); await page.click('[data-hubtabbtn="trades"]'); await page.click('[data-tsectab="calc"]'); await page.waitForTimeout(500);
  await (await page.$('select[data-tbside-select="b"]')).selectOption({ label: t2.teamName }); await page.waitForTimeout(600);
  await page.click(`[data-tbcol="give"] [data-tbplayer="${cold.name}"]`);
  await page.click(`[data-tbcol="get"] [data-tbplayer="${hotThem.name}"]`);
  await page.waitForTimeout(1500);
  const F = await page.evaluate(() => { const el = document.querySelector('[data-tbfair]'); if (!el) return null;
    const tr = el.querySelector('[data-tbfairtrend]');
    return { key: el.getAttribute('data-tbfair'), both: el.getAttribute('data-tbfairboth'),
      trend: Number((tr && tr.getAttribute('data-tbfairtrend')) || 0), t: el.innerText.replace(/\s+/g, ' ') }; });
  ok('3a · ⭐⭐⭐⭐⭐ a fairness block sits under the trade, separate from the grade', !!F, F ? F.t.slice(0, 120) : 'no block');
  ok('3b · ⭐⭐⭐⭐⭐ it says what each lineup gains AND what the value in a vacuum looks like', !!F && /Your lineup/i.test(F.t) && /Their lineup/i.test(F.t) && /Value in a vacuum/i.test(F.t), F ? F.t.slice(0, 200) : '');
  ok('3c · ⭐⭐⭐⭐⭐ and it names who has been playing above or below his projection', !!F && F.trend >= 1 && /a game against a/.test(F.t),
    F ? (F.t.split(' a game against a ')[0] || '').slice(-60) : '');
  ok('3d · ⭐⭐⭐⭐ the man coming to me is the one trending up', !!F && new RegExp(`${hotThem.name}[^.]*coming to you`).test(F.t), F ? F.t.slice(0, 220) : '');
  ok('3e · ⭐⭐⭐⭐ the verdict sentence covers both halves: who improves, and what the value says', !!F && /(Both lineups get better|lineup gets better)/.test(F.t) && /(value|fair)/i.test(F.t), F ? (F.t.split('. ').slice(-2).join('. ') || '').slice(0, 160) : '');
  await page.context().close();
}

ok('4 · nothing threw', errs.length === 0, errs.slice(0, 2).join(' || ').slice(0, 200));
await b.close();
console.log(`\n  ${pass} PASS  ${fail} FAIL`);
process.exit(fail ? 1 : 0);
