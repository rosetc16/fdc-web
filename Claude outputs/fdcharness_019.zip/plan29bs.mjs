/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   TREY'S 29bs NOTES — plan29bs (setup copied from plan29br)
     "I'm not sure how you're determining what's 'fair' (especially re-draft vs. dynasty), but I did want to
      note it shouldn't just be overall projection. It should be some combination of positional scarcity,
      VBD, the opposite team need, upside / trend, rest of season projection, team role (i.e. did they
      recently take over the starting job?)... I think too often trade calculators are reactive to either
      pre-season projections OR they haven't caught up with recent hype/trends/upside."
     §1 every term of the price is on screen, and the base is REST OF SEASON over a replacement starter
     §2 a man who just took the job is priced above his preseason projection (the role term)
     §3 form moves the price, and a dynasty league prices the future as well as this season
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29br header follows)
   TREY'S 29br NOTES — plan29br (setup copied from plan29bq)
     §1 "The loading mechanism stopped on the 'this week' section... It's also taking 10-15 seconds to load."
     §2 "I also want to change 'my week' to 'my teams'"
     §3 "I also want to think about 'fairness' of a deal as a secondary consideration... I want to see that it
        makes sense for both teams, both teams improve, AND they might not do it because the value in a
        vacuum might not make sense."
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29bq header follows)
   TREY'S 29bq NOTES — plan29bq (setup copied from plan29bp)
     "I think the Mevis problem still exists. He isn't listed as a replacement despite the following facts:
      Mevis 6.7 / 6.92 / 6.92, Spencer Shrader 7.12 / 7.32 / 7.32, Tyler Loop 7.04 / 6.72 / 6.72, Harrison
      Butker 6.93 / 6.32 / BYE (but he is also the K3 in the league and put up 7 and 16 in the first 2)."
     §1 a kicker who is ahead in EVERY week, by a fraction each time, is a recommendation
     §2 the row says what the case is (the three-week gain), and a kicker who is only ahead this week is not
        promoted over him
     §3 the card carries what each man has ACTUALLY scored per game this season
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29bp header follows)
   TREY'S 29bp NOTES — plan29bp (setup copied from plan29bo)
     §1 "On the 'starter out' ones, I also want to see alternatives on there."
     §2 "Harrison Mevis is my kicker in a league and in the last update it was recommending an upgrade... after
        this update, nothing is coming up for that league" — a starter with NO projection
     §3 "I see a lot of defense and kicker recommendations, but not a ton of position players... I do want to
        ultimately compare against the starting lineup, but we should also compare against the bench too."
     §4 "For the review, you can just combine the head to head and median if it's a median league."
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29bo header follows)
   TREY'S 29bo NOTES — plan29bo (setup copied from plan29bn)
     §1 the "Pos upgrade" hover: my own player in the list, highlighted, and the next three weeks beside this
        one — "I see +7 for DST, but I don't see my defense in there to compare them... it might also be
        helpful to see the next 3 weeks... particularly important for defenses for matchups"
     §2 the Review tab: my season record per league and across every league, "the macro view mixed with the
        weekly view"
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29bn header follows)
   TREY'S 29bn NOTES — plan29bn (setup copied from plan29bm; the 29bm header below is kept for the helpers)
     §1 home This week: a Power column, record and power coloured by how I'm doing
     §2 the projected hover: a total under each team, the benches, arrows for who should move
     §3 Matchup: "start Bucky Irving (RB) for Harrison Mevis (K)" — an RB goes into the empty RB slot
     §4 calculator: a free-agent QB better than the QB I'm trading for still shows as "pick him up instead"
     §5 My Week free agents: a kicker outscored on waivers, one row + alternatives on hover; the player you'd
        start over AND the one you'd release
     §6 Review: hover vs median / vs field for every team's score, highest first, with the median line
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29bm header follows)
   TREY'S 29bm NOTES — plan29bm
     §1 Home "This week": "it isn't showing my record for each league", "my combined record through every
        league", "what do the red, yellow, and green dots... mean", "when you hover the projected score, I'd
        like to see a side by side of each team and the projected score".
     §2 Matchup: a starter traded away last week still in the lineup (Sleeper seeds the new week from the
        old one) must not show.
     §3 Hub free agents: "Higgins is on my IR... We should just ignore IR players for FA purposes."
     §4 My Week free agents: "I just lost... my 2 QBs... At a very minimum, that league should be
        recommending I pick up a QB."
     §5 My Week league activity: "show the trade grades next to each trade", the same letter the hub gives.
     §6 Game Day: "0-0-10... change these numbers to reflect the projections (and make it clear...)".
     §7 Review: hover the verdict chip for why; hover the result for both lineups side by side.
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import { chromium } from 'playwright';
import fs from 'node:fs';
const APP = 'http://localhost:4174/', STUB = 'http://localhost:5055';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { console.log(`  ${c ? 'PASS' : 'FAIL'}  ${n}${x !== '' ? `   [${x}]` : ''}`); c ? pass++ : fail++; };
const post = (p, b) => fetch(STUB + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b || {}) }).then((r) => r.json()).catch(() => null);
const CFG = { teams: 12, rounds: 15, slot: 1, type: 'redraft', sf: false, tePremMult: 0, order: 'snake',
  start: { QB: 1, RB: 2, WR: 2, TE: 1, FLEX: 1, SUPER: 0, K: 1, DST: 1 }, scoring: { rec: 1 }, caps: {}, keepers: [] };
const lg = (id, name, lid) => { const c = { platform: 'sleeper', leagueId: lid, username: 'trey', ownerUsername: 'trey' };
  return { id, name, created: 'x', cfg: { ...CFG, name, connect: c }, picks: [], preds: [], mocks: [], connect: c, sleeperLeagueId: lid }; };
const fsx = fs;
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const errs = [];
const open = async (leagues, route, vp = { width: 1450, height: 1100 }) => {
  const page = await (await b.newContext({ viewport: vp })).newPage();
  page.on('pageerror', (e) => errs.push(String(e)));
  await page.goto(APP, { waitUntil: 'domcontentloaded' });
  await page.evaluate(([l, r]) => { localStorage.clear(); localStorage.setItem('fdc:token', 't'); localStorage.setItem('fdcTourSeen', '1');
    localStorage.setItem('fdc:gs-state', JSON.stringify({ user: { email: 'trey.rose@pirates.com', paid: true, admin: true, rankSets: [], sleeperUsername: 'trey', sleeperUserId: 's1', homeView: 'season' }, leagues: l, funMocks: [] }));
    sessionStorage.setItem('gs-nav', JSON.stringify(r)); }, [leagues, route]);
  await page.reload({ waitUntil: 'domcontentloaded' });
  return page;
};
/* My Week / Game Day / Review are not restored from the session, so walk in through the home menu. */
const inSeason = async (page, tab) => {
  await page.waitForSelector('button.menuitem', { state: 'attached', timeout: 30000 }); await page.waitForTimeout(800);
  await page.evaluate(() => {
    const btn = Array.from(document.querySelectorAll('button.menuitem')).find((e) => /my (week|teams)/i.test((e.innerText || '').trim()))
      || Array.from(document.querySelectorAll('button')).find((e) => /^\s*My (week|teams)\s*$/i.test(e.innerText || ''));
    if (btn) btn.click();
  });
  await page.waitForSelector('[data-inseasontabs]', { timeout: 30000 });
  if (tab) { await page.click(`button[data-inseasontab="${tab}"]`); }
  await page.waitForTimeout(1500);
};
const cardText = (page) => page.$eval('[data-wkcard]', (x) => x.innerText).catch(() => '');
const LK = lg('HK', 'Blank Kicker League', 'hub-lg-nk');
const LR = lg('HR', 'Role Change League', 'hub-lg-role');
const LD = lg('HD', 'Dynasty Fixture League', 'hub-lg-dyn');
const LM = lg('HM', 'Kicker Margins League', 'hub-lg-mev');
const L1 = lg('H1', 'Hub Fixture League', 'hub-lg-1'), L2 = lg('H2', 'Superflex 3WR League', 'hub-lg-2'), LQ = lg('HQ', 'QB Crisis League', 'hub-lg-qb');


const PACK = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-pack.json', import.meta.url), 'utf8'));
const HUB = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-hub.json', import.meta.url), 'utf8'));




const HUBF = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-hub.json', import.meta.url), 'utf8'));
const PACKF = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-pack.json', import.meta.url), 'utf8'));
const STDF = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-std.json', import.meta.url), 'utf8'));
const byId = new Map(PACKF.players.map((p) => [p.id, p]));
const meT = HUBF.teams.find((t) => t.rosterId === HUBF.myRosterId);
const t2 = HUBF.teams.find((t) => t.rosterId === 2);

const priceIt = async (league, leagueId, giveName, getName, partner) => {
  const page = await open([league], { route: 'teamHub', activeId: null, hubLeagueId: leagueId });
  await page.waitForSelector('[data-hubnav]', { timeout: 30000 }); await page.waitForTimeout(2500);
  await page.click('[data-hubgroup="moves"]'); await page.click('[data-hubtabbtn="trades"]'); await page.click('[data-tsectab="calc"]'); await page.waitForTimeout(500);
  await (await page.$('select[data-tbside-select="b"]')).selectOption({ label: partner }); await page.waitForTimeout(700);
  await page.click(`[data-tbcol="give"] [data-tbplayer="${giveName}"]`);
  await page.click(`[data-tbcol="get"] [data-tbplayer="${getName}"]`);
  await page.waitForTimeout(1600);
  const out = await page.evaluate(() => {
    const el = document.querySelector('[data-tbfair]'); if (!el) return null;
    const rows = [...el.querySelectorAll('[data-tbmarketrow]')].map((r) => ({ who: r.getAttribute('data-tbmarketrow'), t: r.innerText.replace(/\s+/g, ' ') }));
    return { t: el.innerText.replace(/\s+/g, ' '), rows };
  });
  return { page, out };
};

/* ══ §1 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §1 the price, term by term ==');
await post('/stub/reset'); await post('/stub/std', { mode: 'on' });
{
  const cold = meT.players.map((id) => byId.get(id)).find((p) => p && p.name === STDF._cold);
  const hotThem = t2.players.map((id) => byId.get(id)).find((p) => p && p.name === STDF._hotThem);
  const { page, out } = await priceIt(L1, 'hub-lg-1', cold.name, hotThem.name, t2.teamName);
  ok('1 · ⭐⭐⭐⭐⭐ every man in the deal is priced, with the terms shown', !!out && out.rows.length === 2, out ? out.rows.map((r) => r.who).join(', ') : 'no block');
  ok('1a · ⭐⭐⭐⭐⭐ the base is REST OF SEASON over a replacement starter at his position, not a season total',
    !!out && out.rows.every((r) => /over a replacement (RB|WR|TE|QB|K|DEF) for the \d+ weeks left/.test(r.t)), out ? out.rows[0].t.slice(0, 130) : '');
  ok('1b · ⭐⭐⭐⭐ and the block says what it is pricing and what it cannot see', !!out && /scarcity is priced in/i.test(out.t) && /Snap and target share are not in this app/i.test(out.t));
  ok('1c · ⭐⭐⭐⭐⭐ the hot player carries a form premium', !!out && new RegExp(`${STDF._hotThem}[^|]*form \\+\\d+%`).test(out.t), out ? (out.rows.find((r) => r.who === STDF._hotThem) || {}).t : '');
  ok('1d · ⭐⭐⭐⭐ and the cold one is marked down', !!out && new RegExp(`${STDF._cold}[^|]*form -\\d+%`).test(out.t), out ? (out.rows.find((r) => r.who === STDF._cold) || {}).t : '');
  await page.context().close();
}

/* ══ §2 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §2 the man who just took the job ==');
await post('/stub/reset'); await post('/stub/std', { mode: 'on' });
{
  const hub = await (await fetch(`${STUB}/api/connect/sleeper/team-hub?league_id=hub-lg-role`)).json();
  const promoted = hub._promoted;
  const mineWR = meT.players.map((id) => byId.get(id)).filter((p) => p && p.pos === 'WR').sort((a, b) => a.adp - b.adp)[0];
  ok('2 · (fixture) their man is a bench body on projection and is projected 18.4 this week', !!promoted, promoted);
  const { page, out } = await priceIt(LR, 'hub-lg-role', mineWR.name, promoted, t2.teamName);
  const row = out && out.rows.find((r) => r.who === promoted);
  ok('2a · ⭐⭐⭐⭐⭐ the calculator prices the ROLE he is playing now, not his preseason projection', !!row && /role \+\d+%/.test(row.t), row ? row.t.slice(0, 170) : (out ? out.rows.map((r) => r.who).join(', ') : 'no block'));
  ok('2b · ⭐⭐⭐⭐⭐ and it shows the evidence: this week against his own season rate', !!row && /18\.4 this week against a [\d.]+ season rate/.test(row.t), row ? row.t.slice(-90) : '');
  /* ⚠ THE POINT OF THE ROLE TERM IS THE PRICE, NOT THE SENTENCE. On his preseason projection he is below a
     replacement starter and worth exactly nothing, which is how the first cut priced him: a role
     MULTIPLIER times zero is zero. He has to carry real value. */
  const val = row ? Number((row.t.match(/ (\d+(?:\.\d)?) \d/) || [])[1]) : null;
  ok('2c · ⭐⭐⭐⭐⭐ so he is worth something, where his preseason projection alone prices him at nothing', !!val && val >= 5, row ? row.t.slice(0, 80) : '');
  await page.context().close();
}

/* ══ §3 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §3 redraft prices this season; dynasty prices next year too ==');
await post('/stub/reset'); await post('/stub/std', { mode: 'on' });
{
  const mineRB = meT.players.map((id) => byId.get(id)).filter((p) => p && p.pos === 'RB').sort((a, b) => a.adp - b.adp)[0];
  const theirWR = t2.players.map((id) => byId.get(id)).filter((p) => p && p.pos === 'WR').sort((a, b) => a.adp - b.adp)[0];
  const r1 = await priceIt(L1, 'hub-lg-1', mineRB.name, theirWR.name, t2.teamName);
  ok('3 · ⭐⭐⭐⭐ a redraft league prices this season only — no "next year" in the breakdown', !!r1.out && !/next year/i.test(r1.out.t), r1.out ? r1.out.rows[0].t.slice(0, 120) : 'no block');
  await r1.page.context().close();
  const r2 = await priceIt(LD, 'hub-lg-dyn', mineRB.name, theirWR.name, t2.teamName);
  ok('3a · ⭐⭐⭐⭐⭐ a dynasty league puts a share of the price on next year, with the age that drives it',
    !!r2.out && /% of the price is next year/.test(r2.out.t) && /age \d+/.test(r2.out.t), r2.out ? (r2.out.rows[0] || {}).t : 'no block');
  ok('3b · ⭐⭐⭐⭐ and it says so in words rather than moving a number silently', !!r2.out && /blended with next year because this league keeps players/i.test(r2.out.t));
  await r2.page.context().close();
}

ok('4 · nothing threw', errs.length === 0, errs.slice(0, 2).join(' || ').slice(0, 200));
await b.close();
console.log(`\n  ${pass} PASS  ${fail} FAIL`);
process.exit(fail ? 1 : 0);
