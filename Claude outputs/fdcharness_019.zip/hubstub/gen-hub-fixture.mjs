/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   THE LEAGUE-HUB FIXTURE — 29be. The stub's missing piece since the container loss.
   ───────────────────────────────────────────────────────────────────────────────────────────────────
   Without a team-hub route and a player pack the browser suites could not open the in-season hub at all,
   which is how 29bb/29bc shipped a whole new tab — and 29be a whole new menu — verified only in node.
   This generates three files from the APP'S OWN built-in board (through the node library build), so the
   players, stat lines and projections are real rather than invented:
     fixture-pack.json  a player pack in the shape /api/player-pack serves (id, name, pos, team, age, bye,
                        adp, stats in engine keys) — the ids are what the hub's rosters point at
     fixture-hub.json   a 12-team Sleeper-shaped team-hub payload, snake-drafted by ADP, week 9 of 14
     fixture-std.json   season-to-date actuals through week 8, with named HOT and COLD players on MY team
                        so the form blend has something it can visibly move
   Run from /home/claude/work after the lib build:  node hubstub/gen-hub-fixture.mjs
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import fs from 'node:fs';
import path from 'node:path';
const here = path.dirname(new URL(import.meta.url).pathname);
const { buildPlayers, normalizeHubCfg } = await import(path.join(here, '..', 'probe', 'lib', 'app-lib.js'));

const START = { QB: 1, RB: 2, WR: 2, TE: 1, FLEX: 1, SUPER: 0, K: 1, DST: 1 };
const HUBCFG = { teams: 12, rounds: 15, type: 'redraft', sf: false, tePremMult: 0, start: START,
  scoring: { rec: 1, recTE: 1 } };
const pool = buildPlayers(normalizeHubCfg(HUBCFG))
  .filter((p) => p && p.name && ['QB', 'RB', 'WR', 'TE', 'K', 'DST'].includes(p.pos) && p.adp != null)
  .sort((a, b) => a.adp - b.adp);

/* Stable, Sleeper-looking ids. ⚠ They are this fixture's own, so nothing here depends on real Sleeper ids. */
const idOf = new Map(pool.map((p, i) => [p.name, String(90000 + i)]));
const pack = {
  format: 'PPR|1QB|STD|REDRAFT|12', requestedFormat: 'PPR|1QB|STD|REDRAFT|12',
  players: pool.map((p) => ({ id: idOf.get(p.name), name: p.name, pos: p.pos === 'DST' ? 'DEF' : p.pos,
    team: p.team, age: p.age, bye: p.bye, adp: p.adp, adpHi: p.adp, stats: p.stats || {} })),
};

/* ---- 12 teams, snake by ADP, 15 rounds ---- */
const NAMES = ['Yinzer Bombers', 'Steel City Sharks', 'Allegheny Anchors', 'Three Rivers', 'Mon Valley Mudcats',
  'Strip District', 'Point Breeze', 'Polish Hill', 'Squirrel Hill Nuts', 'North Shore', 'Bloomfield Bruisers', 'Lawrenceville'];
const teams = NAMES.map((n, i) => ({ rosterId: i + 1, ownerId: `o${i + 1}`, ownerName: i === 0 ? 'trey' : `mgr${i + 1}`,
  teamName: n, players: [], reserve: [], taxi: [], keepers: [], starters: [] }));
const taken = new Set();
for (let rd = 0; rd < 15; rd++) {
  for (let k = 0; k < 12; k++) {
    const t = teams[rd % 2 ? 11 - k : k];
    const have = (pos) => t.players.filter((id) => pool.find((p) => idOf.get(p.name) === id).pos === pos).length;
    /* A little position sense so every roster can field a lineup: no second K/DST, at most 3 QB/TE. */
    const pick = pool.find((p) => !taken.has(p.name)
      && !((p.pos === 'K' || p.pos === 'DST') && have(p.pos) >= 1)
      && !((p.pos === 'QB' || p.pos === 'TE') && have(p.pos) >= 2)
      && !((p.pos === 'K' || p.pos === 'DST') && rd < 12));
    taken.add(pick.name);
    t.players.push(idOf.get(pick.name));
  }
}
const byId = new Map(pool.map((p) => [idOf.get(p.name), p]));
/* Sleeper stores a set lineup positionally: QB, RB, RB, WR, WR, TE, FLEX, K, DEF. */
teams.forEach((t) => {
  const mine = t.players.map((id) => byId.get(id)).sort((a, b) => b.pts - a.pts);
  const used = new Set();
  const take = (ok) => { const p = mine.find((x) => !used.has(x.name) && ok(x)); if (p) used.add(p.name); return p ? idOf.get(p.name) : '0'; };
  t.starters = [take((p) => p.pos === 'QB'), take((p) => p.pos === 'RB'), take((p) => p.pos === 'RB'),
    take((p) => p.pos === 'WR'), take((p) => p.pos === 'WR'), take((p) => p.pos === 'TE'),
    take((p) => ['RB', 'WR', 'TE'].includes(p.pos)), take((p) => p.pos === 'K'), take((p) => p.pos === 'DST')];
});
teams.forEach((t, i) => {
  const w = [6, 5, 5, 5, 4, 4, 4, 4, 3, 3, 3, 2][i];
  t.record = { wins: w, losses: 8 - w, ties: 0 };
  t.pointsFor = 820 + w * 30 + i; t.pointsAgainst = 900; t.weekPoints = 0; t.matchupId = Math.floor(i / 2) + 1; t.faabUsed = null;
});
const WEEK = 9, REG = 14;
const weekly = {};
teams.forEach((t) => t.players.forEach((id) => {
  const p = byId.get(id);
  weekly[id] = { pts: Math.round((p.pts / 17) * 10) / 10, opp: 'CLE', team: p.team, home: true, date: '2026-11-08' };
}));
const schedule = {};
for (let w = WEEK; w <= REG; w++) {
  const ids = teams.map((t) => t.rosterId);
  const rot = ids.slice(1); for (let r = 0; r < (w - WEEK); r++) rot.push(rot.shift());
  const order = [ids[0], ...rot];
  schedule[w] = Array.from({ length: 6 }, (_, k) => [order[k], order[11 - k]]);
}
const standings = teams.slice().sort((a, b) => b.record.wins - a.record.wins || b.pointsFor - a.pointsFor)
  .map((t, i) => ({ rank: i + 1, rosterId: t.rosterId, teamName: t.teamName, ownerName: t.ownerName, record: t.record, pointsFor: t.pointsFor, isMe: t.rosterId === 1 }));
const me = teams[0];
const hub = {
  leagueName: 'Hub Fixture League', cfg: HUBCFG, week: WEEK, defaultWeek: WEEK, minWeek: 1, maxWeek: 18, season: '2026',
  scoringField: 'pts_ppr', seasonType: 'regular', myRosterId: 1, linked: true, ownerResolved: true, ownerHint: null,
  byeTeams: [], byeTeamsNext: [], rostered: teams.flatMap((t) => t.players), trending: {}, trendAudit: null,
  teams, matchup: { me, opp: teams[1], meProj: null, oppProj: null }, medianScoring: false, medianProjected: null,
  standings, playoffStartWeek: REG + 1, regularSeasonWeeks: REG, playoffTeams: 6, faabBudget: null, faabLeft: {},
  schedule, weekly, matchupDifficulty: {}, platform: 'sleeper',
};

/* ---- season-to-date through week 8: my best WR is HOT, my best RB is COLD, everyone else on projection ---- */
const mineBy = (pos) => me.players.map((id) => byId.get(id)).filter((p) => p.pos === pos).sort((a, b) => b.pts - a.pts)[0];
const hotWR = mineBy('WR'), coldRB = mineBy('RB');
const line = (p, mult, gp = 8) => {
  const s = {}; Object.keys(p.stats || {}).forEach((k) => { s[k] = Math.round((p.stats[k] || 0) * (gp / 17) * mult * 10) / 10; });
  return { gp, s };
};
const players = {};
teams.forEach((t) => t.players.forEach((id) => { players[id] = line(byId.get(id), 1); }));
players[idOf.get(hotWR.name)] = line(hotWR, 1.6);
players[idOf.get(coldRB.name)] = line(coldRB, 0.45);
/* 29br — AND ONE ON SOMEBODY ELSE'S TEAM, because the fairness block is about a trade: a man coming TO me
   who has been playing above his projection is exactly the case Trey described (Washington trending up
   against Judkins trending down), and no fixture could express it while only my own team had form. */
const theirsBy = (pos) => teams[1].players.map((id) => byId.get(id)).filter((p) => p.pos === pos).sort((a, b) => b.pts - a.pts)[0];
const hotThemWR = theirsBy('WR');
players[idOf.get(hotThemWR.name)] = line(hotThemWR, 1.6);
const std = { season: 2026, week: WEEK, throughWeek: WEEK - 1, players, _hot: hotWR.name, _cold: coldRB.name,
  _hotThem: hotThemWR.name,
  _myQB: mineBy('QB').name, _myQBid: idOf.get(mineBy('QB').name) };

fs.writeFileSync(path.join(here, 'fixture-pack.json'), JSON.stringify(pack));
fs.writeFileSync(path.join(here, 'fixture-hub.json'), JSON.stringify(hub));
fs.writeFileSync(path.join(here, 'fixture-std.json'), JSON.stringify(std));
console.log(`pack ${pack.players.length} players · hub ${teams.length} teams, week ${WEEK} · std ${Object.keys(players).length} players`);
console.log(`my team: QB ${std._myQB} · HOT WR ${std._hot} · COLD RB ${std._cold} · their HOT WR ${std._hotThem}`);
