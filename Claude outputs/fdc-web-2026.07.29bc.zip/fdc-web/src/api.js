// Backend API client. Points at the fdc-backend you deployed.
//
// Set VITE_API_URL (e.g. https://fdc-backend.onrender.com) in your environment / Render settings.
// If it's NOT set, the app runs in LOCAL mode: accounts/payments are simulated and data comes from
// the built-in engine. This means the site always works even before the backend is connected —
// connecting the backend is a pure upgrade, not a requirement to launch.

import { packState, unpackState } from './statecodec.js';

const API = import.meta.env.VITE_API_URL || '';
export const hasBackend = !!API;

const TOKEN_KEY = 'fdc:token';
// Remembers the server's most-recent state updated_at, used for optimistic-concurrency on writes.
let _lastStateUpdatedAt = null;
export const getToken = () => { try { return localStorage.getItem(TOKEN_KEY); } catch { return null; } };
export const setToken = (t) => { try { t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY); } catch {} };

/* ⭐⭐⭐⭐ A DEAD SESSION HAS TO BE VISIBLE, BECAUSE THE APP CANNOT TELL ON ITS OWN.
 *
 * Trey: "It's not letting me add free / comp users… It's saying I must sign in, but I'm signed in."
 *
 * He was. The app restores the signed-in user from local storage on boot and recomputes the admin flag
 * from the email — no token is consulted — while the TOKEN lives in a different store and can be gone,
 * expired, or issued by a different backend. Nothing reconciled the two, so the screen said "signed in as
 * an admin" and every admin request came back "Sign in required," and both were telling the truth about
 * different things.
 *
 * The only place that can notice is here, where the 401 actually arrives. So: when an authenticated call
 * is refused because the session is dead, drop the dead token (keeping it only guarantees the next call
 * fails the same way) and tell the app, once, so it can say so and offer the sign-in box.
 *
 * ⚠ ONLY on a genuine session failure. A 503 AUTH_UNAVAILABLE means the server could not check — signing
 *   the user out then would turn a five-second database blip into a lost session and a password prompt
 *   for a password that was never wrong. That case retries (it is a 5xx) and never reaches here.
 */
const _authSubs = new Set();
let _authDead = null;          // null while healthy; otherwise { code, message, at }
export const authHealth = {
  get dead() { return _authDead; },
  clear() { _authDead = null; },
  subscribe(cb) { _authSubs.add(cb); return () => _authSubs.delete(cb); },
  /* For the ONE case no request can discover: a signed-in user restored from local storage with no token
     to send. api.me() short-circuits when there is no token, so nothing 401s, nothing fires, and the app
     shows a signed-in header forever. Boot reports it here instead. */
  reportDead(code, message) { markSessionDead(code, message); },
};
function markSessionDead(code, message) {
  setToken(null);
  const info = { code, message, at: Date.now() };
  // First one wins the notification; a burst of parallel calls all 401 at once and one banner is enough.
  const already = !!_authDead;
  _authDead = info;
  if (already) return;
  for (const cb of _authSubs) { try { cb(info); } catch {} }
}

// `timeoutMs`   — override the per-attempt timeout. Long admin jobs (harvest, full refresh) run SYNCHRONOUSLY
//                 on the server and can take minutes; the default 45s ceiling aborts them client-side long
//                 before they finish, which surfaces as a bogus "BACKEND_WAKING" even though the job is fine.
// `retries`     — set to 0 for anything NON-IDEMPOTENT. Aborting a fetch does NOT cancel the server, so a
//                 retry can stack a second harvest/refresh on top of the first one that's still running.
async function call(path, { method = 'GET', body, auth = true, retries = 2, timeoutMs } = {}) {
  if (!API) throw new Error('NO_BACKEND');
  const headers = { 'Content-Type': 'application/json' };
  const token = auth ? getToken() : null;
  if (token) headers.Authorization = `Bearer ${token}`;
  let lastErr = null;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const ctrl = new AbortController();
      // Render free/starter dynos can cold-start slowly; give the FIRST attempt a long leash (45s) so a
      // waking server isn't reported as a hard failure, then shorter timeouts on retries. A caller-supplied
      // timeoutMs wins outright, and applies to EVERY attempt (a retry that's shorter than a cold start is
      // guaranteed to fail, which is exactly what made long jobs look permanently broken).
      const perAttempt = timeoutMs != null ? timeoutMs : (attempt === 0 ? 45000 : 20000);
      const to = setTimeout(() => ctrl.abort(), perAttempt);
      let res;
      try {
        res = await fetch(`${API}${path}`, { method, headers, body: body ? JSON.stringify(body) : undefined, signal: ctrl.signal });
      } finally { clearTimeout(to); }
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        // 5xx from a still-booting backend is worth a retry; 4xx (bad credentials etc.) is not.
        if (res.status >= 500 && attempt < retries) { lastErr = Object.assign(new Error(data.error || `HTTP ${res.status}`), { status: res.status, data }); await new Promise((r) => setTimeout(r, 1500 * (attempt + 1))); continue; }
        // A 401 on a call that PRESENTED a token means that token is dead — the one case where the client
        // knows more than the screen does. (A 401 with no token sent is just an anonymous request hitting a
        // gated route; there is nothing to invalidate and nobody to tell.)
        if (res.status === 401 && token && data.code !== 'AUTH_UNAVAILABLE') {
          markSessionDead(data.code || 'SESSION_EXPIRED', data.error || 'Your sign-in has expired on this device.');
        }
        throw Object.assign(new Error(data.error || `HTTP ${res.status}`), { status: res.status, data, code: data.code || null });
      }
      return data;
    } catch (e) {
      // Network-level failure ("Failed to fetch") or timeout (AbortError) — the backend is likely cold-starting
      // or briefly unreachable. Retry with backoff before giving up so users aren't locked out by a cold dyno.
      const transient = e.name === 'AbortError' || e.message === 'Failed to fetch' || /NetworkError|network|fetch/i.test(e.message || '');
      if (transient && attempt < retries) { lastErr = e; await new Promise((r) => setTimeout(r, 1500 * (attempt + 1))); continue; }
      if (transient) throw new Error('BACKEND_WAKING');
      throw e;
    }
  }
  throw lastErr || new Error('BACKEND_WAKING');
}

// ---- SYNC HEALTH -------------------------------------------------------------------------------------
// Working without the backend is fine and by design: the engine is entirely client-side and every pick is
// saved on the device first. Working without it while APPEARING to be backed up is not fine — if the
// browser holds the only copy of a live draft, the user is entitled to know before they close the tab.
//
// So this tracks one specific thing: whether the last attempt to mirror state to the server succeeded.
// Not "is there internet", not "did some request 404" — did YOUR DATA reach the server. It flips on the
// first failed mirror and back on the first successful one, and only the state write moves it, so a
// failing side-feature can never raise a false alarm about a draft.
let _syncOk = true;
let _syncSince = 0;
const _syncSubs = new Set();
function markSync(ok) {
  if (ok === _syncOk) return;
  _syncOk = ok;
  _syncSince = Date.now();
  for (const cb of _syncSubs) { try { cb(ok); } catch {} }
}
export const syncHealth = {
  get ok() { return _syncOk; },
  get since() { return _syncSince; },
  subscribe(cb) { _syncSubs.add(cb); return () => _syncSubs.delete(cb); },
};

export const api = {
  hasBackend,

  // Wake a sleeping Render dyno before issuing a slow request.
  //
  // The Starter tier sleeps when idle and takes ~10-40s to boot. A long admin job fired at a cold backend
  // spends its whole timeout budget just waiting for the server to exist, then aborts — surfacing as
  // "BACKEND_WAKING" even though nothing is actually wrong. Pinging the cheap, rate-limit-exempt /api/health
  // first separates the two concerns: we wait for the server to come up, THEN start the job with a full,
  // uninterrupted timeout budget. Returns true once the backend answers.
  async wake({ maxWaitMs = 90000, onTick } = {}) {
    if (!API) return false;
    const started = Date.now();
    let tries = 0;
    while (Date.now() - started < maxWaitMs) {
      tries++;
      try {
        const ctrl = new AbortController();
        const to = setTimeout(() => ctrl.abort(), 10000);
        try {
          const res = await fetch(`${API}/api/health`, { signal: ctrl.signal });
          if (res.ok) return true;
        } finally { clearTimeout(to); }
      } catch { /* still booting */ }
      if (onTick) onTick(Math.round((Date.now() - started) / 1000), tries);
      await new Promise((r) => setTimeout(r, 2000));
    }
    return false;
  },

  // ---- auth ----
  async signup(email, password) {
    const r = await call('/api/auth/signup', { method: 'POST', auth: false, body: { email, password } });
    setToken(r.token); authHealth.clear(); return r.user;
  },
  async signin(email, password) {
    const r = await call('/api/auth/signin', { method: 'POST', auth: false, body: { email, password } });
    setToken(r.token); authHealth.clear(); return r.user;
  },
  async me() {
    if (!getToken()) return null;
    const r = await call('/api/auth/me'); return r.user;
  },
  /* Always answers, even with no session — that is the whole point of it. Says which of the four states
     the server sees us in (ok / anon / expired / unavailable) so a screen can report the real reason
     instead of relaying a refusal. Used by the admin screen's session check. */
  async session() { return call('/api/auth/session'); },
  // Password reset. `forgot` now answers 404 with code NO_ACCOUNT when the address has no account (see the
  // note in the backend's auth route — a deliberate, rate-limited trade), so the modal can say which of the
  // two things went wrong instead of leaving someone waiting for an email that was never sent to anybody.
  // retries:0 — a resend would issue a SECOND token and silently invalidate the link already in flight.
  async forgotPassword(email) {
    return call('/api/auth/forgot', { method: 'POST', auth: false, retries: 0, body: { email } });
  },
  // Does this address have an account? Backs "Forgot username" — the username here IS the email, so there
  // is nothing to send and the only useful answer is yes/no. `null` means the server declined to say.
  async accountExists(email) {
    const r = await call('/api/auth/account-exists', { method: 'POST', auth: false, retries: 0, body: { email } });
    return r && typeof r.exists !== 'undefined' ? r.exists : null;
  },
  async resetPassword(token, password) {
    const r = await call('/api/auth/reset', { method: 'POST', auth: false, retries: 0, body: { token, password } });
    // Guard the shape: a 200 that isn't the expected body (an old build, a proxy, a misrouted path) would
    // otherwise sign nobody in and surface as a raw TypeError in the modal.
    if (!r || !r.token || !r.user) throw new Error('The server did not complete the reset. Request a new link.');
    setToken(r.token); authHealth.clear(); return r.user;
  },
  // The Tuesday weekly-brief SUBSCRIPTION. Opt-in: nobody is emailed unless they turned this on, so this
  // call is the consent itself. Both directions, because the unsubscribe link promises a way back.
  async setEmailPrefs(briefOptIn) {
    return call('/api/auth/email-prefs', { method: 'POST', body: { briefOptIn: !!briefOptIn } });
  },
  async saveRankSets(rankSets, platformRanks) {
    // platformRanks rides along on the same endpoint: it is the other thing the user hand-builds, and it had
    // no server home at all until now.
    const body = { rankSets };
    if (platformRanks && typeof platformRanks === 'object') body.platformRanks = platformRanks;
    const r = await call('/api/auth/rank-sets', { method: 'POST', body });
    return r.user;
  },
  signout() { setToken(null); },

  // ---- payments ----
  async startCheckout() {
    // retries:1 — the default 2 retries with backoff makes a buyer stare at "Taking you to checkout…" for
    // ~5 seconds before being told it failed, and the most common 5xx here ("Payments not configured") is
    // never going to succeed on a retry. One retry covers a genuinely cold dyno; after that, tell them.
    const r = await call('/api/payments/checkout', {
      method: 'POST',
      retries: 1,
      body: { successUrl: `${location.origin}/?paid=1`, cancelUrl: `${location.origin}/?canceled=1` },
    });
    return r.url; // caller redirects to Stripe
  },

  // ---- data ----
  async adpBoard(format, season) {
    return call(`/api/adp/board?format=${encodeURIComponent(format)}${season ? `&season=${season}` : ''}`, { auth: false });
  },
  async adpPlayer(playerId, format, season) {
    return call(`/api/adp/player/${playerId}?format=${encodeURIComponent(format)}${season ? `&season=${season}` : ''}`, { auth: false });
  },
  // Aggregated draft trends from the harvested-drafts pool (thousands of real Sleeper drafts).
  async trendsBoard(format, season, opts = {}) {
    const extra = [];
    if (season) extra.push(`season=${season}`);
    if (opts.limit) extra.push(`limit=${opts.limit}`);
    if (opts.minDrafts != null) extra.push(`minDrafts=${opts.minDrafts}`);
    if (opts.minPicks != null) extra.push(`minPicks=${opts.minPicks}`);
    return call(`/api/trends/board?format=${encodeURIComponent(format)}${extra.length ? `&${extra.join('&')}` : ''}`, { auth: false });
  },
  async trendsPlayer(playerId, format, season, teams) {
    const extra = [];
    if (season) extra.push(`season=${season}`);
    if (teams) extra.push(`teams=${teams}`);
    return call(`/api/trends/player/${playerId}?format=${encodeURIComponent(format)}${extra.length ? `&${extra.join('&')}` : ''}`, { auth: false });
  },
  async trendsDiag(season) {
    return call(`/api/trends/diag${season ? `?season=${season}` : ''}`, { auth: false });
  },
  async projections(season) {
    return call(`/api/projections${season ? `?season=${season}` : ''}`, { auth: false });
  },
  async playerPack(format, season, opts = {}) {
    const extra = [];
    if (season) extra.push(`season=${season}`);
    if (opts.k) extra.push("k=1");
    if (opts.dst) extra.push("dst=1");
    if (opts.idp) extra.push("idp=1");
    // The league's OWN playoff weeks. This changes the playoff-SOS numbers, so it is part of the pack's
    // identity on the server too — a week-14 league must not be served a week-15 league's read.
    if (opts.playoffStart) extra.push(`pw=${Number(opts.playoffStart)}`);
    // TE-PREMIUM SIZE. The format key only records that a league HAS a TE premium, not how big it is —
    // but Sleeper publishes no TE-premium ADP at all, so the server has to model the shift, and a 0.5/rec
    // bonus moves tight ends far less than a 1.5/rec one. Part of the cache identity on the server.
    if (opts.tep) extra.push(`tep=${Number(opts.tep)}`);
    return call(`/api/player-pack?format=${encodeURIComponent(format)}${extra.length ? "&" + extra.join("&") : ""}`, { auth: false });
  },

  // ---- leagues / drafts ----
  async listLeagues() { return (await call('/api/leagues')).leagues; },
  async createLeague(payload) { return (await call('/api/leagues', { method: 'POST', body: payload })).league; },
  async updateLeague(id, patch) { return (await call(`/api/leagues/${id}`, { method: 'PATCH', body: patch })).league; },
  async deleteLeague(id) { return call(`/api/leagues/${id}`, { method: 'DELETE' }); },
  async saveDraft(leagueId, draft) { return (await call(`/api/leagues/${leagueId}/drafts`, { method: 'POST', body: draft })).draft; },

  // ---- per-user app state (cross-device persistence of the local gs-state blob) ----
  // We remember the updated_at we last saw from the server and send it as baseUpdatedAt on write, so the
  // server can reject a stale overwrite (409) instead of silently clobbering newer data from another device.
  /* ⭐⭐ THE BLOB IS COMPRESSED ON THE WIRE AND IN THE DATABASE. A mock's per-pick name arrays are 82% of
     what it costs to store, and they are recoverable from a single id→name table per league — see
     statecodec.js for the measurements and the one case that is deliberately left uncompressed.
     Unpack on the way in, pack on the way out, and nothing between here and React knows the difference. */
  async getState() {
    const r = await call('/api/state');
    if (r && r.updatedAt) _lastStateUpdatedAt = r.updatedAt;
    if (r && r.state) return { ...r, state: unpackState(r.state) };
    return r;
  },
  async putState(state) {
    try {
      const r = await call('/api/state', { method: 'PUT', body: { state: packState(state), baseUpdatedAt: _lastStateUpdatedAt } });
      if (r && r.updatedAt) _lastStateUpdatedAt = r.updatedAt;
      markSync(true);
      return r;
    } catch (e) {
      // 409 = the server has newer data (another device saved). Return the server's state + updatedAt so the
      // caller can merge and re-save, rather than losing the newer copy.
      if (e && e.status === 409 && e.data) {
        if (e.data.serverUpdatedAt) _lastStateUpdatedAt = e.data.serverUpdatedAt;
        markSync(true);   // the server answered — a conflict is a healthy connection, not a broken one
        // ⚠ THE CONFLICT PAYLOAD IS THE SERVER'S BLOB, so it is packed too — the caller merges it into
        //   live React state and would otherwise be handed mocks with no names on them.
        return { ok: false, conflict: true, state: unpackState(e.data.state || {}), updatedAt: e.data.serverUpdatedAt || null };
      }
      markSync(false);
      throw e;
    }
  },

  // ---- Sleeper connect / live sync ----
  async sleeperLeagues(username) { return call(`/api/connect/sleeper/leagues?username=${encodeURIComponent(username)}`); },
  async sleeperDraft(leagueId, username, userId) { return call(`/api/connect/sleeper/draft?league_id=${encodeURIComponent(leagueId)}${username ? `&username=${encodeURIComponent(username)}` : ''}${userId ? `&user_id=${encodeURIComponent(userId)}` : ''}`); },
  // Fast picks-only poll for live drafts — much lighter than sleeperDraft (picks + clock only). Pass draftId
  // after the first call to skip the league→draft lookup for the quickest possible round-trip.
  async sleeperPicks(leagueId, draftId) { return call(`/api/connect/sleeper/picks?league_id=${encodeURIComponent(leagueId)}${draftId ? `&draft_id=${encodeURIComponent(draftId)}` : ''}`); },
  // ---- persistent Sleeper account links (plural since b132) ----
  // -> { linked, accounts:[{platform,id,username}], sleeperUserId, sleeperUsername } — the last two are the
  //    PRIMARY account, kept so every caller written before multi-account keeps working unchanged.
  async sleeperAccount() { return call('/api/connect/sleeper/account'); },
  async sleeperLink(username) { return call('/api/connect/sleeper/link', { method: 'POST', body: { username } }); },
  // No argument = remove every linked account (what "Unlink" has always meant). An id = remove just that one.
  async sleeperUnlink(sleeperUserId) { return call('/api/connect/sleeper/unlink', { method: 'POST', body: sleeperUserId ? { sleeperUserId } : {} }); },
  async sleeperMyLeagues(season) { return call(`/api/connect/sleeper/my-leagues${season ? `?season=${season}` : ''}`); },
  /* `owner` is the Sleeper username this league was imported under. It is a HINT for one question — which
     of the league's rosters is yours — and it is what keeps a league readable after the account that owns
     it is unlinked. Public data, so it is fine in the query string (unlike the MFL/Fantrax secrets). */
  /* ⭐⭐⭐⭐ EVERY LEAGUE'S LIVE SCOREBOARD IN ONE REQUEST, plus the cross-league rooting board.
     ⚠ Deliberately NOT a team-hub call per league: team-hub makes seven upstream calls each, which for
       fifteen leagues on a one-minute poll is ~105 calls/minute against an app-wide ceiling near a
       thousand — two people watching football would break live draft sync for everyone. See connect.js. */
  async sleeperLive(leagueIds, week, owners) {
    const ids = (leagueIds || []).filter(Boolean).join(',');
    const own = (owners || []).filter(Boolean).join(',');
    return call(`/api/connect/sleeper/live?league_ids=${encodeURIComponent(ids)}`
      + `${week ? `&week=${week}` : ''}${own ? `&owner=${encodeURIComponent(own)}` : ''}`);
  },
  /* ⭐⭐⭐⭐ WHAT HAPPENED IN EVERY CONNECTED LEAGUE — b161. Trades, waivers and free-agent adds across
     all of them in one call, because the ask was an AGGREGATED view: "just see an aggregated list of
     connected leagues". Same batching reasoning as sleeperLive above — one request for fifteen leagues,
     never fifteen requests.
     ⚠ `weeks` is a window, not a page. Sleeper has no recent-transactions endpoint, so the backend makes
       one upstream call per league per week; four weeks is what "recent" means and what it defaults to. */
  async sleeperTransactions(leagueIds, owners, weeks) {
    const ids = (leagueIds || []).filter(Boolean).join(',');
    const own = (owners || []).filter(Boolean).join(',');
    return call(`/api/connect/sleeper/transactions?league_ids=${encodeURIComponent(ids)}`
      + `${own ? `&owner=${encodeURIComponent(own)}` : ''}${weeks ? `&weeks=${weeks}` : ''}`);
  },

  /* The same feed for Yahoo leagues — b163. ⭐ A SEPARATE CALL, NOT A MERGED ONE: the two platforms
     address a league differently (a Sleeper numeric id vs a Yahoo "nfl.l.123" key) and answer on
     different upstreams, so one endpoint taking both would be a router pretending to be a feature. The
     screen merges the two payloads, which is where the merge belongs. */
  async yahooTransactions(leagueKeys) {
    const keys = (leagueKeys || []).filter(Boolean).join(',');
    if (!keys) return { leagues: [] };
    return call(`/api/connect/yahoo/transactions?league_keys=${encodeURIComponent(keys)}`);
  },
  /* Every COMPLETED week of one league, already reduced to verdicts, misses and totals — the whole season
     in one call so the week toggle is instant and the trend lines exist at all. See connect.js. */
  async sleeperSeasonReview(leagueId, owner) {
    return call(`/api/connect/sleeper/season-review?league_id=${encodeURIComponent(leagueId)}`
      + `${owner ? `&owner=${encodeURIComponent(owner)}` : ''}`);
  },
  async sleeperTeamHub(leagueId, week, owner) {
    return call(`/api/connect/sleeper/team-hub?league_id=${encodeURIComponent(leagueId)}`
      + `${week ? `&week=${week}` : ''}${owner ? `&owner=${encodeURIComponent(owner)}` : ''}`);
  },
  // One NFL week's games that have weather worth a manager's attention. Games in domes, games with nothing
  // to say, and games too far out to forecast never come back — see src/routes/weather.js.
  async weatherWeek(week, season) { return call(`/api/weather/week?week=${encodeURIComponent(week)}${season ? `&season=${season}` : ''}`); },
  // Dynasty draft archive: every draft in the league's season chain (startup + each rookie draft), and
  // the finished board of any one of them.
  async sleeperDraftHistory(leagueId) { return call(`/api/connect/sleeper/draft-history?league_id=${encodeURIComponent(leagueId)}`); },
  async sleeperDraftBoard(draftId) { return call(`/api/connect/sleeper/draft-board?draft_id=${encodeURIComponent(draftId)}`); },
  // ESPN: settings-only import for a PUBLIC league. There is no ESPN pick sync — see src/lib/espn.js
  // in the backend for why. Returns { cfg, teams, warnings, canSyncPicks:false }.
  async espnLeague(leagueId, season) { return call(`/api/connect/espn/league?league_id=${encodeURIComponent(leagueId)}${season ? `&season=${encodeURIComponent(season)}` : ''}`); },

  /* ---- the other platforms -------------------------------------------------------------------
     ⚠ THE ESPN PRIVATE IMPORT IS A POST, AND HAS TO STAY ONE. Those cookies are credentials; a GET
       would put them in the URL, and URLs end up in access logs, proxy logs and browser history.
       They are sent once, used for that one request, and never stored on either side. */
  async espnPrivate({ leagueId, season, espnS2, swid, teamId }) {
    return call('/api/connect/espn/private', { method: 'POST', body: { league_id: leagueId, season, espn_s2: espnS2, swid, team_id: teamId } });
  },
  /* ⚠⚠⚠ MFL AND FANTRAX ARE POSTS FOR THE SAME REASON THE ESPN PRIVATE IMPORT IS ONE, only more so.
     An MFL league API key and a Fantrax Secret ID are credentials, and these two platforms are the ones
     the DRAFT ROOM POLLS. In a query string the credential would be written into an access log every
     couple of seconds for three hours — thousands of times per draft, per user — and into browser
     history besides. In a body it is sent and gone.
     ⚠ THESE USED TO BE GETs. If you are reading this while adding a sixth platform: a credential in a
       URL is never acceptable, however convenient the call site. */
  async mflLeague(leagueId, season, apiKey) {
    return call('/api/connect/mfl/league', { method: 'POST', body: { league_id: leagueId, season: season || null, api_key: apiKey || null } });
  },
  async mflPicks(leagueId, season, apiKey) {
    return call('/api/connect/mfl/picks', { method: 'POST', body: { league_id: leagueId, season: season || null, api_key: apiKey || null } });
  },
  async fantraxLeagues(secretId) { return call('/api/connect/fantrax/leagues', { method: 'POST', body: { secret_id: secretId } }); },
  async fantraxLeague(leagueId, secretId, name) {
    return call('/api/connect/fantrax/league', { method: 'POST', body: { league_id: leagueId, secret_id: secretId || null, name: name || null } });
  },
  async fantraxPicks(leagueId, secretId) {
    return call('/api/connect/fantrax/picks', { method: 'POST', body: { league_id: leagueId, secret_id: secretId || null } });
  },
  async yahooStatus() { return call('/api/connect/yahoo/status'); },
  async yahooAuthUrl() { return call('/api/connect/yahoo/auth-url'); },
  /* ⚠⚠ retries: 0 — AN AUTHORIZATION CODE IS SINGLE-USE, which is exactly the case the `retries` note at
     the top of this file says to turn them off for. The default of 2 meant a failed exchange fired THREE
     requests at Yahoo for one code (found by plan29cn, which counted them). Two of those are guaranteed
     to fail, and the dangerous shape is the other way round: if the FIRST attempt succeeds but its
     response is lost to a blip, the retry asks Yahoo to redeem a code it has already honoured, Yahoo
     refuses, and the user is told their sign-in failed when their account was in fact linked. */
  async yahooExchange(code) { return call('/api/connect/yahoo/exchange', { method: 'POST', body: { code }, retries: 0 }); },
  async yahooMyLeagues() { return call('/api/connect/yahoo/my-leagues'); },
  async yahooLeague(leagueKey) { return call(`/api/connect/yahoo/league?league_key=${encodeURIComponent(leagueKey)}`); },
  /* ⭐⭐⭐⭐ THE IN-SEASON HUB FOR A YAHOO LEAGUE — b161. It returns the SAME payload shape as
     sleeperTeamHub, deliberately, so every in-season screen works on either platform without knowing
     which one it is reading. See the route's header for why that is the whole design. */
  async yahooTeamHub(leagueKey, week) {
    return call(`/api/connect/yahoo/team-hub?league_key=${encodeURIComponent(leagueKey)}${week ? `&week=${week}` : ''}`);
  },
  async yahooUnlink() { return call('/api/connect/yahoo/unlink', { method: 'POST', body: {} }); },
  async platformStatus(which) { return call(`/api/connect/${which}/status`); },

  // ---- feedback (public submit) ----
  async submitFeedback(payload) { return call('/api/feedback', { method: 'POST', auth: false, body: payload }); },

  // ---- admin: users ----
  async adminUsers(search) { return call(`/api/admin/users${search ? `?search=${encodeURIComponent(search)}` : ''}`); },
  async adminSetDisabled(email, disabled) { return call('/api/admin/set-disabled', { method: 'POST', body: { email, disabled } }); },
  async adminRevokeComp(email) { return call('/api/admin/revoke-comp', { method: 'POST', body: { email } }); },
  // Admin data jobs run SYNCHRONOUSLY on the server and can take minutes (a full refresh re-crawls real
  // drafts). Two things matter here:
  //   • a long timeout, or the client aborts a job that's working fine
  //   • retries: 0 — a client abort does NOT cancel the server, so retrying stacks a second harvest on top
  //     of the one still running, hammering the DB and duplicating work
  // `extra` carries the few jobs that take arguments (connect-check needs a platform and, optionally, a
  // league and its credential). Merged into the body so every other caller is unchanged.
  async adminRunJob(job, extra) {
    return call('/api/admin/run-job', { method: 'POST', body: { job, ...(extra || {}) }, timeoutMs: 300000, retries: 0 });
  },
  async adminDbSize() { return call('/api/admin/db-size', { timeoutMs: 60000, retries: 0 }); },
  async adminDbCleanup(keepDays) { return call('/api/admin/db-cleanup', { method: 'POST', body: { keepDays }, timeoutMs: 600000, retries: 0 }); },

  // ---- Manual rankings (uploaded expert/consensus rankings, e.g. FantasyPros CSV) ----
  async adminManualRankings() { return call('/api/admin/manual-rankings'); },
  async adminUploadRanking(body) { return call('/api/admin/manual-rankings', { method: 'POST', body, timeoutMs: 120000, retries: 0 }); },
  async adminDeleteRanking(id) { return call(`/api/admin/manual-rankings/${id}`, { method: 'DELETE' }); },
  // ---- admin: invites ----
  async adminInvite(email, scope) { return call('/api/admin/invite', { method: 'POST', body: { email, scope } }); },
  async adminInvites() { return call('/api/admin/invites'); },
  async adminCancelInvite(email) { return call('/api/admin/cancel-invite', { method: 'POST', body: { email } }); },
  // ---- admin: feedback inbox ----
  async adminFeedback() { return call('/api/admin/feedback'); },
  async adminFeedbackStatus(id, status) { return call(`/api/admin/feedback/${id}/status`, { method: 'POST', body: { status } }); },

  // ---- Player events (dated value-changing news that stales out pre-event ADP samples) ----
  async adminEventTypes() { return call('/api/admin/event-types'); },
  async adminPlayerSearch(term) { return call(`/api/admin/player-search?q=${encodeURIComponent(term)}`); },
  async adminEvents() { return call('/api/admin/events'); },
  async adminAddEvent(body) { return call('/api/admin/events', { method: 'POST', body }); },
  async adminDeleteEvent(id) { return call(`/api/admin/events/${id}`, { method: 'DELETE' }); },
};
