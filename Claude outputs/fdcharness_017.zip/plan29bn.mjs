/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   TREY'S 29bn NOTES — plan29bn (setup copied from plan29bm; the 29bm header below is kept for the helpers)
     §1 home This week: a Power column, record and power coloured by how I'm doing
     §2 the projected hover: a total under each team, the benches, arrows for who should move
     §3 Matchup: "start Bucky Irving (RB) for Harrison Mevis (K)" — an RB goes into the empty RB slot
     §4 calculator: a free-agent QB better than the QB I'm trading for still shows as "pick him up instead"
     §5 My Week free agents: a kicker outscored on waivers, one row + alternatives on hover; the player you'd
        start over AND the one you'd release
     §6 Review: hover vs median / vs field for every team's score, highest first, with the median line
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29bm header follows)
   TREY'S 29bm NOTES — plan29bm
     §1 Home "This week": "it isn't showing my record for each league", "my combined record through every
        league", "what do the red, yellow, and green dots... mean", "when you hover the projected score, I'd
        like to see a side by side of each team and the projected score".
     §2 Matchup: a starter traded away last week still in the lineup (Sleeper seeds the new week from the
        old one) must not show.
     §3 Hub free agents: "Higgins is on my IR... We should just ignore IR players for FA purposes."
     §4 My Week free agents: "I just lost... my 2 QBs... At a very minimum, that league should be
        recommending I pick up a QB."
     §5 My Week league activity: "show the trade grades next to each trade", the same letter the hub gives.
     §6 Game Day: "0-0-10... change these numbers to reflect the projections (and make it clear...)".
     §7 Review: hover the verdict chip for why; hover the result for both lineups side by side.
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import { chromium } from 'playwright';
import fs from 'node:fs';
const APP = 'http://localhost:4174/', STUB = 'http://localhost:5055';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { console.log(`  ${c ? 'PASS' : 'FAIL'}  ${n}${x !== '' ? `   [${x}]` : ''}`); c ? pass++ : fail++; };
const post = (p, b) => fetch(STUB + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b || {}) }).then((r) => r.json()).catch(() => null);
const CFG = { teams: 12, rounds: 15, slot: 1, type: 'redraft', sf: false, tePremMult: 0, order: 'snake',
  start: { QB: 1, RB: 2, WR: 2, TE: 1, FLEX: 1, SUPER: 0, K: 1, DST: 1 }, scoring: { rec: 1 }, caps: {}, keepers: [] };
const lg = (id, name, lid) => { const c = { platform: 'sleeper', leagueId: lid, username: 'trey', ownerUsername: 'trey' };
  return { id, name, created: 'x', cfg: { ...CFG, name, connect: c }, picks: [], preds: [], mocks: [], connect: c, sleeperLeagueId: lid }; };
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const errs = [];
const open = async (leagues, route, vp = { width: 1450, height: 1100 }) => {
  const page = await (await b.newContext({ viewport: vp })).newPage();
  page.on('pageerror', (e) => errs.push(String(e)));
  await page.goto(APP, { waitUntil: 'domcontentloaded' });
  await page.evaluate(([l, r]) => { localStorage.clear(); localStorage.setItem('fdc:token', 't'); localStorage.setItem('fdcTourSeen', '1');
    localStorage.setItem('fdc:gs-state', JSON.stringify({ user: { email: 'trey.rose@pirates.com', paid: true, admin: true, rankSets: [], sleeperUsername: 'trey', sleeperUserId: 's1', homeView: 'season' }, leagues: l, funMocks: [] }));
    sessionStorage.setItem('gs-nav', JSON.stringify(r)); }, [leagues, route]);
  await page.reload({ waitUntil: 'domcontentloaded' });
  return page;
};
/* My Week / Game Day / Review are not restored from the session, so walk in through the home menu. */
const inSeason = async (page, tab) => {
  await page.waitForSelector('button.menuitem', { state: 'attached', timeout: 30000 }); await page.waitForTimeout(800);
  await page.evaluate(() => {
    const btn = Array.from(document.querySelectorAll('button.menuitem')).find((e) => /my week/i.test((e.innerText || '').trim()))
      || Array.from(document.querySelectorAll('button')).find((e) => /^\s*My week\s*$/i.test(e.innerText || ''));
    if (btn) btn.click();
  });
  await page.waitForSelector('[data-inseasontabs]', { timeout: 30000 });
  if (tab) { await page.click(`button[data-inseasontab="${tab}"]`); }
  await page.waitForTimeout(1500);
};
const cardText = (page) => page.$eval('[data-wkcard]', (x) => x.innerText).catch(() => '');
const L1 = lg('H1', 'Hub Fixture League', 'hub-lg-1'), L2 = lg('H2', 'Superflex 3WR League', 'hub-lg-2'), LQ = lg('HQ', 'QB Crisis League', 'hub-lg-qb');


const PACK = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-pack.json', import.meta.url), 'utf8'));
const HUB = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-hub.json', import.meta.url), 'utf8'));

/* ══ §1 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §1 home: Power column, record and power coloured ==');
await post('/stub/reset'); await post('/stub/live', { mode: 'pregame' });
{
  const page = await open([L1, LQ], { route: 'home' });
  await page.waitForSelector('[data-homeaheadrow]', { timeout: 30000 }); await page.waitForTimeout(6000);
  const pw = await page.$$eval('[data-homeaheadpow]', (xs) => xs.map((x) => ({ v: x.getAttribute('data-homeaheadpow'), tone: x.getAttribute('data-homeaheadpowtone'), c: getComputedStyle(x).color })));
  ok('1 · ⭐⭐⭐⭐⭐ every row carries my power rank (N/teams)', pw.length === 2 && pw.every((p) => /^\d+\/12$/.test(p.v)), pw.map((p) => p.v).join(' | '));
  ok('1a · ⭐⭐⭐⭐ and it is coloured by where I sit (green top third, red bottom third, ink between)', pw.every((p) => /pos|neg|ink/.test(p.tone)), pw.map((p) => p.tone).join(' '));
  const rt = await page.$$eval('[data-homeaheadrectone]', (xs) => xs.map((x) => x.getAttribute('data-homeaheadrectone')));
  ok('1b · ⭐⭐⭐⭐ a 6-2 record is green', rt.length === 2 && rt.every((t) => t === 'var(--pos)'), rt.join(' '));
  const hdr = await page.evaluate(() => document.body.innerText);
  ok('1c · the header names the column', /\bPow\b/i.test(hdr));

  /* ══ §2 ═══════════════════════════════════════════════════════════════════════════════════════ */
  console.log('\n== §2 projected hover: totals, benches, move arrows ==');
  await page.hover('[data-homeaheadproj="QB Crisis League"]'); await page.waitForTimeout(500);
  const card = await page.evaluate(() => { const c = document.querySelector('[data-wkcard]'); if (!c) return null;
    return { t: c.innerText, totals: c.querySelectorAll('[data-projtotal]').length, up: [...c.querySelectorAll('[data-projmove="start"]')].map((x) => x.textContent.trim()),
      down: [...c.querySelectorAll('[data-projmove="sit"]')].map((x) => x.textContent.trim()) }; });
  ok('2 · ⭐⭐⭐⭐⭐ a Total row under each team', !!card && card.totals === 2, card ? card.totals : 'no card');
  ok('2a · ⭐⭐⭐⭐⭐ the benches follow, under a BENCH line', !!card && /BENCH/.test(card.t) && card.t.indexOf('BENCH') > card.t.indexOf('Total'));
  ok('2b · ⭐⭐⭐⭐⭐ an up arrow on the bench man who should start (Irving into the empty RB slot)', !!card && card.up.some((x) => /Bucky Irving/.test(x)), card ? card.up.join(', ') : '');
  ok('2c · ⭐⭐⭐ and the note says which moves the arrows are', !!card && /Irving in/.test(card.t), card ? card.t.split('\n').slice(-2).join(' / ').slice(0, 160) : '');
  await page.context().close();
}

/* ══ §3 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §3 Matchup: an RB is never swapped for a kicker ==');
await post('/stub/reset');
{
  const page = await open([LQ], { route: 'teamHub', activeId: null, hubLeagueId: 'hub-lg-qb' });
  await page.waitForSelector('[data-hubnav]', { timeout: 30000 }); await page.waitForTimeout(2200);
  await page.click('[data-hubgroup="team"]'); await page.waitForTimeout(300);
  await page.click('[data-hubtabbtn="lineup"]'); await page.waitForTimeout(900);
  const sw = await page.$$eval('[data-myswap]', (xs) => xs.map((x) => x.getAttribute('data-myswap')));
  ok('3 · ⭐⭐⭐⭐⭐ Bucky Irving is suggested INTO the empty RB slot', sw.some((x) => /^Bucky Irving>empty RB/.test(x)), sw.join(' | '));
  ok('3a · ⭐⭐⭐⭐⭐ and nobody is ever suggested for the kicker except a kicker', !sw.some((x) => /Brandon Aubrey/.test(x) && !/^[^>]*\bK\b/.test(x)), sw.join(' | '));
  await page.context().close();
}

/* ══ §4 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §4 calculator: a free QB better than the one you trade for ==');
await post('/stub/reset');
{
  const byId = new Map(PACK.players.map((p) => [p.id, p]));
  const me = HUB.teams.find((t) => t.rosterId === HUB.myRosterId);
  const myWR1 = me.players.map((id) => byId.get(id)).filter((p) => p && p.pos === 'WR').sort((a, b) => a.adp - b.adp)[0];
  const t11 = HUB.teams.find((t) => t.rosterId === 11);
  const tua = t11.players.map((id) => byId.get(id)).filter((p) => p && p.pos === 'QB').sort((a, b) => b.adp - a.adp)[0];
  const injuries = { '90071': { status: 'season', weeks: 0, at: Date.now(), setWeek: HUB.week }, '90092': { status: 'season', weeks: 0, at: Date.now(), setWeek: HUB.week } };
  const page = await (await b.newContext({ viewport: { width: 1450, height: 1500 } })).newPage();
  page.on('pageerror', (e) => errs.push(String(e)));
  await page.goto(APP, { waitUntil: 'domcontentloaded' });
  await page.evaluate(([l, inj]) => { localStorage.clear(); localStorage.setItem('fdc:token', 't'); localStorage.setItem('fdcTourSeen', '1');
    localStorage.setItem('fdc:gs-state', JSON.stringify({ user: { email: 'trey.rose@pirates.com', paid: true, admin: true, rankSets: [], sleeperUsername: 'trey', sleeperUserId: 's1', homeView: 'season' }, leagues: [l], funMocks: [], injuries: inj }));
    sessionStorage.setItem('gs-nav', JSON.stringify({ route: 'teamHub', activeId: null, hubLeagueId: 'hub-lg-qb' })); }, [LQ, injuries]);
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-hubnav]', { timeout: 30000 }); await page.waitForTimeout(2500);
  await page.click('[data-hubgroup="moves"]'); await page.click('[data-hubtabbtn="trades"]'); await page.click('[data-tsectab="calc"]'); await page.waitForTimeout(500);
  await (await page.$('select[data-tbside-select="b"]')).selectOption({ label: t11.teamName }); await page.waitForTimeout(600);
  await page.click(`[data-tbcol="give"] [data-tbplayer="${myWR1.name}"]`); await page.click(`[data-tbcol="get"] [data-tbplayer="${tua.name}"]`); await page.waitForTimeout(1500);
  const w = await page.evaluate(() => { const el = document.querySelector('[data-tbwire]'); const g = document.querySelector('[data-tbgrade]');
    return { who: el && el.getAttribute('data-tbwire'), call: g && g.getAttribute('data-tbcall'), grade: g && g.getAttribute('data-tbgrade'), diff: (document.querySelector('[data-tbgrade]') || {}).textContent }; });
  ok(`4 · ⭐⭐⭐⭐⭐ ${myWR1.name} for ${tua.name}: the calculator names the free QB you could add instead`, !!w.who && /Aaron Rodgers|Russell Wilson|Fernando Mendoza/.test(w.who), w.who || 'no wire block');
  ok('4a · ⭐⭐⭐⭐⭐ and tells you to use the wire, not make the trade', w.call === 'wire', `${w.grade} / ${w.call}`);
  await page.context().close();
}

/* ══ §5 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §5 My Week free agents: position upgrades, kicker included ==');
await post('/stub/reset');
{
  const page = await open([LQ], { route: 'home' });
  await inSeason(page);
  await page.waitForSelector('[data-wkview="fa"]', { timeout: 30000 }); await page.waitForTimeout(1500);
  await page.click('[data-wkview="fa"]'); await page.waitForTimeout(700);
  const rows = await page.$$eval('[data-wkfarow]', (xs) => xs.map((x) => ({ who: x.getAttribute('data-wkfarow'), kind: x.querySelector('[data-wkfakind]').getAttribute('data-wkfakind'),
    start: (x.querySelector('[data-wkfastart]') || { getAttribute: () => null }).getAttribute('data-wkfastart'),
    rel: (x.querySelector('[data-wkfarelease]') || { getAttribute: () => null }).getAttribute('data-wkfarelease'), t: x.innerText.replace(/\s+/g, ' ') })));
  const k = rows.filter((r) => r.kind === 'upgrade' && /Butker/.test(r.who));
  ok('5 · ⭐⭐⭐⭐⭐ my kicker outscored on waivers: one row, for the best free kicker', k.length === 1 && rows.filter((r) => r.kind === 'upgrade' && / K /.test(` ${r.t} `) && !/Butker/.test(r.who)).length === 0, rows.map((r) => `${r.kind}:${r.who}`).join(', '));
  ok('5a · ⭐⭐⭐⭐⭐ it names the kicker he starts over and the player you release', k[0] && k[0].start === 'Brandon Aubrey' && k[0].rel === 'Brandon Aubrey', k[0] ? `${k[0].start} / ${k[0].rel}` : '');
  const chip = await page.$('[data-wkfarow="Harrison Butker"] [data-wkfakind]');
  if (chip) { await chip.hover(); await page.waitForTimeout(400); }
  const alts = await cardText(page);
  /* 29bo moved this card to "every option beside your own man, with the next three weeks" — see plan29bo. */
  ok('5b · ⭐⭐⭐⭐⭐ hovering "Pos upgrade" lists the kickers next to the one I start', /Harrison Butker/.test(alts) && /Brandon Aubrey/.test(alts) && /THIS WEEK/i.test(alts), alts.split('\n').slice(0, 3).join(' / '));
  await page.mouse.move(5, 5);
  const wr = rows.find((r) => r.kind === 'upgrade' && /Keenan Allen/.test(r.who));
  ok('5c · ⭐⭐⭐⭐⭐ a receiver upgrade compares the pickup to the starter he replaces AND the bench player you release (a different man)', !!wr && !!wr.start && !!wr.rel && wr.start !== wr.rel && /Starts over/.test(wr.t) && /Release/.test(wr.t), wr ? `${wr.start} / ${wr.rel}` : rows.map((r) => r.who).join(','));
  ok('5d · ⭐⭐⭐ no IR player is ever the release', !rows.some((r) => r.rel === 'Christian Kirk'));
  await page.context().close();
}

/* ══ §6 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §6 Review: every score that week, with the median line ==');
await post('/stub/reset');
{
  const page = await open([L1], { route: 'home' });
  await inSeason(page, 'review'); await page.waitForTimeout(1500);
  await page.hover('[data-wkmedian]'); await page.waitForTimeout(400);
  const t = await cardText(page);
  const lines = t.split('\n');
  const nums = (t.match(/\b\d{2,3}\.\d\b/g) || []).map(Number);
  ok('6 · ⭐⭐⭐⭐⭐ hovering vs median lists every team, highest first, with me marked', /\(you\)/.test(t) && /Allegheny Anchors/.test(t) && lines.some((l) => /MEDIAN 99/.test(l)), lines.slice(0, 4).join(' / '));
  const i120 = t.indexOf('120.3'), iMed = t.indexOf('MEDIAN'), i88 = t.indexOf('88.8');
  ok('6a · ⭐⭐⭐⭐ the median line sits between the top half and the bottom half', i120 > -1 && iMed > i120 && i88 > iMed);
  await page.mouse.move(5, 5); await page.waitForTimeout(200);
  await page.hover('[data-wkfield]'); await page.waitForTimeout(400);
  ok('6b · the same list on the vs field cell', /MEDIAN/.test(await cardText(page)));
  await page.context().close();
}

ok('7 · nothing threw', errs.length === 0, errs.slice(0, 2).join(' || ').slice(0, 200));
await b.close();
console.log(`\n  ${pass} PASS  ${fail} FAIL`);
process.exit(fail ? 1 : 0);
