/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   TREY'S 29bp NOTES — plan29bp (setup copied from plan29bo)
     §1 "On the 'starter out' ones, I also want to see alternatives on there."
     §2 "Harrison Mevis is my kicker in a league and in the last update it was recommending an upgrade... after
        this update, nothing is coming up for that league" — a starter with NO projection
     §3 "I see a lot of defense and kicker recommendations, but not a ton of position players... I do want to
        ultimately compare against the starting lineup, but we should also compare against the bench too."
     §4 "For the review, you can just combine the head to head and median if it's a median league."
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29bo header follows)
   TREY'S 29bo NOTES — plan29bo (setup copied from plan29bn)
     §1 the "Pos upgrade" hover: my own player in the list, highlighted, and the next three weeks beside this
        one — "I see +7 for DST, but I don't see my defense in there to compare them... it might also be
        helpful to see the next 3 weeks... particularly important for defenses for matchups"
     §2 the Review tab: my season record per league and across every league, "the macro view mixed with the
        weekly view"
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29bn header follows)
   TREY'S 29bn NOTES — plan29bn (setup copied from plan29bm; the 29bm header below is kept for the helpers)
     §1 home This week: a Power column, record and power coloured by how I'm doing
     §2 the projected hover: a total under each team, the benches, arrows for who should move
     §3 Matchup: "start Bucky Irving (RB) for Harrison Mevis (K)" — an RB goes into the empty RB slot
     §4 calculator: a free-agent QB better than the QB I'm trading for still shows as "pick him up instead"
     §5 My Week free agents: a kicker outscored on waivers, one row + alternatives on hover; the player you'd
        start over AND the one you'd release
     §6 Review: hover vs median / vs field for every team's score, highest first, with the median line
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29bm header follows)
   TREY'S 29bm NOTES — plan29bm
     §1 Home "This week": "it isn't showing my record for each league", "my combined record through every
        league", "what do the red, yellow, and green dots... mean", "when you hover the projected score, I'd
        like to see a side by side of each team and the projected score".
     §2 Matchup: a starter traded away last week still in the lineup (Sleeper seeds the new week from the
        old one) must not show.
     §3 Hub free agents: "Higgins is on my IR... We should just ignore IR players for FA purposes."
     §4 My Week free agents: "I just lost... my 2 QBs... At a very minimum, that league should be
        recommending I pick up a QB."
     §5 My Week league activity: "show the trade grades next to each trade", the same letter the hub gives.
     §6 Game Day: "0-0-10... change these numbers to reflect the projections (and make it clear...)".
     §7 Review: hover the verdict chip for why; hover the result for both lineups side by side.
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import { chromium } from 'playwright';
import fs from 'node:fs';
const APP = 'http://localhost:4174/', STUB = 'http://localhost:5055';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { console.log(`  ${c ? 'PASS' : 'FAIL'}  ${n}${x !== '' ? `   [${x}]` : ''}`); c ? pass++ : fail++; };
const post = (p, b) => fetch(STUB + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b || {}) }).then((r) => r.json()).catch(() => null);
const CFG = { teams: 12, rounds: 15, slot: 1, type: 'redraft', sf: false, tePremMult: 0, order: 'snake',
  start: { QB: 1, RB: 2, WR: 2, TE: 1, FLEX: 1, SUPER: 0, K: 1, DST: 1 }, scoring: { rec: 1 }, caps: {}, keepers: [] };
const lg = (id, name, lid) => { const c = { platform: 'sleeper', leagueId: lid, username: 'trey', ownerUsername: 'trey' };
  return { id, name, created: 'x', cfg: { ...CFG, name, connect: c }, picks: [], preds: [], mocks: [], connect: c, sleeperLeagueId: lid }; };
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const errs = [];
const open = async (leagues, route, vp = { width: 1450, height: 1100 }) => {
  const page = await (await b.newContext({ viewport: vp })).newPage();
  page.on('pageerror', (e) => errs.push(String(e)));
  await page.goto(APP, { waitUntil: 'domcontentloaded' });
  await page.evaluate(([l, r]) => { localStorage.clear(); localStorage.setItem('fdc:token', 't'); localStorage.setItem('fdcTourSeen', '1');
    localStorage.setItem('fdc:gs-state', JSON.stringify({ user: { email: 'trey.rose@pirates.com', paid: true, admin: true, rankSets: [], sleeperUsername: 'trey', sleeperUserId: 's1', homeView: 'season' }, leagues: l, funMocks: [] }));
    sessionStorage.setItem('gs-nav', JSON.stringify(r)); }, [leagues, route]);
  await page.reload({ waitUntil: 'domcontentloaded' });
  return page;
};
/* My Week / Game Day / Review are not restored from the session, so walk in through the home menu. */
const inSeason = async (page, tab) => {
  await page.waitForSelector('button.menuitem', { state: 'attached', timeout: 30000 }); await page.waitForTimeout(800);
  await page.evaluate(() => {
    const btn = Array.from(document.querySelectorAll('button.menuitem')).find((e) => /my week/i.test((e.innerText || '').trim()))
      || Array.from(document.querySelectorAll('button')).find((e) => /^\s*My week\s*$/i.test(e.innerText || ''));
    if (btn) btn.click();
  });
  await page.waitForSelector('[data-inseasontabs]', { timeout: 30000 });
  if (tab) { await page.click(`button[data-inseasontab="${tab}"]`); }
  await page.waitForTimeout(1500);
};
const cardText = (page) => page.$eval('[data-wkcard]', (x) => x.innerText).catch(() => '');
const LK = lg('HK', 'Blank Kicker League', 'hub-lg-nk');
const L1 = lg('H1', 'Hub Fixture League', 'hub-lg-1'), L2 = lg('H2', 'Superflex 3WR League', 'hub-lg-2'), LQ = lg('HQ', 'QB Crisis League', 'hub-lg-qb');


const PACK = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-pack.json', import.meta.url), 'utf8'));
const HUB = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-hub.json', import.meta.url), 'utf8'));



const faRows = async (page) => page.$$eval('[data-wkfarow]', (xs) => xs.map((x) => ({
  who: x.getAttribute('data-wkfarow'), kind: x.querySelector('[data-wkfakind]').getAttribute('data-wkfakind'),
  start: (x.querySelector('[data-wkfastart]') || { getAttribute: () => null }).getAttribute('data-wkfastart'),
  bench: (x.querySelector('[data-wkfabench]') || { getAttribute: () => null }).getAttribute('data-wkfabench'),
  rel: (x.querySelector('[data-wkfarelease]') || { getAttribute: () => null }).getAttribute('data-wkfarelease'),
  t: x.innerText.replace(/\s+/g, ' ') })));

/* ══ §1 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §1 "Starter out" rows carry alternatives too ==');
await post('/stub/reset');
{
  const page = await open([LQ], { route: 'home' });
  await inSeason(page);
  await page.waitForSelector('[data-wkview="fa"]', { timeout: 30000 }); await page.waitForTimeout(1500);
  await page.click('[data-wkview="fa"]'); await page.waitForTimeout(800);
  const rows = await faRows(page);
  const hole = rows.find((r) => r.kind === 'hole');
  ok('1 · (fixture) a Starter out row (both my QBs are gone)', !!hole && /Rodgers/.test(hole.who), rows.map((r) => `${r.kind}:${r.who}`).join(', '));
  await page.hover(`[data-wkfarow="${hole.who}"] [data-wkfakind]`); await page.waitForTimeout(500);
  const card = await page.evaluate(() => { const c = document.querySelector('[data-wkcard]'); if (!c) return null;
    return { t: c.innerText, mine: (c.querySelector('[data-wkaltmine]') || {}).textContent || null, head: [...c.querySelectorAll('th')].map((h) => h.textContent) }; });
  ok('1a · ⭐⭐⭐⭐⭐ hovering it lists the other free agents who could fill the hole', !!card && /Russell Wilson|Fernando Mendoza/.test(card.t), card ? card.t.split('\n').slice(2, 5).join(' / ') : 'no card');
  ok('1b · ⭐⭐⭐⭐⭐ with my own man (the one who would otherwise start) marked, and the next three weeks', !!card && !!card.mine && card.head.filter((h) => /^Wk \d+$/.test(h)).length === 3, card ? `${card.mine} | ${card.head.join(' ')}` : '');
  await page.context().close();
}

/* ══ §2 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §2 a kicker Sleeper has not projected still gets a recommendation ==');
await post('/stub/reset');
{
  const page = await open([LK], { route: 'home' });
  await inSeason(page);
  await page.waitForSelector('[data-wkview="fa"]', { timeout: 30000 }); await page.waitForTimeout(1500);
  await page.click('[data-wkview="fa"]'); await page.waitForTimeout(800);
  const rows = await faRows(page);
  const k = rows.find((r) => /Butker/.test(r.who));
  ok('2 · ⭐⭐⭐⭐⭐ my kicker has no projection at all and the league still recommends a kicker', !!k, rows.map((r) => `${r.kind}:${r.who}`).join(', ') || 'no rows at all');
  ok('2a · ⭐⭐⭐⭐ and the row says why, naming my man', !!k && /Aubrey/.test(k.t), k ? k.t.slice(0, 150) : '');

  /* ══ §3 ═══════════════════════════════════════════════════════════════════════════════════════ */
  console.log('\n== §3 the bench comparison, which is where the running backs live ==');
  const d = rows.find((r) => r.kind === 'depth');
  ok('3 · ⭐⭐⭐⭐⭐ a free running back who beats my BEST BACKUP (not my starter) is a "Bench upgrade" row', !!d && d.pos !== 'K', d ? d.t.slice(0, 170) : rows.map((r) => `${r.kind}:${r.who}`).join(', '));
  ok('3a · ⭐⭐⭐⭐⭐ it compares him to the backup he replaces AND to my lineup, and names the release', !!d && !!d.bench && /Better than/.test(d.t) && /Your lineup/.test(d.t) && !!d.rel, d ? `${d.bench} / ${d.rel}` : '');
  ok('3b · ⭐⭐⭐⭐ depth claims never fire for a kicker or a defence', !rows.some((r) => r.kind === 'depth' && /(D\/ST|Butker|Aubrey)/.test(r.who)));
  await page.context().close();
}

/* ══ §4 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §4 Review: one record in a median league ==');
await post('/stub/reset');
{
  const page = await open([L1, L2], { route: 'home' });
  await inSeason(page, 'review'); await page.waitForTimeout(2000);
  const per = await page.$$eval('[data-wkseason]', (xs) => xs.map((x) => x.getAttribute('data-wkseason')));
  ok('4 · ⭐⭐⭐⭐⭐ the league record is the head to head AND the median games in one number (1-1 plus 1-0 = 2-1)', per.length >= 2 && per.every((v) => v === '2-1'), per.join(' | '));
  const cell = await page.$eval('[data-wkseason]', (x) => ({ t: x.textContent.replace(/\s+/g, ' ').trim(), title: x.getAttribute('title') }));
  ok('4a · ⭐⭐⭐⭐ the cell marks it as a median league and the hover splits the two halves', /med/i.test(cell.t) && /head to head/i.test(cell.title || '') && /median/i.test(cell.title || ''), `${cell.t} · ${(cell.title || '').slice(0, 110)}`);
  const tot = await page.$eval('[data-wkseasontotal]', (x) => ({ v: x.getAttribute('data-wkseasontotal'), t: x.closest('[data-wktile]').innerText.replace(/\s+/g, ' ') }));
  ok('4b · ⭐⭐⭐⭐⭐ and the tile adds those up rather than keeping a separate median line', tot.v === '4-2' && !/plus/i.test(tot.t), `${tot.v} · ${tot.t}`);
  await page.context().close();
}

ok('5 · nothing threw', errs.length === 0, errs.slice(0, 2).join(' || ').slice(0, 200));
await b.close();
console.log(`\n  ${pass} PASS  ${fail} FAIL`);
process.exit(fail ? 1 : 0);
