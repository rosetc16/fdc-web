/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   TREY'S 29bq NOTES — plan29bq (setup copied from plan29bp)
     "I think the Mevis problem still exists. He isn't listed as a replacement despite the following facts:
      Mevis 6.7 / 6.92 / 6.92, Spencer Shrader 7.12 / 7.32 / 7.32, Tyler Loop 7.04 / 6.72 / 6.72, Harrison
      Butker 6.93 / 6.32 / BYE (but he is also the K3 in the league and put up 7 and 16 in the first 2)."
     §1 a kicker who is ahead in EVERY week, by a fraction each time, is a recommendation
     §2 the row says what the case is (the three-week gain), and a kicker who is only ahead this week is not
        promoted over him
     §3 the card carries what each man has ACTUALLY scored per game this season
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29bp header follows)
   TREY'S 29bp NOTES — plan29bp (setup copied from plan29bo)
     §1 "On the 'starter out' ones, I also want to see alternatives on there."
     §2 "Harrison Mevis is my kicker in a league and in the last update it was recommending an upgrade... after
        this update, nothing is coming up for that league" — a starter with NO projection
     §3 "I see a lot of defense and kicker recommendations, but not a ton of position players... I do want to
        ultimately compare against the starting lineup, but we should also compare against the bench too."
     §4 "For the review, you can just combine the head to head and median if it's a median league."
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29bo header follows)
   TREY'S 29bo NOTES — plan29bo (setup copied from plan29bn)
     §1 the "Pos upgrade" hover: my own player in the list, highlighted, and the next three weeks beside this
        one — "I see +7 for DST, but I don't see my defense in there to compare them... it might also be
        helpful to see the next 3 weeks... particularly important for defenses for matchups"
     §2 the Review tab: my season record per league and across every league, "the macro view mixed with the
        weekly view"
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29bn header follows)
   TREY'S 29bn NOTES — plan29bn (setup copied from plan29bm; the 29bm header below is kept for the helpers)
     §1 home This week: a Power column, record and power coloured by how I'm doing
     §2 the projected hover: a total under each team, the benches, arrows for who should move
     §3 Matchup: "start Bucky Irving (RB) for Harrison Mevis (K)" — an RB goes into the empty RB slot
     §4 calculator: a free-agent QB better than the QB I'm trading for still shows as "pick him up instead"
     §5 My Week free agents: a kicker outscored on waivers, one row + alternatives on hover; the player you'd
        start over AND the one you'd release
     §6 Review: hover vs median / vs field for every team's score, highest first, with the median line
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29bm header follows)
   TREY'S 29bm NOTES — plan29bm
     §1 Home "This week": "it isn't showing my record for each league", "my combined record through every
        league", "what do the red, yellow, and green dots... mean", "when you hover the projected score, I'd
        like to see a side by side of each team and the projected score".
     §2 Matchup: a starter traded away last week still in the lineup (Sleeper seeds the new week from the
        old one) must not show.
     §3 Hub free agents: "Higgins is on my IR... We should just ignore IR players for FA purposes."
     §4 My Week free agents: "I just lost... my 2 QBs... At a very minimum, that league should be
        recommending I pick up a QB."
     §5 My Week league activity: "show the trade grades next to each trade", the same letter the hub gives.
     §6 Game Day: "0-0-10... change these numbers to reflect the projections (and make it clear...)".
     §7 Review: hover the verdict chip for why; hover the result for both lineups side by side.
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import { chromium } from 'playwright';
import fs from 'node:fs';
const APP = 'http://localhost:4174/', STUB = 'http://localhost:5055';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { console.log(`  ${c ? 'PASS' : 'FAIL'}  ${n}${x !== '' ? `   [${x}]` : ''}`); c ? pass++ : fail++; };
const post = (p, b) => fetch(STUB + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b || {}) }).then((r) => r.json()).catch(() => null);
const CFG = { teams: 12, rounds: 15, slot: 1, type: 'redraft', sf: false, tePremMult: 0, order: 'snake',
  start: { QB: 1, RB: 2, WR: 2, TE: 1, FLEX: 1, SUPER: 0, K: 1, DST: 1 }, scoring: { rec: 1 }, caps: {}, keepers: [] };
const lg = (id, name, lid) => { const c = { platform: 'sleeper', leagueId: lid, username: 'trey', ownerUsername: 'trey' };
  return { id, name, created: 'x', cfg: { ...CFG, name, connect: c }, picks: [], preds: [], mocks: [], connect: c, sleeperLeagueId: lid }; };
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const errs = [];
const open = async (leagues, route, vp = { width: 1450, height: 1100 }) => {
  const page = await (await b.newContext({ viewport: vp })).newPage();
  page.on('pageerror', (e) => errs.push(String(e)));
  await page.goto(APP, { waitUntil: 'domcontentloaded' });
  await page.evaluate(([l, r]) => { localStorage.clear(); localStorage.setItem('fdc:token', 't'); localStorage.setItem('fdcTourSeen', '1');
    localStorage.setItem('fdc:gs-state', JSON.stringify({ user: { email: 'trey.rose@pirates.com', paid: true, admin: true, rankSets: [], sleeperUsername: 'trey', sleeperUserId: 's1', homeView: 'season' }, leagues: l, funMocks: [] }));
    sessionStorage.setItem('gs-nav', JSON.stringify(r)); }, [leagues, route]);
  await page.reload({ waitUntil: 'domcontentloaded' });
  return page;
};
/* My Week / Game Day / Review are not restored from the session, so walk in through the home menu. */
const inSeason = async (page, tab) => {
  await page.waitForSelector('button.menuitem', { state: 'attached', timeout: 30000 }); await page.waitForTimeout(800);
  await page.evaluate(() => {
    const btn = Array.from(document.querySelectorAll('button.menuitem')).find((e) => /my week/i.test((e.innerText || '').trim()))
      || Array.from(document.querySelectorAll('button')).find((e) => /^\s*My week\s*$/i.test(e.innerText || ''));
    if (btn) btn.click();
  });
  await page.waitForSelector('[data-inseasontabs]', { timeout: 30000 });
  if (tab) { await page.click(`button[data-inseasontab="${tab}"]`); }
  await page.waitForTimeout(1500);
};
const cardText = (page) => page.$eval('[data-wkcard]', (x) => x.innerText).catch(() => '');
const LK = lg('HK', 'Blank Kicker League', 'hub-lg-nk');
const LM = lg('HM', 'Kicker Margins League', 'hub-lg-mev');
const L1 = lg('H1', 'Hub Fixture League', 'hub-lg-1'), L2 = lg('H2', 'Superflex 3WR League', 'hub-lg-2'), LQ = lg('HQ', 'QB Crisis League', 'hub-lg-qb');


const PACK = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-pack.json', import.meta.url), 'utf8'));
const HUB = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-hub.json', import.meta.url), 'utf8'));



const faRows = async (page) => page.$$eval('[data-wkfarow]', (xs) => xs.map((x) => ({
  who: x.getAttribute('data-wkfarow'), kind: x.querySelector('[data-wkfakind]').getAttribute('data-wkfakind'),
  hz: (x.querySelector('[data-wkfahorizon]') || { getAttribute: () => null }).getAttribute('data-wkfahorizon'),
  start: (x.querySelector('[data-wkfastart]') || { getAttribute: () => null }).getAttribute('data-wkfastart'),
  t: x.innerText.replace(/\s+/g, ' ') })));

console.log('\n== §1-3 the kicker margins league: 6.7/6.92/6.92 against 7.12/7.32/7.32 ==');
await post('/stub/reset');
{
  const page = await open([LM], { route: 'home' });
  await inSeason(page);
  await page.waitForSelector('[data-wkview="fa"]', { timeout: 30000 }); await page.waitForTimeout(1800);
  await page.click('[data-wkview="fa"]'); await page.waitForTimeout(900);
  const rows = await faRows(page);
  const k = rows.find((r) => /Bates/.test(r.who));
  ok('1 · ⭐⭐⭐⭐⭐ the kicker who is ahead in every week (by 0.42, 0.40, 0.40) IS recommended', !!k && k.kind === 'upgrade',
    rows.map((r) => `${r.kind}:${r.who}`).join(', ') || 'no rows at all');
  ok('1a · ⭐⭐⭐⭐⭐ and the row makes the three-week case, not a one-week one', !!k && Number(k.hz) > 1 && Number(k.hz) < 2 && /every one of them/i.test(k.t), k ? `${k.hz} · ${k.t.slice(0, 150)}` : '');
  ok('2 · ⭐⭐⭐⭐ the kicker who is only ahead THIS week does not get his own row', !rows.some((r) => /Dicker/.test(r.who)), rows.map((r) => r.who).join(', '));
  ok('2a · ⭐⭐⭐⭐ one kicker row, not three', rows.filter((r) => r.kind === 'upgrade' && /(Bates|Dicker|Butker)/.test(r.who)).length === 1);
  await page.hover(`[data-wkfarow="${k.who}"] [data-wkfakind]`); await page.waitForTimeout(500);
  const card = await page.evaluate(() => { const c = document.querySelector('[data-wkcard]'); if (!c) return null;
    return { t: c.innerText, head: [...c.querySelectorAll('th')].map((h) => h.textContent), mine: (c.querySelector('[data-wkaltmine]') || {}).textContent || null }; });
  ok('3 · ⭐⭐⭐⭐⭐ the card carries what each man has actually scored a game this season', !!card && card.head.some((h) => /So far/i.test(h)) && /\d+\.\d\s*\/\d+g/.test(card.t.replace(/\s+/g, ' ')), card ? card.head.join(' | ') : 'no card');
  ok('3a · ⭐⭐⭐⭐ Butker is in the card with his record, even though his bye keeps him off the list', !!card && /Butker/.test(card.t), card ? (card.t.split('\n').find((l) => /Butker/.test(l)) || '').replace(/\s+/g, ' ') : '');
  ok('3b · ⭐⭐⭐ my own kicker is still the gold row', !!card && /Aubrey/.test(card.mine || ''), card ? card.mine : '');
  await page.context().close();
}

/* the other leagues must not have become noisier */
console.log('\n== §4 the rule did not turn every position into a list ==');
await post('/stub/reset');
{
  const page = await open([LQ], { route: 'home' });
  await inSeason(page);
  await page.waitForSelector('[data-wkview="fa"]', { timeout: 30000 }); await page.waitForTimeout(1500);
  await page.click('[data-wkview="fa"]'); await page.waitForTimeout(800);
  const rows = await faRows(page);
  ok('4 · the QB crisis league still leads with the Starter out row', rows[0] && rows[0].kind === 'hole', rows.map((r) => `${r.kind}:${r.who}`).join(', '));
  ok('4a · and the list stays short enough to act on', rows.length <= 8, String(rows.length));
  await page.context().close();
}

ok('5 · nothing threw', errs.length === 0, errs.slice(0, 2).join(' || ').slice(0, 200));
await b.close();
console.log(`\n  ${pass} PASS  ${fail} FAIL`);
process.exit(fail ? 1 : 0);
