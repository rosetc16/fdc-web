/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   TREY'S 29bo NOTES — plan29bo (setup copied from plan29bn)
     §1 the "Pos upgrade" hover: my own player in the list, highlighted, and the next three weeks beside this
        one — "I see +7 for DST, but I don't see my defense in there to compare them... it might also be
        helpful to see the next 3 weeks... particularly important for defenses for matchups"
     §2 the Review tab: my season record per league and across every league, "the macro view mixed with the
        weekly view"
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29bn header follows)
   TREY'S 29bn NOTES — plan29bn (setup copied from plan29bm; the 29bm header below is kept for the helpers)
     §1 home This week: a Power column, record and power coloured by how I'm doing
     §2 the projected hover: a total under each team, the benches, arrows for who should move
     §3 Matchup: "start Bucky Irving (RB) for Harrison Mevis (K)" — an RB goes into the empty RB slot
     §4 calculator: a free-agent QB better than the QB I'm trading for still shows as "pick him up instead"
     §5 My Week free agents: a kicker outscored on waivers, one row + alternatives on hover; the player you'd
        start over AND the one you'd release
     §6 Review: hover vs median / vs field for every team's score, highest first, with the median line
   ══════════════════════════════════════════════════════════════════════════════════════════════════
   (29bm header follows)
   TREY'S 29bm NOTES — plan29bm
     §1 Home "This week": "it isn't showing my record for each league", "my combined record through every
        league", "what do the red, yellow, and green dots... mean", "when you hover the projected score, I'd
        like to see a side by side of each team and the projected score".
     §2 Matchup: a starter traded away last week still in the lineup (Sleeper seeds the new week from the
        old one) must not show.
     §3 Hub free agents: "Higgins is on my IR... We should just ignore IR players for FA purposes."
     §4 My Week free agents: "I just lost... my 2 QBs... At a very minimum, that league should be
        recommending I pick up a QB."
     §5 My Week league activity: "show the trade grades next to each trade", the same letter the hub gives.
     §6 Game Day: "0-0-10... change these numbers to reflect the projections (and make it clear...)".
     §7 Review: hover the verdict chip for why; hover the result for both lineups side by side.
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import { chromium } from 'playwright';
import fs from 'node:fs';
const APP = 'http://localhost:4174/', STUB = 'http://localhost:5055';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { console.log(`  ${c ? 'PASS' : 'FAIL'}  ${n}${x !== '' ? `   [${x}]` : ''}`); c ? pass++ : fail++; };
const post = (p, b) => fetch(STUB + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b || {}) }).then((r) => r.json()).catch(() => null);
const CFG = { teams: 12, rounds: 15, slot: 1, type: 'redraft', sf: false, tePremMult: 0, order: 'snake',
  start: { QB: 1, RB: 2, WR: 2, TE: 1, FLEX: 1, SUPER: 0, K: 1, DST: 1 }, scoring: { rec: 1 }, caps: {}, keepers: [] };
const lg = (id, name, lid) => { const c = { platform: 'sleeper', leagueId: lid, username: 'trey', ownerUsername: 'trey' };
  return { id, name, created: 'x', cfg: { ...CFG, name, connect: c }, picks: [], preds: [], mocks: [], connect: c, sleeperLeagueId: lid }; };
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const errs = [];
const open = async (leagues, route, vp = { width: 1450, height: 1100 }) => {
  const page = await (await b.newContext({ viewport: vp })).newPage();
  page.on('pageerror', (e) => errs.push(String(e)));
  await page.goto(APP, { waitUntil: 'domcontentloaded' });
  await page.evaluate(([l, r]) => { localStorage.clear(); localStorage.setItem('fdc:token', 't'); localStorage.setItem('fdcTourSeen', '1');
    localStorage.setItem('fdc:gs-state', JSON.stringify({ user: { email: 'trey.rose@pirates.com', paid: true, admin: true, rankSets: [], sleeperUsername: 'trey', sleeperUserId: 's1', homeView: 'season' }, leagues: l, funMocks: [] }));
    sessionStorage.setItem('gs-nav', JSON.stringify(r)); }, [leagues, route]);
  await page.reload({ waitUntil: 'domcontentloaded' });
  return page;
};
/* My Week / Game Day / Review are not restored from the session, so walk in through the home menu. */
const inSeason = async (page, tab) => {
  await page.waitForSelector('button.menuitem', { state: 'attached', timeout: 30000 }); await page.waitForTimeout(800);
  await page.evaluate(() => {
    const btn = Array.from(document.querySelectorAll('button.menuitem')).find((e) => /my week/i.test((e.innerText || '').trim()))
      || Array.from(document.querySelectorAll('button')).find((e) => /^\s*My week\s*$/i.test(e.innerText || ''));
    if (btn) btn.click();
  });
  await page.waitForSelector('[data-inseasontabs]', { timeout: 30000 });
  if (tab) { await page.click(`button[data-inseasontab="${tab}"]`); }
  await page.waitForTimeout(1500);
};
const cardText = (page) => page.$eval('[data-wkcard]', (x) => x.innerText).catch(() => '');
const L1 = lg('H1', 'Hub Fixture League', 'hub-lg-1'), L2 = lg('H2', 'Superflex 3WR League', 'hub-lg-2'), LQ = lg('HQ', 'QB Crisis League', 'hub-lg-qb');


const PACK = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-pack.json', import.meta.url), 'utf8'));
const HUB = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-hub.json', import.meta.url), 'utf8'));


/* ══ §1 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §1 the Pos upgrade hover: your own man, and the next three weeks ==');
await post('/stub/reset');
{
  const page = await open([LQ], { route: 'home' });
  await inSeason(page);
  await page.waitForSelector('[data-wkview="fa"]', { timeout: 30000 }); await page.waitForTimeout(1500);
  await page.click('[data-wkview="fa"]'); await page.waitForTimeout(800);
  const rows = await page.$$eval('[data-wkfarow]', (xs) => xs.map((x) => x.getAttribute('data-wkfarow')));
  const def = rows.find((n) => /D\/ST|Defense|D\/S/.test(n));
  ok('1 · (fixture) my defence is outscored on the wire, so there is a defence row', !!def, rows.join(', '));
  await page.hover(`[data-wkfarow="${def}"] [data-wkfakind]`); await page.waitForTimeout(500);
  const card = await page.evaluate(() => { const c = document.querySelector('[data-wkcard]'); if (!c) return null;
    return { t: c.innerText, mine: (c.querySelector('[data-wkaltmine]') || {}).textContent || null,
      mineColor: c.querySelector('[data-wkaltmine]') ? getComputedStyle(c.querySelector('[data-wkaltmine]')).color : null,
      head: [...c.querySelectorAll('th')].map((h) => h.textContent) }; });
  ok('1a · ⭐⭐⭐⭐⭐ my own defence is a row in the card, marked as mine', !!card && /Broncos/.test(card.mine || '') && /YOURS/.test(card.mine || ''), card ? card.mine : 'no card');
  ok('1b · ⭐⭐⭐⭐⭐ and it is drawn in the theme gold so it stands out', !!card && /rgb\(/.test(card.mineColor || ''), card ? card.mineColor : '');
  ok('1c · ⭐⭐⭐⭐⭐ three more weeks sit beside this one, with a three-week total', !!card && card.head.filter((h) => /^Wk \d+$/.test(h)).length === 3 && card.head.some((h) => /Next 3/i.test(h)), card ? card.head.join(' | ') : '');
  /* the fixture is built so the one-week wonder falls off and my own defence is the best team over three */
  const lines = (card ? card.t : '').split('\n');
  const mineLine = (lines.filter((l) => /Broncos/.test(l) && /\d/.test(l))[0] || '').replace(/\s+/g, ' ');
  const hotLine = (lines.find((l) => /D\/ST/.test(l) && !/Broncos/.test(l) && /\d/.test(l)) || '').replace(/\s+/g, ' ');
  const sum = (l) => Number((l.match(/([\d.]+)$/) || [])[1]);
  ok('1d · ⭐⭐⭐⭐⭐ the free defence that beats me THIS week is well behind over the next three', Number.isFinite(sum(mineLine)) && Number.isFinite(sum(hotLine)) && sum(mineLine) > sum(hotLine) + 10, `mine ${mineLine} || wire ${hotLine}`);
  ok('1e · ⭐⭐⭐ the note says what the gold row and the three-week column are for', /gold row/i.test(card ? card.t : '') && /one-week matchup/i.test(card ? card.t : ''), (card ? card.t : '').split('\n').slice(-1)[0].slice(0, 120));
  await page.context().close();
}

/* ══ §2 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §2 Review: the season record beside the week ==');
await post('/stub/reset');
{
  const page = await open([L1, L2], { route: 'home' });
  await inSeason(page, 'review'); await page.waitForTimeout(2000);
  const per = await page.$$eval('[data-wkseason]', (xs) => xs.map((x) => x.getAttribute('data-wkseason')));
  ok('2 · ⭐⭐⭐⭐⭐ every league row carries my season record', per.length >= 2 && per.every((v) => /^\d+-\d+/.test(v)), per.join(' | '));
  const tot = await page.$eval('[data-wkseasontotal]', (x) => ({ v: x.getAttribute('data-wkseasontotal'), t: x.closest('[data-wktile]').innerText.replace(/\s+/g, ' ') })).catch(() => null);
  /* 29bp folded the median half INTO the record (Trey: "you can just combine the head to head and median if
     it's a median league"), so the combined figure is 4-2 across these two median leagues. */
  ok('2a · ⭐⭐⭐⭐⭐ and a combined season record across every league, labelled with the week', !!tot && tot.v === '4-2' && /Season through week 2/i.test(tot.t), tot ? `${tot.v} · ${tot.t}` : 'no tile');
  ok('2b · ⭐⭐⭐⭐ the tile says the median games are in it', !!tot && /median games included/i.test(tot.t), tot ? tot.t : '');
  const hdr = await page.evaluate(() => document.body.innerText);
  ok('2c · the column is named', /season/i.test(hdr));
  await page.context().close();
}

ok('3 · nothing threw', errs.length === 0, errs.slice(0, 2).join(' || ').slice(0, 200));
await b.close();
console.log(`\n  ${pass} PASS  ${fail} FAIL`);
process.exit(fail ? 1 : 0);
