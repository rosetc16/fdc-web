/* THE FIVE THINGS TREY PICKED — b163, verified after the container loss.
 * ═══════════════════════════════════════════════════════════════════════════════════════════════════
 *   1. the 22 remaining remount sites — components declared during render, remounted every time
 *   2. cold-start honesty — a first load against a sleeping backend says so
 *   3. Yahoo transactions in the activity feed
 *   4. "Open to a deal" gets contention signal
 *   5. the phone pass on the dense screens
 *
 * ⚠⚠⚠⚠⚠ THE OLD HARNESS IS GONE AND THIS IS NOT A REPLACEMENT FOR IT. The container was reclaimed
 *   mid-session and took ~1,100 accumulated checks with it. This file covers THE WORK IN THIS BUILD and
 *   nothing else; the in-season hub, the draft room's deeper screens, the theme sweep and the legacy
 *   sweep are all unverified in a browser until the harness is rebuilt. Pretending otherwise by writing
 *   a thin pass over everything would be worse than the gap, because a green line nobody should trust is
 *   how a regression ships.
 *
 * ⚠ §1 IS THE ONE THAT MATTERS MOST AND LOOKS LEAST INTERESTING. Twenty-three components changed shape
 *   across four files. A build succeeding proves the syntax parsed; it says nothing about whether the
 *   screens still render. Every check in §1 is "this screen came up and nothing threw".
 */
import { chromium } from 'playwright';
const APP = 'http://localhost:4174/';       // the bundle that talks to the stub
const NOBE = 'http://localhost:4173/';      // the bundle with no backend at all
const STUB = 'http://localhost:5055';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { console.log('  PASS  ' + n + (x ? `   [${x}]` : '')); pass++; } else { console.log('  FAIL  ' + n + (x ? `   [${x}]` : '')); fail++; } };
const post = (p, b) => fetch(STUB + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b) }).then((r) => r.json()).catch(() => null);

const CFG = { teams: 12, rounds: 15, slot: 3, type: 'redraft', sf: false, tePremMult: 0, order: 'snake',
  start: { QB: 1, RB: 2, WR: 2, TE: 1, FLEX: 1, SUPER: 0, K: 1, DST: 1 }, scoring: { rec: 1 }, caps: {}, keepers: [] };
const lg = (id, name, lid, platform = 'sleeper') => ({
  id, name, created: 'x',
  cfg: { ...CFG, name, connect: { platform, leagueId: lid, leagueKey: platform === 'yahoo' ? lid : undefined, username: 'trey', ownerUsername: 'trey' } },
  picks: [], preds: [], mocks: [],
  connect: { platform, leagueId: lid, leagueKey: platform === 'yahoo' ? lid : undefined, username: 'trey', ownerUsername: 'trey' },
  sleeperLeagueId: platform === 'sleeper' ? lid : undefined });
const SLEEPER = [lg('L0', 'Pirates Dynasty Keeper', 'stub-league-1'), lg('L1', 'Second Squad', 'lg-1')];
const YAHOO = lg('Y0', 'Yahoo Dynasty', 'nfl.l.99', 'yahoo');

const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const errs = [];
const phone = () => b.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 });
const desk = () => b.newContext({ viewport: { width: 1450, height: 1600 } });

const seedInto = async (page, leagues, url = APP) => {
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.evaluate((l) => {
    try { localStorage.clear(); sessionStorage.clear(); } catch (e) {}
    localStorage.setItem('fdc:token', 't');
    localStorage.setItem('fdcTourSeen', '1');
    localStorage.setItem('fdc:gs-state', JSON.stringify({
      user: { email: 'trey.rose@pirates.com', paid: true, admin: true, rankSets: [], sleeperUsername: 'trey', sleeperUserId: 's1', homeView: 'season' },
      leagues: l, funMocks: [] }));
    sessionStorage.setItem('gs-nav', JSON.stringify({ route: 'home', activeId: null, hubLeagueId: null }));
  }, leagues);
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(15000);
  const d = page.getByText('Dismiss', { exact: false }).first();
  if (await d.count()) await d.click({ force: true }).catch(() => {});
  await page.waitForTimeout(1200);
};
const broke = (page) => page.evaluate(() => ({
  boundary: /Something went wrong|Something hiccuped|reload the page/i.test(document.body.innerText || ''),
  text: (document.body.innerText || '').replace(/\s+/g, ' ').slice(0, 90),
}));

await post('/stub/reset', {});
await fetch(`${STUB}/api/state`, { method: 'PUT', headers: { 'content-type': 'application/json' },
  body: JSON.stringify({ state: { leagues: SLEEPER, funMocks: [], feedback: [] } }) });

/* ══ §0 — CAN THE FIXTURE FAIL ═════════════════════════════════════════════════════════════════ */
console.log('\n== §0 is this fixture capable of failing? ==');
{
  const s = await fetch(`${STUB}/api/connect/sleeper/transactions?league_ids=stub-league-1,lg-1`).then((r) => r.json());
  const L = s.leagues[0];
  const rows = L.trends.rows;
  const streamer = rows.find((r) => !r.trades && (r.waivers + r.freeAgents) >= 5);
  const trader = rows.find((r) => r.trades === 1 && (r.waivers + r.freeAgents) === 0);
  ok('0 · ⭐⭐⭐⭐⭐ the league contains a manager who streams constantly and has NEVER traded',
    !!streamer, streamer ? `${streamer.teamName}: ${streamer.waivers}w/${streamer.freeAgents}fa, 0 trades` : 'NONE — §4 cannot fail');
  ok('0b · ⭐⭐⭐⭐⭐ …and raw move-count would rank him ABOVE a manager who traded, which is the wrong answer',
    !!streamer && !!trader && (streamer.waivers + streamer.freeAgents) > trader.trades,
    streamer && trader ? `${streamer.waivers + streamer.freeAgents} moves vs ${trader.trades}` : '—');
  ok('0c · ⭐⭐⭐⭐ a three-team trade is in the feed, which a give/get pair cannot render',
    L.items.some((x) => x.teams.length === 3));
  ok('0d · ⭐⭐⭐⭐ …and one league runs FAAB while the other runs waiver priority',
    s.leagues.map((x) => !!x.faab).join() === 'true,false');
  const y = await fetch(`${STUB}/api/connect/yahoo/transactions?league_keys=nfl.l.99`).then((r) => r.json());
  const st = new Set(y.leagues[0].items.map((x) => x.status));
  ok('0e · ⭐⭐⭐⭐⭐ the Yahoo fixture carries a PENDING and a REJECTED trade — what Sleeper cannot express',
    st.has('pending') && st.has('failed'), [...st].join(', '));
}

/* ══ §1 — EVERY SCREEN THE REMOUNT WORK TOUCHED STILL RENDERS ══════════════════════════════════ */
console.log('\n== §1 twenty-three components changed shape — do the screens still come up? ==');
{
  /* ⚠ THESE SCREENS NEED NO BACKEND, which is why they are driven against :4173. The app carries a
     built-in board, so the draft room, the guide, the marketing page and the trends page all render
     from local data — and between them they cover fifteen of the twenty-three conversions. */
  const ctx = await desk();
  const page = await ctx.newPage();
  page.on('pageerror', (e) => errs.push('nobackend: ' + String(e.message).slice(0, 140)));
  await page.goto(NOBE, { waitUntil: 'domcontentloaded' });
  await page.evaluate(() => { try { localStorage.clear(); localStorage.setItem('fdcTourSeen', '1'); } catch (e) {} });
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(14000);

  const land = await broke(page);
  ok('1 · ⭐⭐⭐⭐⭐ the app boots with no backend at all and nothing throws', !land.boundary, land.text);

  /* The marketing page's tabs — Overview / Draft Day / In-Season / Guide & Glossary. The guide is where
     `crumb` and `place` live, and the glossary is the densest thing on the public site. */
  const tabs = await page.evaluate(() => Array.from(document.querySelectorAll('button'))
    .map((e) => (e.innerText || '').trim()).filter((t) => /guide|glossary|in-season|draft day|overview/i.test(t)));
  ok('1b · ⭐⭐⭐ the public site still offers its tabs', tabs.length >= 2, tabs.slice(0, 5).join(' | '));
  for (const want of ['Guide', 'In-Season']) {
    await page.evaluate((w) => {
      const t = Array.from(document.querySelectorAll('button')).find((e) => new RegExp(w, 'i').test((e.innerText || '').trim()));
      if (t) t.click();
    }, want);
    await page.waitForTimeout(2500);
    const st = await broke(page);
    ok(`1c · ⭐⭐⭐⭐⭐ the "${want}" tab renders (crumb / place / the guide's breadcrumbs)`, !st.boundary, st.text);
  }
  /* ⚠ THE FIRST VERSION OF THIS CHECK LOOKED FOR `[data-guideplace]` ON THE PUBLIC PAGE AND WENT RED ON
     A BUILD THAT WAS FINE. The signed-out copy renders the guide's breadcrumbs as PLAIN TEXT on purpose
     — a reader with no app has nowhere to be routed to — so those attributes only exist inside Help.
     The check was asserting something that was never true of the surface it was pointed at, which is a
     suite bug accusing the product, and this project has paid for that one more than once.

     ⭐⭐⭐⭐⭐ SO IT POINTS AT THE DRAFT ROOM INSTEAD, which is a far better target anyway: the demo draft
     needs no backend and its two views exercise SEVEN of the twenty-three conversions between them —
     `trackChip` on the tracker strip, `pickChip`, `comboSlot`, `panelCard`, `pct`, `kvRow`, `headCol`.
     If any of those were still a component declared during render, or lost a `key`, this is where it
     shows. */
  await page.evaluate(() => {
    const t = Array.from(document.querySelectorAll('button,a')).find((e) => /demo/i.test(e.innerText || ''));
    if (t) t.click();
  });
  await page.waitForTimeout(12000);
  const room = await page.evaluate(() => ({
    boundary: /Something went wrong|Something hiccuped|reload the page/i.test(document.body.innerText || ''),
    cells: document.querySelectorAll('td').length,
    text: (document.body.innerText || '').replace(/\s+/g, ' ').slice(0, 70),
  }));
  ok('1d · ⭐⭐⭐⭐⭐ the demo draft room opens and the board fills',
    !room.boundary && room.cells > 100, `${room.cells} cells · ${room.text}`);
  /* The Simple view is where `panelCard`, `pct` and `comboSlot` render. */
  await page.evaluate(() => {
    const t = Array.from(document.querySelectorAll('button')).find((e) => /^\s*Simple\s*$/i.test((e.innerText || '').trim()));
    if (t) t.click();
  });
  await page.waitForTimeout(3500);
  const simple = await page.evaluate(() => ({
    boundary: /Something went wrong|Something hiccuped|reload the page/i.test(document.body.innerText || ''),
    slots: document.querySelectorAll('[data-comboslot]').length,
    txt: (document.body.innerText || '').replace(/\s+/g, ' '),
  }));
  ok('1e · ⭐⭐⭐⭐⭐ …and the Simple view renders its cards (panelCard / pct / comboSlot)',
    !simple.boundary && /Last picks|Your next picks|On the clock|Take him/i.test(simple.txt),
    simple.boundary ? 'ERROR BOUNDARY' : `${simple.slots} combo slots`);
  /* ⭐⭐⭐⭐ AND BACK, because a remount bug often only shows on the SECOND render of a subtree. */
  await page.evaluate(() => {
    const t = Array.from(document.querySelectorAll('button')).find((e) => /^\s*Complex\s*$/i.test((e.innerText || '').trim()));
    if (t) t.click();
  });
  await page.waitForTimeout(3000);
  const back = await broke(page);
  ok('1f · ⭐⭐⭐⭐⭐ …and switching back and forth does not break anything', !back.boundary, back.text);
  await ctx.close();
}

/* ══ §2 — COLD START ═══════════════════════════════════════════════════════════════════════════ */
console.log('\n== §2 "my account didn\'t transfer" — the first load of the day ==');
{
  await post('/stub/me-mode', { mode: 'hang' });
  const ctx = await phone();
  const page = await ctx.newPage();
  await page.goto(APP, { waitUntil: 'domcontentloaded' });
  /* A token and nothing else: a browser that has never seen this app. */
  await page.evaluate(() => { try { localStorage.clear(); localStorage.setItem('fdc:token', 't'); localStorage.setItem('fdcTourSeen', '1'); } catch (e) {} });
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(15000);
  const said = await page.evaluate(() => {
    const el = document.querySelector('[data-waking]');
    const txt = (document.body.innerText || '').replace(/\s+/g, ' ');
    return { state: el ? el.getAttribute('data-waking') : null,
      text: el ? (el.innerText || '').replace(/\s+/g, ' ').trim() : txt.slice(0, 150),
      offersConnect: /Connect a league|Connect Sleeper/i.test(txt),
      escape: !!document.querySelector('[data-wakingskip]') };
  });
  ok('2 · ⭐⭐⭐⭐⭐ a first load against a sleeping backend SAYS it is waking', said.state === 'pending', said.text.slice(0, 80));
  /* ⭐⭐⭐⭐⭐ THE THING THAT COST HIM THE RECONNECT. */
  ok('2b · ⭐⭐⭐⭐⭐ …and never invites him to connect an account it has not looked for yet',
    !said.offersConnect, String(said.offersConnect));
  /* ⚠ A FULL-SCREEN STATE WITH NO WAY PAST IT turns a slow server into a broken app. */
  ok('2c · ⭐⭐⭐⭐⭐ …and always leaves a door out of it', said.escape, String(said.escape));

  await post('/stub/me-mode', { mode: 'ok' });
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(16000);
  const after = await page.evaluate(() => {
    let blob = null; try { blob = JSON.parse(localStorage.getItem('fdc:gs-state') || '{}'); } catch (e) {}
    return { waking: !!document.querySelector('[data-waking]'),
      cached: blob && blob.user ? blob.user.sleeperUsername || null : null };
  });
  ok('2d · ⭐⭐⭐⭐ …and once the server answers the app comes up normally', !after.waking, String(after.waking));
  /* ⭐⭐⭐⭐⭐ THE 29az HALF, RE-PINNED: the answer is written down, so the SECOND load never re-asks. */
  ok('2e · ⭐⭐⭐⭐⭐ …with the Sleeper account cached on the device, so the next load cannot lose it',
    after.cached === 'trey', String(after.cached));
  await ctx.close();
}

/* ══ §3 — YAHOO IS IN THE FEED ═════════════════════════════════════════════════════════════════ */
console.log('\n== §3 the activity feed covers both platforms ==');
{
  const ctx = await desk();
  const page = await ctx.newPage();
  page.on('pageerror', (e) => errs.push('feed: ' + String(e.message).slice(0, 140)));
  await seedInto(page, [...SLEEPER, YAHOO]);
  await page.evaluate(() => {
    const btn = Array.from(document.querySelectorAll('button.menuitem')).find((e) => /my week/i.test((e.innerText || '').trim()))
      || Array.from(document.querySelectorAll('button')).find((e) => /^\s*My week\s*$/i.test(e.innerText || ''));
    if (btn) btn.click();
  });
  await page.waitForSelector('[data-wkviews]', { timeout: 60000 }).catch(() => {});
  await page.waitForTimeout(3000);
  await page.evaluate(() => { const c = document.querySelector('[data-wkview="moves"]'); if (c) c.click(); });
  await page.waitForSelector('[data-wkmoves]', { timeout: 45000 }).catch(() => {});
  await page.waitForTimeout(3500);
  await page.evaluate(() => { const el = document.querySelector('[data-wkmovescope="all"]'); if (el) el.click(); });
  await page.waitForTimeout(1500);

  const feed = await page.evaluate(() => {
    const rows = Array.from(document.querySelectorAll('[data-wkmove]'));
    const labelOf = (r) => ((r.querySelector('span') || {}).innerText || '').trim();
    const txt = (document.body.innerText || '').replace(/\s+/g, ' ');
    return { n: rows.length,
      leagues: [...new Set(rows.map(labelOf))].filter(Boolean),
      blank: rows.filter((r) => !labelOf(r)).length,
      note: (document.querySelector('[data-wkmovesnote]') || {}).innerText || '',
      uncovered: (document.querySelector('[data-wkmovesuncovered]') || {}).innerText || null,
      oldSentence: /publishes no transaction feed/i.test(txt) };
  });
  ok('3 · ⭐⭐⭐⭐⭐ the feed carries the Yahoo league as well as the Sleeper ones',
    feed.leagues.some((x) => /Yahoo/i.test(x)) && feed.leagues.some((x) => !/Yahoo/i.test(x)),
    feed.leagues.join(' | '));
  /* ⭐⭐⭐⭐⭐ THE BUG THE FIRST CUT SHIPPED: Yahoo rows with an EMPTY league column. They looked perfect
     and were useless on a feed whose whole job is to span twelve leagues. */
  ok('3b · ⭐⭐⭐⭐⭐ …and not one row is missing its league label', feed.blank === 0, `${feed.blank} of ${feed.n} blank`);
  /* ⭐⭐⭐⭐⭐ THE SENTENCE THAT WAS TRUE AND IS NOT ANY MORE. */
  ok('3c · ⭐⭐⭐⭐⭐ …and it no longer claims Yahoo publishes no transaction feed',
    !feed.oldSentence, feed.oldSentence ? 'STILL ON SCREEN' : 'gone');
  ok('3d · ⭐⭐⭐⭐⭐ …and the pending note says it is Yahoo only, on a mixed feed',
    /Yahoo/i.test(feed.note) && /Sleeper/i.test(feed.note), feed.note.replace(/\s+/g, ' ').slice(0, 100));
  ok('3e · ⭐⭐⭐⭐ …and nothing is listed as "not included" when both calls worked',
    !feed.uncovered, feed.uncovered || 'nothing excluded');

  /* ⭐⭐⭐⭐⭐ ONE PLATFORM FAILING MUST NOT EMPTY THE OTHER — the new way to produce a quietly short list. */
  await post('/stub/yahoo', { txFail: true });
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(16000);
  const dd = page.getByText('Dismiss', { exact: false }).first();
  if (await dd.count()) await dd.click({ force: true }).catch(() => {});
  await page.evaluate(() => {
    const btn = Array.from(document.querySelectorAll('button.menuitem')).find((e) => /my week/i.test((e.innerText || '').trim()));
    if (btn) btn.click();
  });
  await page.waitForTimeout(4000);
  await page.evaluate(() => { const c = document.querySelector('[data-wkview="moves"]'); if (c) c.click(); });
  await page.waitForTimeout(5000);
  const degraded = await page.evaluate(() => ({
    rows: document.querySelectorAll('[data-wkmove]').length,
    uncovered: (document.querySelector('[data-wkmovesuncovered]') || {}).innerText || null }));
  ok('3f · ⭐⭐⭐⭐⭐ a Yahoo failure leaves the Sleeper half of the feed intact',
    degraded.rows > 0, `${degraded.rows} rows still shown`);
  /* ⚠ AND NAMED THE WAY HE NAMED IT. It came back as "nfl.l.99" in the first cut — how the API
     addresses the league, not how anybody thinks about it. */
  ok('3g · ⭐⭐⭐⭐⭐ …and the league it could not read is named as HE names it, not as the API does',
    !!degraded.uncovered && /Yahoo Dynasty/i.test(degraded.uncovered),
    degraded.uncovered ? degraded.uncovered.replace(/\s+/g, ' ').slice(0, 90) : 'NOTHING SAID');
  await post('/stub/yahoo', { txFail: false });
  await ctx.close();
}

/* ══ §4 — NOTHING THREW ════════════════════════════════════════════════════════════════════════ */
console.log('\n== §4 the console ==');
ok('4 · ⭐⭐⭐⭐ nothing threw in any context', errs.length === 0, errs.slice(0, 3).join(' | '));

await post('/stub/reset', {});
console.log(`\n  ${pass} PASS  ${fail} FAIL`);
await b.close();
process.exit(fail ? 1 : 0);
