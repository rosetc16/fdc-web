/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   A GRADE ON EVERY TRADE IDEA — plan29bg
   Trey: "put the grade on every trade idea". 29bf put a letter and a call in the calculator; 29bg carries
   it to every list that suggests a trade. What has to be true:
     §1 DEALS — every card has a grade, the cards run best-first, and each card's letter and call are the
        ones the calculator shows when you press "Price this deal" (same grader, not an estimate).
     §1 ⭐ and the card's lineup gain is the calculator's lineup change. This is the stale-cache check: the
        trade lists were cached under a key that ignored this season's actual results, so they kept the
        projections-only numbers after the blend arrived while the (uncached) calculator moved.
     §2 LONG SHOTS, the LEAGUE table's ideas and the MARKET pathways carry the pill too.
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import { chromium } from 'playwright';
const APP = 'http://localhost:4174/', STUB = 'http://localhost:5055';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { console.log(`  ${c ? 'PASS' : 'FAIL'}  ${n}${x !== '' ? `   [${x}]` : ''}`); c ? pass++ : fail++; };
const post = (p, b) => fetch(STUB + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b || {}) }).then((r) => r.json()).catch(() => null);

const CFG = { teams: 12, rounds: 15, slot: 1, type: 'redraft', sf: false, tePremMult: 0, order: 'snake',
  start: { QB: 1, RB: 2, WR: 2, TE: 1, FLEX: 1, SUPER: 0, K: 1, DST: 1 }, scoring: { rec: 1 }, caps: {}, keepers: [] };
const c = { platform: 'sleeper', leagueId: 'hub-lg-1', username: 'trey', ownerUsername: 'trey' };
const L1 = { id: 'H1', name: 'Hub Fixture League', created: 'x', cfg: { ...CFG, name: 'Hub Fixture League', connect: c }, picks: [], preds: [], mocks: [], connect: c, sleeperLeagueId: 'hub-lg-1' };

const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const errs = [];
await post('/stub/reset'); await post('/stub/std', { mode: 'on' });
const page = await (await b.newContext({ viewport: { width: 1450, height: 1500 } })).newPage();
page.on('pageerror', (e) => errs.push(String(e)));
await page.goto(APP, { waitUntil: 'domcontentloaded' });
await page.evaluate((l) => {
  localStorage.clear(); localStorage.setItem('fdc:token', 't'); localStorage.setItem('fdcTourSeen', '1');
  localStorage.setItem('fdc:gs-state', JSON.stringify({ user: { email: 'trey.rose@pirates.com', paid: true, admin: true, rankSets: [], sleeperUsername: 'trey', sleeperUserId: 's1', homeView: 'season' }, leagues: [l], funMocks: [] }));
  sessionStorage.setItem('gs-nav', JSON.stringify({ route: 'teamHub', activeId: null, hubLeagueId: 'hub-lg-1' }));
}, L1);
await page.reload({ waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-hubnav]', { timeout: 30000 }); await page.waitForTimeout(2500);
const sec = async (k) => { await page.click('[data-hubgroup="moves"]'); await page.waitForTimeout(250); await page.click('[data-hubtabbtn="trades"]'); await page.waitForTimeout(400);
  await page.click(`[data-tsectab="${k}"]`); await page.waitForTimeout(700); };

/* ══ §1 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §1 Deals: graded, best first, and the same grade the calculator gives ==');
await sec('deals');
const cards = await page.$$eval('[data-tbrec]', (xs) => xs.map((x) => {
  const g = x.querySelector('[data-ideagrade]');
  const btn = x.querySelector('[data-tbrecbuild]');
  const gain = x.querySelector('[data-tbrecgain]');
  return { g: g && g.getAttribute('data-ideagrade'), call: g && g.getAttribute('data-ideacall'), score: g ? Number(g.getAttribute('data-ideascore')) : null,
    build: btn && btn.getAttribute('data-tbrecbuild'), gain: gain ? Number(gain.getAttribute('data-tbrecgain')) : null };
}));
ok('1 · (fixture) there are deals to grade', cards.length >= 2, `${cards.length} cards`);
ok('1a · ⭐⭐⭐⭐⭐ every card carries a grade and a call', cards.length > 0 && cards.every((x) => x.g && x.call), cards.map((x) => `${x.g}/${x.call}`).join(' '));
/* 29bh — a "they won't accept" deal sorts to the bottom whatever its score, so the check runs on the rest. */
const real = cards.filter((x) => x.call !== 'dream');
const firstDream = cards.findIndex((x) => x.call === 'dream');
ok('1b · ⭐⭐⭐⭐ best first — scores never rise down the list, and "won\'t accept" deals come last', real.every((x, i) => i === 0 || x.score <= real[i - 1].score) && (firstDream < 0 || cards.slice(firstDream).every((x) => x.call === 'dream')), real.map((x) => x.score).join(' ≥ '));
for (let i = 0; i < Math.min(3, cards.length); i++) {
  const cd = cards[i];
  if (i) await sec('deals');
  await page.click(`[data-tbrecbuild="${cd.build.replace(/"/g, '\\"')}"]`); await page.waitForTimeout(900);
  const calc = await page.evaluate(() => {
    const g = document.querySelector('[data-tbgrade]'); const d = document.querySelector('[data-tbside="me"] [data-tbdelta]');
    return { g: g && g.getAttribute('data-tbgrade'), call: g && g.getAttribute('data-tbcall'), delta: d ? Number(d.getAttribute('data-tbdelta')) : null };
  });
  ok(`1c.${i + 1} · ⭐⭐⭐⭐⭐ card #${i + 1} (${cd.build}) says ${cd.g} "${cd.call}" — the calculator says ${calc.g} "${calc.call}"`, calc.g === cd.g && calc.call === cd.call);
  ok(`1d.${i + 1} · ⭐⭐⭐⭐⭐ and the card's lineup gain is the calculator's lineup change (no stale list)`, calc.delta != null && Math.abs(calc.delta - cd.gain) <= 0.15, `card +${cd.gain} / calc ${calc.delta}`);
}

/* ══ §2 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §2 the other lists that suggest a trade ==');
const ls = await page.$('[data-tblongtoggle]');
if (ls) { await ls.click(); await page.waitForTimeout(400);
  const n = await page.$$eval('[data-tblongrow]', (xs) => [xs.length, xs.filter((x) => x.querySelector('[data-ideagrade]')).length]);
  ok('2 · long shots are graded too', n[0] > 0 && n[0] === n[1], `${n[1]}/${n[0]}`);
} else ok('2 · (no long shots in the fixture — nothing to grade)', true);

await sec('league');
const opened = await page.evaluate(() => { const x = [...document.querySelectorAll('button[aria-expanded="false"]')].find((e) => /\d/.test(e.textContent) && e.closest('td')); if (x) { x.click(); return true; } return false; });
await page.waitForTimeout(600);
const lr = await page.$$eval('[data-lrdeal]', (xs) => [xs.length, xs.filter((x) => x.querySelector('[data-ideagrade]')).length]);
ok('2a · the League table\'s trade ideas carry the grade', opened && lr[0] > 0 && lr[0] === lr[1], `${lr[1]}/${lr[0]}`);

await sec('market');
let mk = [0, 0];
for (const pos of await page.$$eval('[data-mktpos]', (xs) => xs.map((x) => x.getAttribute('data-mktpos')))) {
  await page.click(`[data-mktpos="${pos}"]`); await page.waitForTimeout(600);
  mk = await page.$$eval('[data-mktpath]', (xs) => [xs.length, xs.filter((x) => x.querySelector('[data-ideagrade]')).length]);
  if (mk[0]) break;
  if (await page.$('[data-mktback]')) { await page.click('[data-mktback]'); await page.waitForTimeout(300); }
}
ok('2b · the Market\'s pathways carry the grade', mk[0] > 0 && mk[0] === mk[1], `${mk[1]}/${mk[0]}`);

ok('3 · nothing threw', errs.length === 0, errs.slice(0, 2).join(' || ').slice(0, 160));
await page.screenshot({ path: '/tmp/claude-0/deals.png' });
await b.close();
console.log(`\n  ${pass} PASS  ${fail} FAIL`);
process.exit(fail ? 1 : 0);
