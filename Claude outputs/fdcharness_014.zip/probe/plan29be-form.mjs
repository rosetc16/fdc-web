/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   SEASON-TO-DATE FORM, AGAINST THE REAL SCORER — plan29be-form, 29be
   ───────────────────────────────────────────────────────────────────────────────────────────────────
   Trey: "is the projected points of value taking into account what they have already done this season?
   I just want to make sure it's as dynamic as possible with changing values weekly."
   src/form.js has 20 unit checks on the arithmetic with a toy scorer. This suite runs the real pool, the
   real league scorer and the real `leaguePower`, through the exported `injCtxFor` / `formResolve` /
   `injResolve` the hub uses.
   ⚠ Same synthetic-sid caveat as plan29bb-cascade: the sandbox cannot reach the player pack.
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import { leaguePower, hubPoolFor, normalizeHubCfg, injCtxFor, injResolve, formResolve, POS } from "./lib/app-lib.js";
import { INJ_SEASON } from "/home/claude/work/web/fdc-web/src/injuries.js";
import { scaleLine } from "/home/claude/work/web/fdc-web/src/form.js";

let n = 0, failed = 0;
const ok = (c, m) => { n++; if (!c) { failed++; console.log(`  FAIL  ${m}`); } else console.log(`  ok    ${m}`); return !!c; };

/* ⚠ A CUSTOM-SCORING LEAGUE ON PURPOSE: TE premium, 6-point passing TDs, half PPR. A check run in default
   scoring could not tell "actuals scored with league rules" from "actuals scored with default rules". */
const CUSTOM = { teams: 12, type: "redraft", sf: false, start: { QB: 1, RB: 2, WR: 3, TE: 1, FLEX: 1, K: 1, DST: 1 },
  scoring: { rec: 0.5, recTE: 1.5, passTD: 6 } };

function makeLeague(cfg) {
  const built = hubPoolFor(normalizeHubCfg(cfg));
  const entries = built.pool.map((p, i) => (p && p.sid != null ? p : { ...p, sid: `fx${i}` }));
  const bySid = new Map(); entries.forEach((p) => bySid.set(String(p.sid), p));
  const pool = { pool: entries, bySid };
  const rankable = entries.filter((p) => POS.includes(p.pos) && p.pts > 0).sort((a, b) => b.pts - a.pts);
  const teams = Array.from({ length: 12 }, (_, i) => ({ rosterId: i + 1, teamName: `Team ${i + 1}`, players: [], record: { wins: 4, losses: 4 }, pointsFor: 900 }));
  rankable.slice(0, 180).forEach((p, i) => { const rd = Math.floor(i / 12), sl = i % 12; teams[rd % 2 ? 11 - sl : sl].players.push(String(p.sid)); });
  return { pool, data: { cfg, teams, myRosterId: 1, week: 9, regularSeasonWeeks: 14 } };
}
const { pool, data } = makeLeague(CUSTOM);

console.log("\n§0  IS THIS FIXTURE ACTUALLY A CUSTOM-SCORING LEAGUE?");
/* ⚠⚠⚠⚠ THIS SECTION EXISTS BECAUSE §1 PASSED VACUOUSLY ON ITS FIRST RUN. normalizeHubCfg hard-coded
   `scoring: {}`, so the "TE-premium" fixture was scored as default PPR, and "an on-projection TE keeps
   his value" was true for the uninteresting reason that no custom rule reached anything. That was also a
   real product bug — every hub season value ignored the league's scoring — fixed in 29be. This asserts
   the rules arrive BEFORE any check below relies on them. */
{
  const plain = hubPoolFor(normalizeHubCfg({ ...CUSTOM, scoring: { rec: 1 } }));
  const bw = (pl) => pl.pool.find((p) => p.name === "Brock Bowers").pts;
  const al = (pl) => pl.pool.find((p) => p.name === "Josh Allen").pts;
  ok(bw(pool) > bw(plain), `the TE premium reaches the scorer (Bowers ${bw(plain)} in PPR → ${bw(pool)} here)`);
  ok(al(pool) > al(plain), `six-point passing TDs reach it (Allen ${al(plain)} → ${al(pool)})`);
  const half = hubPoolFor(normalizeHubCfg({ ...CUSTOM, scoring: { rec: 0.5 } }));
  ok(bw(half) < bw(plain), `and a Yahoo-style { rec: 0.5 } with no recTE gives TEs half PPR, not a phantom premium (${bw(half)})`);
}
const scoreMap = (t) => Object.fromEntries(t.map((r) => [r.rosterId, r.rosterScore]));
const rankMap = (t) => Object.fromEntries(t.map((r) => [r.rosterId, r.powerRank]));
const GP = 8;
/* A record whose per-game line is exactly `mult` × the player's projected per-game line. */
const recAt = (p, mult) => ({ gp: GP, s: scaleLine(p.stats || {}, (GP / 17) * mult) });

console.log("\n§1  ON-PROJECTION PLAYERS DO NOT MOVE — THE SAME SCORER, THE SAME RULES");
{
  const te = pool.pool.find((p) => p.pos === "TE" && p.pts > 150);
  const qb = pool.pool.find((p) => p.pos === "QB" && p.pts > 250);
  const std = { throughWeek: 8, players: { [te.sid]: recAt(te, 1), [qb.sid]: recAt(qb, 1) } };
  const ctx = injCtxFor(data, {}, std);
  const teF = formResolve(pool, te.sid, ctx), qbF = formResolve(pool, qb.sid, ctx);
  /* ⚠⚠⚠⚠⚠ THE PROPERTY THAT MATTERS MOST. If actuals were scored under default rules while projections
     used the league's, a TE whose actual line EXACTLY equals his projection would still move — by the TE
     premium — and every TE in a premium league would show phantom "form". */
  ok(Math.abs(teF.pts - te.pts) <= 1, `a TE producing exactly his projected line keeps his value in a TE-premium league (${te.pts} → ${teF.pts})`);
  ok(Math.abs(qbF.pts - qb.pts) <= 1, `a QB on exactly his projection keeps his value with 6-point passing TDs (${qb.pts} → ${qbF.pts})`);
}

console.log("\n§2  A HOT PLAYER RISES, A COLD ONE FALLS, AND IT REACHES THE POWER TABLE");
{
  const t1 = data.teams[0];
  const best = t1.players.map((id) => pool.bySid.get(id)).sort((a, b) => b.pts - a.pts)[0];
  const healthy = leaguePower(data, pool, injCtxFor(data, {}, null));
  const hot = leaguePower(data, pool, injCtxFor(data, {}, { throughWeek: 8, players: { [best.sid]: recAt(best, 1.5) } }));
  const cold = leaguePower(data, pool, injCtxFor(data, {}, { throughWeek: 8, players: { [best.sid]: recAt(best, 0.5) } }));
  const h = scoreMap(healthy), hs = scoreMap(hot), cs = scoreMap(cold);
  const hotP = formResolve(pool, best.sid, injCtxFor(data, {}, { throughWeek: 8, players: { [best.sid]: recAt(best, 1.5) } }));
  ok(hotP.pts > best.pts, `${best.name} at 1.5× his projection for ${GP} games is worth more (${best.pts} → ${hotP.pts})`);
  /* (8×1.5 + 6×1)/14 = 1.286 of projection */
  ok(Math.abs(hotP.pts / best.pts - (GP * 1.5 + 6) / (GP + 6)) < 0.02, `…by exactly the weighted amount — 8 games at 1.5×, 6 of projection = ${((GP * 1.5 + 6) / (GP + 6)).toFixed(3)}× (got ${(hotP.pts / best.pts).toFixed(3)}×)`);
  ok(hs[1] > h[1] && cs[1] < h[1], `team 1's roster score follows him: ${h[1].toFixed(1)} → hot ${hs[1].toFixed(1)} / cold ${cs[1].toFixed(1)}`);
  let moved = 0; for (let r = 2; r <= 12; r++) if (Math.abs(hs[r] - h[r]) > 0.001) moved++;
  ok(moved === 0, `no other team's score moved (${moved})`);
}

console.log("\n§3  NO DATA, NO CHANGE — THE PRE-29be PATH IS UNTOUCHED");
{
  const p = pool.pool.find((x) => x.pos === "WR");
  ok(formResolve(pool, p.sid, injCtxFor(data, {}, null)) === p, "no season-to-date at all: the pool entry itself comes back");
  ok(formResolve(pool, p.sid, injCtxFor(data, {}, { throughWeek: 0, players: {} })) === p, "an empty table (backend still warming): the pool entry itself");
  const a = scoreMap(leaguePower(data, pool, null)), b = scoreMap(leaguePower(data, pool, injCtxFor(data, {}, { throughWeek: 3, players: {} })));
  ok(Object.keys(a).every((k) => a[k] === b[k]), "and the whole power table is identical to having no context at all");
}

console.log("\n§4  FORM FIRST, THEN INJURY");
{
  const p = pool.pool.filter((x) => x.pos === "RB").sort((a, b) => b.pts - a.pts)[0];
  const ctx = injCtxFor(data, { [p.sid]: { status: INJ_SEASON, setWeek: 9, at: 1 } }, { throughWeek: 8, players: { [p.sid]: recAt(p, 1.4) } });
  const f = formResolve(pool, p.sid, ctx), both = injResolve(pool, p.sid, ctx);
  ok(both.pts === 0, "a hot player marked out for the season still projects zero");
  /* ⚠ The injury removes HIS CURRENT RATE — the blended one — so the points the tab says he costs you
     are what he has actually been worth, not a stale preseason number. */
  ok(both.injHealthyPts === f.pts && f.pts > p.pts, `and the injury is measured against his FORM-adjusted value (${f.pts}), not the stale projection (${p.pts})`);
}

console.log(`\n${n - failed}/${n} PASS${failed ? ` — ${failed} FAILED` : ""}`);
process.exit(failed ? 1 : 0);
