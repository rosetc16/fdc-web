/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   WHAT AN INJURY DOES TO ONE TEAM — plan29bb-team, 29bb
   ───────────────────────────────────────────────────────────────────────────────────────────────────
   Trey: "take Jayden Daniels' projection for the rest of the year, make it a zero, and the replacement
   becomes whoever your backup quarterback is. So you basically want to see, like, what are the
   ramifications of that injury?"

   This suite runs the EXACT functions the Injuries tab runs — `injuryImpact` and `hubWeekPts`, both
   exported from App.jsx and imported here through the vite library build — against the real pool and
   the real lineup optimizer. Rosters are built the way `resolve` builds them: season value from the
   (injury-adjusted) pool entry, weekly points through `hubWeekPts`.

   ⭐ THE CLAIM UNDER TEST, in one line: the cost of an injury is the gap between two solved lineups, and
     never the injured man's own points. Every section below is a shape where those two disagree.
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import { hubPoolFor, normalizeHubCfg, injuryImpact, hubWeekPts, setSpec } from "./lib/app-lib.js";
import { applyInjuryToEntry, INJ_SEASON, INJ_WEEKS, INJ_LIMITED, LIMITED_RATE } from "/home/claude/work/web/fdc-web/src/injuries.js";

let n = 0, failed = 0;
const ok = (c, m) => { n++; if (!c) { failed++; console.log(`  FAIL  ${m}`); } else console.log(`  ok    ${m}`); return !!c; };
const near = (a, b, eps, m) => ok(Math.abs(a - b) <= eps, `${m} (${a} ≈ ${b})`);

const CFG = normalizeHubCfg({ teams: 12, type: "redraft", sf: false, start: { QB: 1, RB: 2, WR: 3, TE: 1, FLEX: 1, K: 1, DST: 1 }, scoring: "ppr" });
const pool = hubPoolFor(CFG);
setSpec(CFG.start);   // lineupSlots reads the SPEC global; the hub sets it the same way
const CTX = { week: 6, weeksLeft: 9, dynasty: false };

/* Pick real players by positional rank so the fixture is readable. */
const byPos = (pos) => pool.pool.filter((p) => p && p.pos === pos && p.pts > 0).sort((a, b) => b.pts - a.pts);
const QB = byPos("QB"), RB = byPos("RB"), WR = byPos("WR"), TE = byPos("TE"), K = byPos("K"), DST = byPos("DST");

/* ⚠ BUILT THE WAY `resolve` BUILDS A ROSTER, including the synthetic sid the pool lacks in node (see the
   note in plan29bb-cascade). Each player gets `ptsSeason` from the adjusted entry and `pts` from
   `hubWeekPts` with no platform slate — the fallback path, which is the one that carried the bug. */
const mk = (raw, i, inj) => {
  const sid = `t${i}`;
  const base = inj ? applyInjuryToEntry(raw, inj, CTX) : raw;
  return { ...base, sid, ptsSeason: base.pts, pts: hubWeekPts(raw, base, undefined, false, 17) };
};
const roster = (list, injured = {}) => list.map((raw, i) => mk(raw, i, injured[i]));

/* A normal team: QB1 + a real backup, starting RBs and WRs, bench depth. Index 0 is the star QB. */
const LIST = [QB[1], QB[18], RB[4], RB[15], RB[30], WR[5], WR[14], WR[22], WR[40], TE[6], K[3], DST[3]];

console.log("\n§1  THE STAR QB IS OUT — THE BACKUP INHERITS THE SLOT");
{
  const healthy = roster(LIST);
  const now = roster(LIST, { 0: { status: INJ_SEASON } });
  const r = injuryImpact(now, healthy, false, 17, 9);
  const row = r.rows[0];
  ok(r.injuredCount === 1, "one injured player on the roster");
  ok(row.wasStarting === "QB", `he held the QB slot when healthy (${row.wasStarting})`);
  ok(row.replacedBy && row.replacedBy.name === LIST[1].name, `and the man who steps in is the backup, by name (${row.replacedBy && row.replacedBy.name})`);
  const starW = healthy[0].pts, backupW = healthy[1].pts;
  /* ⚠⚠⚠⚠⚠ THE WHOLE POINT. The naive answer is the star's own weekly points; the true one is star minus
     backup. If these two ever agree, the function has stopped crediting the man who actually plays. */
  near(r.weekCost, Math.round((starW - backupW) * 10) / 10, 0.15, "this week costs STAR minus BACKUP");
  ok(r.weekCost < starW - 1, `and NOT the star's full ${starW} — the backup's ${backupW} is credited`);
  near(r.meanCost, Math.round(((LIST[0].pts - LIST[1].pts) / 17) * 10) / 10, 0.15, "the rest-of-season per-week cost is the same difference, on season value");
  ok(r.needPos.length === 1 && r.needPos[0] === "QB", `the team is now shopping at QB and nowhere else (${r.needPos.join(",")})`);
}

console.log("\n§2  NO BACKUP — THE SLOT IS EMPTY, AND THE FULL COST IS REAL");
{
  const noBackup = LIST.filter((_, i) => i !== 1);
  const healthy = roster(noBackup);
  const now = roster(noBackup, { 0: { status: INJ_SEASON } });
  const r = injuryImpact(now, healthy, false, 17, 9);
  const row = r.rows[0];
  /* In a one-QB, no-superflex league nobody else can play QB, so the optimizer leaves it empty. */
  ok(row.emptyNow === true, "with no second quarterback the QB slot is reported EMPTY");
  ok(row.replacedBy === null, "and nobody is named as a replacement");
  /* ⚠ THE PRODUCT BUG §2 FOUND: the solver leaves him IN the QB slot at 0.0, and the first cut reported
     that as "still your best option at QB, at reduced value" — about a man out for the year. */
  ok(row.stillStarting === false, "and he is NOT described as still starting at reduced value");
  near(r.weekCost, healthy[0].pts, 0.15, "so here — and only here — the cost IS his whole projection");
}

console.log("\n§3  AN INJURED BENCH PLAYER COSTS NOTHING, AND SENDS NOBODY SHOPPING");
{
  const healthy = roster(LIST);
  const now = roster(LIST, { 1: { status: INJ_SEASON } });   // the backup QB
  const r = injuryImpact(now, healthy, false, 17, 9);
  ok(r.rows[0].wasStarting === null, "the backup was not in the best lineup");
  ok(r.weekCost === 0 && r.meanCost === 0, `so the injury costs 0 this week and 0 per week after (${r.weekCost}, ${r.meanCost})`);
  ok(r.needPos.length === 0, "and no position is flagged for a replacement search — that would be bad advice");
}

console.log("\n§4  TWO SLOTS OF ONE POSITION — THE RIGHT MAN IS NAMED");
/* ⚠⚠ THE OCCURRENCE BUG. With two RB slots, a first-match lookup reads the RB1 slot back for an injured
   RB2 and reports "RB1 steps in" — the right position, the wrong man, and a sentence that reads fine. */
{
  const healthy = roster(LIST);
  const rb1 = healthy[2], rb2 = healthy[3];
  const now = roster(LIST, { 3: { status: INJ_SEASON } });   // RB2 out
  const r = injuryImpact(now, healthy, false, 17, 9);
  const row = r.rows[0];
  /* ⚠ SUITE BUG ON FIRST RUN: the slots are named RB1/RB2, not "RB". The test assumed a label shape it
     had never looked at — the product was right. */
  ok(/^(RB|FLEX)/.test(row.wasStarting || ""), `RB2 was starting (${row.wasStarting})`);
  ok(row.replacedBy && row.replacedBy.name !== rb1.name, `the man named is NOT the healthy RB1 (${row.replacedBy && row.replacedBy.name} vs ${rb1.name})`);
  ok(row.replacedBy && String(row.replacedBy.sid) !== String(rb2.sid), "and not the injured man himself");
  ok(r.weekCost > 0 && r.weekCost < rb2.pts, `the cost is a partial one (${r.weekCost} of his ${rb2.pts})`);
}

console.log("\n§5  LIMITED — AND THE DOUBLE DISCOUNT THIS SUITE FOUND");
{
  const raw = LIST[0];
  const lim = applyInjuryToEntry(raw, { status: INJ_LIMITED }, CTX);
  const healthyWk = hubWeekPts(raw, raw, undefined, false, 17);
  const limWk = hubWeekPts(raw, lim, undefined, false, 17);
  /* ⚠⚠⚠⚠ Before 29bb's fix the fallback averaged the ALREADY-discounted season value and then applied
     the week factor on top: 0.7 × 0.7 = 49%. This is the assertion that pins it. */
  near(limWk / healthyWk, LIMITED_RATE, 0.02, "a limited player projects the LIMITED rate this week, not the rate squared");
  ok(limWk / healthyWk > LIMITED_RATE * LIMITED_RATE + 0.1, `explicitly: not ${Math.round(LIMITED_RATE * LIMITED_RATE * 100)}% (got ${Math.round(limWk / healthyWk * 100)}%)`);
  /* And with a real platform slate, the platform number is the undiscounted one and gets exactly one factor. */
  near(hubWeekPts(raw, lim, { pts: 20 }, true, 17), 20 * LIMITED_RATE, 0.05, "a platform projection of 20 becomes 14 for a limited man");
  ok(hubWeekPts(raw, applyInjuryToEntry(raw, { status: INJ_SEASON }, CTX), { pts: 20 }, true, 17) === 0, "and 0 for a man out for the year — Sleeper's 20 is overridden");
  ok(hubWeekPts(raw, raw, { pts: 20 }, true, 17) === 20, "a healthy man's platform number is untouched");

  /* ⚠ FIXTURE BUG ON FIRST RUN: the default backup (a QB18) outscores a star at 70%, so the optimizer was
     RIGHT to bench him and the check failed a correct build. A limited star who keeps his job needs a
     backup who genuinely cannot take it — the weakest QB in the pool. */
  const WEAK = [LIST[0], QB[QB.length - 1]].concat(LIST.slice(2));
  const healthy = roster(WEAK);
  const now = roster(WEAK, { 0: { status: INJ_LIMITED } });
  const r = injuryImpact(now, healthy, false, 17, 9);
  const row = r.rows[0];
  ok(healthy[1].pts < healthy[0].pts * LIMITED_RATE, `precondition: the backup (${healthy[1].pts}) is below the star at 70% (${Math.round(healthy[0].pts * LIMITED_RATE * 10) / 10})`);
  ok(row.stillStarting === true, `a limited star who still beats his backup keeps starting (${row.stillStarting})`);
  near(r.weekCost, Math.round(healthy[0].pts * (1 - LIMITED_RATE) * 10) / 10, 0.15, "and the cost is exactly his lost 30%");
  ok(r.needPos.includes("QB"), "the position is still offered for an upgrade search — he is worth less");
}

console.log("\n§6  OUT A FEW WEEKS IS BETWEEN THE TWO");
{
  const healthy = roster(LIST);
  const season = injuryImpact(roster(LIST, { 0: { status: INJ_SEASON } }), healthy, false, 17, 9).meanCost;
  const weeks = injuryImpact(roster(LIST, { 0: { status: INJ_WEEKS, weeks: 3, setWeek: 6 } }), healthy, false, 17, 9).meanCost;
  const none = injuryImpact(healthy, healthy, false, 17, 9).meanCost;
  ok(none === 0, "a healthy roster has no cost at all");
  ok(weeks > 0 && weeks < season, `three weeks out (${weeks}/wk) costs less than the season (${season}/wk) and more than nothing`);
  /* ⚠⚠⚠⚠ THE BUG THIS SECTION FOUND ON ITS FIRST RUN: both came out 5.3. Averaged over the window, a
     two-thirds star sits below his backup and the solver benches him for all nine weeks. Phased, he misses
     three and starts six, so the cost is three-ninths of the season-long one. */
  near(weeks, Math.round(season * 3 / 9 * 10) / 10, 0.2, "and it is three-ninths of the season-long cost — three weeks out, then he starts again");
}

console.log(`\n${n - failed}/${n} PASS${failed ? ` — ${failed} FAILED` : ""}`);
process.exit(failed ? 1 : 0);
