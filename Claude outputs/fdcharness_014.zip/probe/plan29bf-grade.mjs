/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   THE TRADE GRADE AND THE CALL — plan29bf-grade, 29bf
   Trey: "can you also put a grade on the trade for you... and a recommendation (that is clear) for whether
   or not you should make the deal."
   Runs the REAL `tradeEval` (node library build) with a transparent scorer: a team's starting lineup is
   its best two players, so every expected number can be worked out by hand.
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import { tradeEval } from "./lib/app-lib.js";

let n = 0, failed = 0;
const ok = (c, m) => { n++; if (!c) { failed++; console.log(`  FAIL  ${m}`); } else console.log(`  ok    ${m}`); return !!c; };

const P = (sid, pos, pts) => ({ sid, pos, pts, name: sid });
const top2 = (r) => r.slice().sort((a, b) => b.pts - a.pts).slice(0, 2).reduce((s, p) => s + p.pts, 0);
const score = (r) => ({ start: top2(r), rosterScore: top2(r), bench: [] });
/* Season points; the grade reads them per week (÷17). */
const league = (mine, theirs) => [
  { rosterId: 1, teamName: "Me", isMe: true, roster: mine, record: { wins: 4, losses: 4 }, pointsFor: 900 },
  { rosterId: 2, teamName: "Them", roster: theirs, record: { wins: 4, losses: 4 }, pointsFor: 900 },
  ...[3, 4, 5, 6].map((i) => ({ rosterId: i, teamName: `T${i}`, roster: [P(`x${i}a`, "WR", 200 + i * 5), P(`x${i}b`, "RB", 190)], record: { wins: 4, losses: 4 }, pointsFor: 900 })),
];
const ev = (mine, theirs, give, get) => tradeEval(league(mine, theirs), { myId: 1, theirId: 2, give, get, score, replacement: { WR: 100, RB: 100, QB: 100, TE: 60 } });

console.log("\n§1  EACH CALL, ON A TRADE WHOSE RIGHT ANSWER IS OBVIOUS");
{
  /* +51 season for me = +3.0 a week; they lose. */
  const r = ev([P("a", "WR", 200), P("b", "RB", 150), P("c", "RB", 90)], [P("d", "RB", 201), P("e", "WR", 180), P("f", "WR", 120)], ["c"], ["d"]);
  ok(r.grade.letter === "A", `a +${r.grade.perWeek}/week upgrade grades A (29bk scale: A+ is +4 a week) (${r.grade.letter})`);
  /* 29bh — this deal sends back 0 of value for 101: not "they may want more" but a different trade. */
  ok(r.call.key === "dream", `…and because it sends them nothing of value back, the call is "they won't accept" (${r.call.key}: ${r.call.label})`);
}
{
  /* 29bh — the "may need more" band: good for me, they lose, but the value going back is real (60 for 101). */
  const r = ev([P("a", "WR", 200), P("b", "RB", 150), P("c", "RB", 160)], [P("d", "RB", 201), P("e", "WR", 180), P("f", "WR", 120)], ["c"], ["d"]);
  ok(r.grade.letter === "A-" && r.call.key === "sweeten", `a +${r.grade.perWeek}/week upgrade at ${r.sides.me.assetsOut} for ${r.sides.me.assetsIn} of value → ${r.grade.letter}, "${r.call.label}"`);
}
{
  /* ⭐⭐⭐⭐⭐ 29bh — TREY'S CASE: a defense for a star quarterback. The defense's points count in the lineup,
     but in a trade it is worth 15% of them, so the value check sees it for what it is. */
  const r = ev([P("a", "QB", 250), P("b", "DEF", 160), P("c", "RB", 150)], [P("d", "QB", 330), P("e", "DEF", 110), P("f", "WR", 180)], ["b"], ["d"]);
  ok(r.call.key !== "send" && r.call.key !== "sweeten", `Eagles-for-Allen is never "make this offer" or "may need more" (${r.call.key}: ${r.call.label}; value ${r.sides.me.assetsOut} for ${r.sides.me.assetsIn})`);
}
{
  /* ⚠ BOTH SIDES GAIN — which needs a scorer that knows positions (a lineup of one WR and one RB), because
     "best two players" cannot express a positional fit; the first cut of this block used it and asserted
     nothing. I have two receivers and no back, they have the mirror image; the swap fixes both lineups. */
  const posScore = (r) => { const b = (pos) => Math.max(0, ...r.filter((p) => p.pos === pos).map((p) => p.pts));
    const v = b("WR") + b("RB"); return { start: v, rosterScore: v, bench: [] }; };
  const r = tradeEval(league([P("a", "WR", 200), P("b", "WR", 190), P("c", "RB", 150)], [P("d", "RB", 200), P("e", "RB", 190), P("f", "WR", 150)]),
    { myId: 1, theirId: 2, give: ["b"], get: ["e"], score: posScore, replacement: { WR: 100, RB: 100, QB: 100, TE: 60 } });
  ok(r.sides.me.delta > 0 && r.sides.them.delta > 0, `(fixture) both lineups improve: me +${r.sides.me.delta}, them +${r.sides.them.delta}`);
  ok(r.call.key === "send", `⭐⭐⭐⭐⭐ good for me AND fair for them → "${r.call.label}" (${r.grade.letter})`);
}
{
  /* A swap of equals: nothing changes for me. */
  const r = ev([P("a", "WR", 200), P("b", "RB", 180), P("c", "RB", 90)], [P("d", "RB", 200), P("e", "WR", 170), P("f", "RB", 90)], ["c"], ["f"]);
  ok(r.grade.perWeek === 0 && r.grade.letter === "C", `⭐⭐⭐⭐⭐ a trade that changes nothing grades C — ABSOLUTE, not relative (${r.grade.letter})`);
  ok(r.call.key === "even", `…and the call says it is not worth it (${r.call.label})`);
}
{
  /* −34 season = −2.0 a week. */
  const r = ev([P("a", "WR", 200), P("b", "RB", 184), P("c", "RB", 90)], [P("d", "RB", 150), P("e", "WR", 170)], ["b"], ["d"]);
  ok(r.grade.letter === "D", `a −${Math.abs(r.grade.perWeek)}/week downgrade grades D (29bk scale: F is −2.8 a week and worse) (${r.grade.letter})`);
  ok(r.call.key === "pass", `…and the call is don't (${r.call.label})`);
}
{
  /* +0.35 a week: a small upgrade. */
  const r = ev([P("a", "WR", 200), P("b", "RB", 150), P("c", "RB", 90)], [P("d", "RB", 156), P("e", "WR", 220), P("f", "WR", 200)], ["b"], ["d"]);
  ok(r.grade.letter === "B-" && r.call.key === "small", `a +${r.grade.perWeek}/week nudge is a B− and a "small upgrade" (${r.grade.letter}, ${r.call.key})`);
}

console.log("\n§1a CALIBRATION (29bi)");
{
  /* Trey's D: "it drops my annual scoring by only 12 points and just re-allocates to different players".
     A 1-for-2 where my lineup gives back 12 season points and I take on more total talent. */
  const r = ev([P("a", "WR", 200), P("b", "WR", 190), P("c", "RB", 150), P("x", "RB", 100)], [P("d", "RB", 175), P("e", "WR", 175), P("f", "RB", 140)], ["b"], ["d", "e"]);
  ok(r.sides.me.delta <= -5 && r.sides.me.delta >= -20, `(fixture) my lineup gives back ${r.sides.me.delta} season points`);
  ok(!["D", "F"].includes(r.grade.letter), `⭐⭐⭐⭐⭐ a small give-back that brings in more talent is not a D (${r.grade.letter}, ${r.grade.score})`);
}
{
  /* ⭐⭐⭐⭐⭐ BOTH SIDES CAN BE POSITIVE: my spare receiver for their spare back, each fixing the other's
     hole. Graded from each side separately, both must come out on the winning half of the scale. */
  const posScore = (r) => { const b = (pos) => Math.max(0, ...r.filter((p) => p.pos === pos).map((p) => p.pts));
    const v = b("WR") + b("RB"); return { start: v, rosterScore: v, bench: [] }; };
  const L = league([P("a", "WR", 200), P("b", "WR", 190), P("c", "RB", 120)], [P("d", "RB", 200), P("e", "RB", 190), P("f", "WR", 120)]);
  const mine = tradeEval(L, { myId: 1, theirId: 2, give: ["b"], get: ["e"], score: posScore, replacement: { WR: 100, RB: 100, QB: 100, TE: 60 } });
  const theirs = tradeEval(L, { myId: 2, theirId: 1, give: ["e"], get: ["b"], score: posScore, replacement: { WR: 100, RB: 100, QB: 100, TE: 60 } });
  ok(/^[AB]/.test(mine.grade.letter) && /^[AB]/.test(theirs.grade.letter), `a deal that fixes both rosters grades well for BOTH (${mine.grade.letter} / ${theirs.grade.letter})`);
}

console.log("\n§1c THE WAIVER WIRE (29bl): Evans for Burrow with no healthy QB and Jordan Love on waivers");
{
  /* A lineup of QB + 2 WR. My quarterbacks are out for the year (0 points); Evans is my WR1. Burrow is theirs.
     Jordan Love (season 300 = 17.6 a week) is a free agent. Season points throughout. */
  const slotsOf = (r) => {
    const by = (pos) => r.filter((p) => p.pos === pos).sort((a, b) => b.pts - a.pts);
    const q = by("QB"), w = by("WR");
    return [{ slot: "QB", p: q[0] || null }, { slot: "WR1", p: w[0] || null }, { slot: "WR2", p: w[1] || null }];
  };
  const sc = (r) => { const sl = slotsOf(r); const st = sl.reduce((a, x) => a + (x.p ? x.p.pts : 0), 0);
    const on = new Set(sl.filter((x) => x.p).map((x) => x.p.sid)); return { start: st, rosterScore: st, bench: r.filter((p) => !on.has(p.sid)) }; };
  const mine = [P("daniels", "QB", 0), P("dart", "QB", 0), P("evans", "WR", 230), P("w2", "WR", 160), P("w3", "WR", 120)];
  const theirs = [P("burrow", "QB", 318), P("q2", "QB", 250), P("tw", "WR", 150)];
  const love = P("love", "QB", 300);
  const base = { myId: 1, theirId: 2, give: ["evans"], get: ["burrow"], score: sc, slotsOf, replacement: { WR: 100, RB: 100, QB: 240, TE: 60 } };
  const raw = tradeEval(league(mine, theirs), base);
  const wire = tradeEval(league(mine, theirs), { ...base, freeAgents: [love] });
  ok(raw.sides.me.delta === 318 - (230 - 120), `(check) against my roster as it stands the trade is +${raw.sides.me.delta}: Burrow's 318 at QB minus Evans' 230 replaced by a 120 at WR2`);
  ok(wire.waiver && wire.waiver.replaced.some((p) => p.name === "love") && wire.waiver.overWire === 18 - 110, `⭐⭐⭐⭐⭐ the wire baseline finds Love and the trade adds ${wire.waiver.overWire} over picking him up (Burrow 18 better, minus the 110 Evans costs)`);
  ok(wire.call.key === "wire" && /Pick up love instead/.test(wire.call.label), `⭐⭐⭐⭐⭐ so the call is to take the free agent (${wire.call.key}: ${wire.call.label})`);
  ok(raw.grade.score > wire.grade.score && /over just picking up love/.test(wire.grade.why[0]), `and the grade drops from ${raw.grade.letter} to ${wire.grade.letter}, saying why ("${wire.grade.why[0].slice(0, 60)}...")`);
  const d = raw.lineupDiff || [];
  ok(d.length === 3 && Math.round(d.reduce((a, x) => a + x.delta, 0)) === raw.sides.me.delta && d[0].slot === "QB" && d[0].delta === 318,
    `⭐⭐⭐⭐ the slot breakdown explains the net: ${d.map((x) => `${x.slot} ${x.delta >= 0 ? "+" : ""}${x.delta}`).join(", ")}`);
  const none = tradeEval(league(mine, theirs), { ...base, freeAgents: [P("scrub", "QB", 60)] });
  ok(none.call.key !== "wire", `a free agent who would not really fill the hole does not trigger the "use the wire" call (${none.call.key})`);
}

console.log("\n§1b DYNASTY — THE SAME TRADE, GRADED FOR A CONTENDER AND FOR A REBUILDER (29bh)");
{
  /* A 30-year-old star for a 22-year-old who scores less now. `longValue` is supplied so the long horizon is
     hand-checkable: the young man is worth far more over time. */
  const P2 = (sid, pos, pts, age, lv) => ({ sid, pos, pts, age, name: sid, lv });
  const mine = [P2("a", "WR", 200, 30, 40), P2("b", "RB", 150, 26, 60), P2("c", "RB", 120, 25, 50)];
  const theirs = [P2("d", "WR", 170, 22, 160), P2("e", "RB", 160, 27, 60), P2("f", "WR", 120, 28, 30)];
  const run = (posture) => tradeEval(league(mine, theirs), { myId: 1, theirId: 2, give: ["a"], get: ["d"], score, keeps: true, posture,
    windowInfo: { avgAge: 27, set: true }, longValue: (p) => p.lv, replacement: { WR: 100, RB: 100, QB: 100, TE: 60 } });
  const win = run("winnow"), reb = run("rebuild");
  ok(reb.grade.score > win.grade.score, `⭐⭐⭐⭐⭐ getting younger grades higher for a rebuilder than a contender (${reb.grade.letter} ${reb.grade.score} vs ${win.grade.letter} ${win.grade.score})`);
  ok(win.grade.why.some((w) => /win-now team.*this season 80%/.test(w)) && reb.grade.why.some((w) => /rebuilding team.*the future 70%/.test(w)), "and each grade says which window it used and how it weighted it");
}

console.log("\n§2  SYMMETRY — THE COMPLAINT, AS AN ASSERTION");
{
  /* "I tested out the calculator to see what would happen if I made the exact same trade back... my lineup
     would lose points (which it also said with the players I returned)." A trade and its exact reverse must
     grade as mirror images. */
  const mine = [P("a", "WR", 200), P("b", "RB", 150), P("c", "RB", 90)], theirs = [P("d", "RB", 201), P("e", "WR", 180), P("f", "WR", 120)];
  const fwd = ev(mine, theirs, ["c"], ["d"]);
  const mine2 = [P("a", "WR", 200), P("b", "RB", 150), P("d", "RB", 201)], theirs2 = [P("c", "RB", 90), P("e", "WR", 180), P("f", "WR", 120)];
  const rev = ev(mine2, theirs2, ["d"], ["c"]);
  ok(Math.abs(fwd.grade.perWeek + rev.grade.perWeek) < 0.05, `forward ${fwd.grade.perWeek}/wk, reverse ${rev.grade.perWeek}/wk — exact opposites`);
  ok(fwd.grade.letter === "A" && rev.grade.letter === "F", `and the letters mirror (${fwd.grade.letter} / ${rev.grade.letter})`);
  ok(fwd.power.myRank.to === rev.power.myRank.from && rev.power.myRank.to === fwd.power.myRank.from, `and the ranks round-trip (#${fwd.power.myRank.from}→#${fwd.power.myRank.to}→#${rev.power.myRank.to})`);
}

console.log("\n§3  THE WORDS MATCH THE NUMBERS");
{
  const r = ev([P("a", "WR", 200), P("b", "RB", 184), P("c", "RB", 90)], [P("d", "RB", 150), P("e", "WR", 170)], ["b"], ["d"]);
  ok(/worse by about 2\.0 a week/.test(r.call.why), `the call quotes the same per-week number as the grade ("${r.call.why.slice(0, 60)}…")`);
  ok(r.grade.why[0].startsWith("-2.0 a week"), `and the grade's reasons lead with it ("${r.grade.why[0]}")`);
}

console.log(`\n${n - failed}/${n} PASS${failed ? ` — ${failed} FAILED` : ""}`);
process.exit(failed ? 1 : 0);
