/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   "EAGLES DEFENSE FOR JOSH ALLEN" — plan29bh-dst, Trey's exact complaint rebuilt in node.
   The browser fixture cannot produce it (its defenses sit below the streaming line), so this builds the
   shape that does: a defense a couple of points over replacement, a star quarterback on a team with a good
   backup and a bad defense. Runs the REAL `tradeBoard` from src/trademarket.js.
   ⚠ Falsified: with `tradeable` switched off and the old raw-points `tierShare` fallback, §1 goes red —
     that pair is offered, because 2 raw points and a 1.0 share look like an even swap.
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import { tradeBoard } from "../web/fdc-web/src/trademarket.js";

let n = 0, failed = 0;
const ok = (c, m) => { n++; if (!c) { failed++; console.log(`  FAIL  ${m}`); } else console.log(`  ok    ${m}`); };
const P = (sid, pos, pts, name) => ({ sid, pos, pts, name: name || sid });
const SLOTS = { QB: 1, RB: 2, WR: 2, TE: 1, DEF: 1 };
const lineupValue = (r) => Object.entries(SLOTS).reduce((s, [pos, k]) => s + (r || []).filter((p) => p.pos === pos).map((p) => p.pts).sort((a, b) => b - a).slice(0, k).reduce((a, b) => a + b, 0), 0);
const repl = { QB: 240, RB: 120, WR: 130, TE: 90, DEF: 158, K: 130 };

const me = { rosterId: 1, teamName: "Me", roster: [P("qbme", "QB", 250), P("eagles", "DEF", 160, "Eagles D"), P("r1", "RB", 200), P("r2", "RB", 180), P("w1", "WR", 210), P("w2", "WR", 190), P("t1", "TE", 170), P("def2", "DEF", 150)] };
const them = { rosterId: 2, teamName: "Them", roster: [P("allen", "QB", 380, "Josh Allen"), P("qb2", "QB", 330), P("tr1", "RB", 190), P("tr2", "RB", 170), P("tw1", "WR", 200), P("tw2", "WR", 185), P("tt", "TE", 120), P("tdef", "DEF", 100)] };
const board = tradeBoard({ me, others: [them], lineupValue, sf: false, req: SLOTS, repl, max: 20 });
const all = [].concat(board.all || board, board.longShots || []);
const involves = (t, sid) => [t.give, t.give2, t.get].some((p) => p && p.sid === sid);

console.log("\n§1  THE DEFENSE-FOR-A-QUARTERBACK DEAL");
ok(!all.some((t) => involves(t, "eagles") && involves(t, "allen")), `⭐⭐⭐⭐⭐ Eagles D for Josh Allen is never suggested (${all.length} ideas)`);
ok(!all.some((t) => [t.give, t.give2, t.get].some((p) => p && ["DEF", "K"].includes(p.pos))), "⭐⭐⭐⭐⭐ no kicker or defense appears in any idea, either side");
console.log("\n§2  THE FINDER STILL WORKS");
ok(all.length > 0, `real player-for-player ideas survive: ${all.slice(0, 3).map((t) => `${t.give.name}${t.give2 ? " + " + t.give2.name : ""} → ${t.get.name}`).join(", ")}`);

console.log(`\n${n - failed}/${n} PASS${failed ? ` — ${failed} FAILED` : ""}`);
process.exit(failed ? 1 : 0);
