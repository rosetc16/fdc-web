/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   THE INJURY CASCADE, AGAINST THE REAL SCORER — plan29bb, 29bb
   ───────────────────────────────────────────────────────────────────────────────────────────────────
   `src/injuries.js` has 36 unit checks and they prove the ARITHMETIC. They cannot prove the thing that
   actually matters, which is that the arithmetic reaches the screens: a perfect discount applied to a
   value nothing reads is a feature that does nothing, and it would pass every one of those 36.

   ⭐⭐⭐⭐⭐ WHAT IS NEW HERE IS THAT NODE CAN NOW IMPORT THE APP'S REAL SCORING FUNCTIONS. Until this
     build, `leaguePower` — the function behind the hub's power column, the League tab's table and the
     home page's Power rank — could only be executed by a browser, because it lives in a 43,000-line JSX
     file. That is why 29w and 29y both shipped a power rating that was quietly wrong: there was no
     cheap way to ask it a question. `vite.lib.config.js` builds the module with React external and this
     suite imports it directly. Every number below is produced by the SAME code the app runs.

   ⚠ WHAT THIS STILL DOES NOT COVER: the tab's own DOM — the search box, the save button, the before/
     after arrows, the banner on the League tab. Those need a browser and are listed as unverified in
     the harness README. This suite covers the cascade, which is the half that can be wrong silently.
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import {
  leaguePower, hubPoolFor, normalizeHubCfg, injCtxFor, injResolve, hubWeeks, buildPlayers, POS,
} from "./lib/app-lib.js";
import { INJ_SEASON, INJ_WEEKS, INJ_LIMITED } from "/home/claude/work/web/fdc-web/src/injuries.js";

let n = 0, failed = 0;
const ok = (cond, msg) => {
  n++;
  if (!cond) { failed++; console.log(`  FAIL  ${msg}`); return false; }
  console.log(`  ok    ${msg}`);
  return true;
};

const REDRAFT = { teams: 12, type: "redraft", sf: false, start: { QB: 1, RB: 2, WR: 3, TE: 1, FLEX: 1, K: 1, DST: 1 }, scoring: "ppr" };
const DYNASTY = { ...REDRAFT, type: "dynasty" };

/* ⚠⚠⚠⚠ THE FIXTURE HAS TO BE CAPABLE OF EXPRESSING THE BUG, and this project has been caught three
   times by one that was not. Twelve teams dealt round-robin off the real pool gives rosters close
   enough in strength that removing one star genuinely reorders them — a fixture where one team is
   miles clear would absorb any injury and report "nothing moved" for a completely broken build.
   §0 below asserts that capability BEFORE anything else runs, so a fixture that stops being able to
   express the fault fails loudly instead of passing vacuously. */
/* ⚠⚠ SYNTHETIC SIDS, AND THE REASON MATTERS. Real Sleeper ids reach the pool only through
   `applyLivePack`, which needs the backend's player pack — and this sandbox cannot reach the backend,
   Sleeper or production. Without them every `p.sid` is null and `pool.bySid` is empty, which §0 caught
   on the first run of this suite rather than letting it "pass" against a league of twelve zero-point
   rosters. So the fixture stamps its own ids onto the REAL pool entries — the same objects, the same
   projections, the same VBD and dynasty values the app computes, addressed by a key the fixture chose.
   ⭐ WHAT THIS STILL PROVES: the transform, the scorer, the ranking and the dynasty damping, all on real
     player values. ⚠ WHAT IT DOES NOT: that a Sleeper roster's ids line up with the pool's — that is
     `resolve`'s existing job, predates this feature, and needs a browser and a real pack to check. */
function makeLeague(cfg) {
  const built = hubPoolFor(normalizeHubCfg(cfg));
  if (!built) throw new Error("the player pool would not build — nothing below can mean anything");
  const entries = built.pool.map((p, i) => (p && p.sid != null ? p : { ...p, sid: `fx${i}` }));
  const bySid = new Map();
  entries.forEach((p) => { if (p && p.sid != null) bySid.set(String(p.sid), p); });
  const pool = { pool: entries, bySid };
  const rankable = entries
    .filter((p) => p && p.sid != null && POS.includes(p.pos) && p.pts != null)
    .sort((a, b) => (b.pts || 0) - (a.pts || 0));
  const teams = [];
  for (let i = 0; i < 12; i++) teams.push({ rosterId: i + 1, teamName: `Team ${i + 1}`, ownerName: `Owner ${i + 1}`, players: [], record: { wins: 5, losses: 4, ties: 0 }, pointsFor: 1000 });
  // Snake the top 180 out across the twelve rosters, so every team gets a comparable spread.
  rankable.slice(0, 180).forEach((p, i) => {
    const rd = Math.floor(i / 12), slot = i % 12;
    teams[rd % 2 === 0 ? slot : 11 - slot].players.push(String(p.sid));
  });
  return { pool, data: { cfg, teams, myRosterId: 1, week: 6, regularSeasonWeeks: 14, playoffTeams: 6 } };
}

const rankMap = (table) => { const m = {}; (table || []).forEach((t) => { m[t.rosterId] = t.powerRank; }); return m; };
const scoreMap = (table) => { const m = {}; (table || []).forEach((t) => { m[t.rosterId] = t.rosterScore; }); return m; };

console.log("\n§0  CAN THE FIXTURE EVEN EXPRESS THE FAULT?");
const { pool, data } = makeLeague(REDRAFT);
const healthy = leaguePower(data, pool, null);
ok(healthy.length === 12, "the real scorer ranks all twelve teams");
const hs = scoreMap(healthy);
const spread = Math.max(...Object.values(hs)) - Math.min(...Object.values(hs));
const gaps = Object.values(hs).sort((a, b) => b - a).slice(0, -1).map((v, i) => v - Object.values(hs).sort((a, b) => b - a)[i + 1]);
ok(spread > 0, `the twelve teams are not identical (spread ${spread.toFixed(1)})`);
ok(Math.min(...gaps) < spread / 4, "and at least two of them sit close enough together that one injury could reorder them");

/* The biggest asset on team 1 — the man whose absence has the best chance of moving something. */
const t1 = data.teams[0];
const star = t1.players.map((id) => pool.bySid.get(String(id))).filter(Boolean).sort((a, b) => (b.pts || 0) - (a.pts || 0))[0];
ok(!!star, `team 1's best player resolves off the real pool (${star && star.name}, ${star && star.pos}, ${star && Math.round(star.pts)} pts)`);

console.log("\n§1  A SAVED INJURY REACHES THE POWER TABLE");
const inj = { [String(star.sid)]: { status: INJ_SEASON, setWeek: 6, at: Date.now() } };
const ictx = injCtxFor(data, inj);
ok(ictx.map[String(star.sid)], "injCtxFor carries the entry through to the resolver's map");
ok(ictx.weeksLeft === 9, `and reads the season window off the payload (week 6 of 14 → 9 left, got ${ictx.weeksLeft})`);
ok(ictx.dynasty === false, "and knows this is a redraft league");

const hurt = leaguePower(data, pool, ictx);
const hR = rankMap(healthy), iR = rankMap(hurt), iS = scoreMap(hurt);
ok(iS[1] < hs[1], `team 1's roster score falls when its best player is out (${hs[1].toFixed(1)} → ${iS[1].toFixed(1)})`);
ok(iR[1] > hR[1], `and its POWER RANK actually moves (#${hR[1]} → #${iR[1]}) — the cascade is not cosmetic`);

/* ⚠⚠⚠⚠⚠ THE CHECK THAT CATCHES THE VBD MULTIPLY AT THE LEAGUE LEVEL. The unit suite catches it on one
   player; this catches it on eleven rosters at once. If the transform ever goes back to a multiply,
   every team holding a below-replacement body GAINS score from an injury, and the giveaway is that a
   team nobody marked changes at all. */
let untouchedMoved = 0;
for (let r = 2; r <= 12; r++) if (Math.abs(iS[r] - hs[r]) > 0.001) untouchedMoved++;
ok(untouchedMoved === 0, `no team without a marked player changed score at all (${untouchedMoved} did)`);
ok(iS[1] < hs[1] && Object.keys(iS).every((r) => iS[r] <= hs[r] + 0.001), "and NO roster in the league got stronger because somebody got hurt");

const ladder = [
  ["healthy", null],
  ["limited", { status: INJ_LIMITED, setWeek: 6, at: 1 }],
  ["out 4 weeks", { status: INJ_WEEKS, weeks: 4, setWeek: 6, at: 1 }],
  ["out 8 weeks", { status: INJ_WEEKS, weeks: 8, setWeek: 6, at: 1 }],
  ["out for the season", { status: INJ_SEASON, setWeek: 6, at: 1 }],
];
console.log("\n§2  THE LADDER DISCRIMINATES");
/* ⚠⚠⚠⚠⚠ THIS SECTION WAS VACUOUS ON ITS FIRST RUN AND THAT IS WORTH RECORDING.
   It asserted that team 1's ROSTER SCORE never rose as the injury worsened, and it passed 5/5 —
   against four steps that all returned the identical −5.5. The reason is not a bug: `posQualityScore`
   floors a FILLED starting slot at the empty-slot penalty (−25), deliberately, so that holding a real
   body can never score worse than holding nobody. Team 1 has exactly one quarterback, so the moment he
   is docked at all the slot hits that floor and stays there — "limited" and "out for the year" are
   genuinely the same number to that roster, and a check that only reads it cannot tell a working
   discount from one that is jammed at maximum.
   ⭐ THE PORTABLE LESSON, AGAIN: a check that passes is not the same as a check that BITES. So the
     ladder is now read where it is unclamped — the player's own VBD, which is the input every consumer
     downstream actually reads — and the section asserts NON-DEGENERACY out loud before trusting it. */
let prevV = Infinity, distinct = new Set();
ladder.forEach(([label, e]) => {
  const v = injResolve(pool, star.sid, e ? injCtxFor(data, { [String(star.sid)]: e }) : null).vbd;
  ok(v <= prevV + 0.001, `${label}: ${star.name} is worth ${v} — no more than the step before`);
  prevV = v; distinct.add(v);
});
ok(distinct.size === ladder.length, `and all ${ladder.length} rungs give DIFFERENT values (${distinct.size} distinct) — the ladder is not jammed`);

/* The team score is still checked, but only for the direction it CAN move, with the clamp acknowledged. */
let prevS = Infinity;
ladder.forEach(([label, e]) => {
  const sc = scoreMap(leaguePower(data, pool, e ? injCtxFor(data, { [String(star.sid)]: e }) : null))[1];
  ok(sc <= prevS + 0.001, `${label}: team 1 scores ${sc.toFixed(1)} — never better than the step before`);
  prevS = sc;
});

console.log("\n§3  DYNASTY GIVES A DIFFERENT — AND CORRECT — ANSWER");
/* ⚠ A SEPARATE LEAGUE, NOT THE SAME ONE RELABELLED. The dynasty value model runs inside `buildPlayers`
   and changes the pool itself, so flipping `cfg.type` on an existing pool would test nothing. */
const dyn = makeLeague(DYNASTY);
const dStar = dyn.data.teams[0].players.map((id) => dyn.pool.bySid.get(String(id))).filter(Boolean).sort((a, b) => (b.pts || 0) - (a.pts || 0))[0];
const dInj = { [String(dStar.sid)]: { status: INJ_SEASON, setWeek: 6, at: 1 } };
const dCtx = injCtxFor(dyn.data, dInj);
ok(dCtx.dynasty === true, "injCtxFor reads the dynasty flag out of the league's own cfg");
const dHealthy = scoreMap(leaguePower(dyn.data, dyn.pool, null))[1];
const dHurt = scoreMap(leaguePower(dyn.data, dyn.pool, dCtx))[1];
ok(dHurt < dHealthy, `a dynasty roster still takes a hit (${dHealthy.toFixed(1)} → ${dHurt.toFixed(1)})`);

const rLoss = (hs[1] - iS[1]) / Math.abs(hs[1] || 1);
const dLoss = (dHealthy - dHurt) / Math.abs(dHealthy || 1);
/* ⭐⭐⭐⭐ THE ONE THAT PROTECTS TREY'S DYNASTY LEAGUES. Without damping, this feature would tell him to
   sell a franchise quarterback for pennies the week he got hurt — the single most expensive piece of
   advice the app is capable of giving. The unit suite asserts the factor; this asserts that the factor
   survives all the way through the real pool, the real value model and the real scorer. */
ok(dLoss < rLoss, `and it is a SMALLER hit than redraft takes (dynasty ${(dLoss * 100).toFixed(1)}% vs redraft ${(rLoss * 100).toFixed(1)}%) — an injured star is still a franchise asset`);

console.log("\n§4  THE RESOLVER ITSELF");
const raw = pool.bySid.get(String(star.sid));
const viaInj = injResolve(pool, star.sid, ictx);
ok(viaInj.pts < raw.pts, "injResolve returns a discounted copy");
ok(pool.bySid.get(String(star.sid)).pts === raw.pts, "and does NOT mutate the shared, format-cached pool entry");
ok(injResolve(pool, star.sid, null).pts === raw.pts, "with no context it hands back the pool entry untouched");
const other = data.teams[1].players[0];
ok(injResolve(pool, other, ictx).pts === pool.bySid.get(String(other)).pts, "and leaves everyone else alone");
ok(injResolve(pool, "no-such-player-9999", ictx) == null, "an id the pool has never heard of resolves to null rather than an invented body");

console.log("\n§5  hubWeeks — ONE DEFINITION OF THE SEASON WINDOW");
ok(hubWeeks({ week: 6, regularSeasonWeeks: 14 }).weeksLeft === 9, "week 6 of 14 leaves 9");
ok(hubWeeks({ week: 6, playoffStartWeek: 15 }).weeksLeft === 9, "and derives the same from a playoff start week");
ok(hubWeeks({ week: 14, regularSeasonWeeks: 14 }).weeksLeft === 1, "the last week leaves one, never zero");
ok(hubWeeks({}).weeksLeft === 14, "an empty payload falls back to a 14-week regular season");

console.log(`\n${n - failed}/${n} PASS${failed ? ` — ${failed} FAILED` : ""}`);
process.exit(failed ? 1 : 0);
