/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   TREY'S 29bk NOTES — plan29bk
     §1 "when you hover a team on the 'this week' can you make them highlight yellow to show that you can click
        them... I also want people to know you can click on these to look into the league"
     §2 "I'm looking at a re-draft league and there are still draft picks (it's not eligible to trade draft picks)"
     §3 "on the hover for 'rosters' on the deals worth sending... They are dramatically bleeding off the widget"
   (The grade scale change is pinned in probe/plan29bf-grade.mjs.)
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import { chromium } from 'playwright';
const APP = 'http://localhost:4174/', STUB = 'http://localhost:5055';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { console.log(`  ${c ? 'PASS' : 'FAIL'}  ${n}${x !== '' ? `   [${x}]` : ''}`); c ? pass++ : fail++; };
const post = (p, b) => fetch(STUB + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b || {}) }).then((r) => r.json()).catch(() => null);
const CFG = { teams: 12, rounds: 15, slot: 1, type: 'redraft', sf: false, tePremMult: 0, order: 'snake',
  start: { QB: 1, RB: 2, WR: 2, TE: 1, FLEX: 1, SUPER: 0, K: 1, DST: 1 }, scoring: { rec: 1 }, caps: {}, keepers: [] };
const lg = (id, name, lid, type) => { const c = { platform: 'sleeper', leagueId: lid, username: 'trey', ownerUsername: 'trey' };
  return { id, name, created: 'x', cfg: { ...CFG, type: type || 'redraft', name, connect: c }, picks: [], preds: [], mocks: [], connect: c, sleeperLeagueId: lid }; };
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const errs = [];
const open = async (leagues, route) => {
  const page = await (await b.newContext({ viewport: { width: 1450, height: 1100 } })).newPage();
  page.on('pageerror', (e) => errs.push(String(e)));
  await page.goto(APP, { waitUntil: 'domcontentloaded' });
  await page.evaluate(([l, r]) => { localStorage.clear(); localStorage.setItem('fdc:token', 't'); localStorage.setItem('fdcTourSeen', '1');
    localStorage.setItem('fdc:gs-state', JSON.stringify({ user: { email: 'trey.rose@pirates.com', paid: true, admin: true, rankSets: [], sleeperUsername: 'trey', sleeperUserId: 's1', homeView: 'season' }, leagues: l, funMocks: [] }));
    sessionStorage.setItem('gs-nav', JSON.stringify(r)); }, [leagues, route]);
  await page.reload({ waitUntil: 'domcontentloaded' });
  return page;
};

/* ══ §1 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §1 the This week rows light up gold and open the league ==');
await post('/stub/reset'); await post('/stub/live', { mode: 'on' });
{
  const L = [lg('H1', 'Hub Fixture League', 'hub-lg-1'), lg('H2', 'Superflex 3WR League', 'hub-lg-2')];
  const page = await open(L, { route: 'home' });
  await page.waitForSelector('[data-homeweekrow]', { timeout: 30000 }); await page.waitForTimeout(600);
  ok('1 · (fixture) the live table is on the home page', (await page.$$('[data-homeweekrow]')).length === 2);
  ok('1a · ⭐⭐⭐⭐ a line says the leagues can be clicked', !!(await page.$('[data-homeweekhint]')), (await page.$eval('[data-homeweekhint]', (x) => x.textContent).catch(() => '')).trim());
  const row = await page.$('[data-homeweekrow="Hub Fixture League"]');
  const before = await row.evaluate((x) => ({ bg: getComputedStyle(x).backgroundImage, go: getComputedStyle(x.querySelector('.hwgo')).opacity }));
  await row.hover(); await page.waitForTimeout(350);
  /* the name must turn the theme's gold: the same colour the gold edge is drawn in */
  const after = await row.evaluate((x) => ({ bg: getComputedStyle(x).backgroundImage, shadow: getComputedStyle(x).boxShadow, name: getComputedStyle(x.querySelector('.hwname')).color, go: getComputedStyle(x.querySelector('.hwgo')).opacity, cursor: getComputedStyle(x).cursor }));
  ok('1b · ⭐⭐⭐⭐⭐ hovering a row washes it gold with a gold edge, and the name turns gold', before.bg === 'none' && /gradient/.test(after.bg) && /inset/.test(after.shadow) && after.shadow.startsWith(after.name), `${after.bg.slice(0, 50)} | ${after.shadow.slice(0, 40)} | name ${after.name}`);
  ok('1c · ⭐⭐⭐⭐ an "Open ›" appears on hover, and the pointer says clickable', Number(before.go) === 0 && Number(after.go) === 1 && after.cursor === 'pointer', `opacity ${before.go}→${after.go}, cursor ${after.cursor}`);
  /* click an empty part of the row (the record cell), not a button */
  await (await row.$('[data-homeweekrec]')).click(); await page.waitForTimeout(2500);
  ok('1d · ⭐⭐⭐⭐⭐ clicking anywhere on the row opens that league', !!(await page.$('[data-hubnav]')));
  await page.context().close();
}

/* ══ §2 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §2 no draft picks in a redraft league ==');
await post('/stub/reset');
{
  const page = await open([lg('HR', 'Redraft With Stale Picks', 'hub-lg-rd')], { route: 'teamHub', activeId: null, hubLeagueId: 'hub-lg-rd' });
  await page.waitForSelector('[data-hubnav]', { timeout: 30000 }); await page.waitForTimeout(2000);
  await page.click('[data-hubgroup="moves"]'); await page.click('[data-hubtabbtn="trades"]'); await page.click('[data-tsectab="calc"]'); await page.waitForTimeout(500);
  await (await page.$('select[data-tbside-select="b"]')).selectOption({ index: 2 }); await page.waitForTimeout(600);
  const n = (await page.$$('[data-tbpick]')).length;
  ok('2 · ⭐⭐⭐⭐⭐ a redraft league shows no draft picks even when an older backend sends them', n === 0, `${n} picks`);
  await page.context().close();
  const dp = await open([lg('HD', 'Dynasty Fixture League', 'hub-lg-dyn', 'dynasty')], { route: 'teamHub', activeId: null, hubLeagueId: 'hub-lg-dyn' });
  await dp.waitForSelector('[data-hubnav]', { timeout: 30000 }); await dp.waitForTimeout(2000);
  await dp.click('[data-hubgroup="moves"]'); await dp.click('[data-hubtabbtn="trades"]'); await dp.click('[data-tsectab="calc"]'); await dp.waitForTimeout(500);
  await (await dp.$('select[data-tbside-select="b"]')).selectOption({ index: 2 }); await dp.waitForTimeout(600);
  ok('2a · a dynasty league still has them', (await dp.$$('[data-tbpick]')).length > 0);
  await dp.context().close();
}

/* ══ §3 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §3 the Rosters card stays inside itself and inside the window ==');
for (const vw of [1450, 1100]) {
  const page = await open([lg('H1', 'Hub Fixture League', 'hub-lg-1')], { route: 'teamHub', activeId: null, hubLeagueId: 'hub-lg-1' });
  await page.setViewportSize({ width: vw, height: 1100 });
  await page.waitForSelector('[data-hubnav]', { timeout: 30000 }); await page.waitForTimeout(2000);
  await page.click('[data-hubgroup="moves"]'); await page.click('[data-hubtabbtn="trades"]'); await page.click('[data-tsectab="deals"]'); await page.waitForTimeout(700);
  await (await page.$('[data-teamoutlookbtn]')).hover(); await page.waitForTimeout(500);
  const m = await page.$eval('[data-wkcard^="outlook-"]', (card) => {
    const cb = card.getBoundingClientRect();
    const over = [...card.querySelectorAll('td, th, table')].filter((el) => { const r = el.getBoundingClientRect(); return r.right > cb.right + 1 || el.scrollWidth > el.clientWidth + 1; }).length;
    return { left: cb.left, right: cb.right, vw: window.innerWidth, over, sw: card.scrollWidth, cw: card.clientWidth };
  }).catch(() => null);
  ok(`3 · ⭐⭐⭐⭐⭐ at ${vw}px no cell runs past the card's edge`, !!m && m.over === 0 && m.sw <= m.cw + 1, m ? JSON.stringify(m) : 'no card');
  ok(`3a · and the card is inside the window at ${vw}px`, !!m && m.left >= 0 && m.right <= m.vw, m ? `${Math.round(m.left)}..${Math.round(m.right)} of ${m.vw}` : '');
  await page.context().close();
}

await post('/stub/reset');
ok('4 · nothing threw', errs.length === 0, errs.slice(0, 2).join(' || ').slice(0, 160));
await b.close();
console.log(`\n  ${pass} PASS  ${fail} FAIL`);
process.exit(fail ? 1 : 0);
