/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   TREY'S 29bi NOTES — plan29bi
     §1 IDEAS QUALITY. "trade both of my QBs (Lamar Jackson + Bo Nix) for him... Garrett Wilson + Brian Thomas
        for Chuba Hubbard... but Thomas for Hubbard is a B- and much more realistic (but that's not on there)"
        · no idea leaves me with fewer players at a position than I start there
        · no padded pair: when a pair is offered, neither man alone is a fair price (checked by loading each
          single into the calculator and reading its fairness)
        · no idea is a D or F for me unless the list says every fair price costs my lineup
     §2 "click QB and ideas automatically populate" + "make it clear that you can click on those positions"
     §3 "somewhere where I can hover on there to see team outlooks" (Deals cards)
     §4 "game day... a pop up that I can see on my current screen"
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import { chromium } from 'playwright';
import fs from 'node:fs';
const APP = 'http://localhost:4174/', STUB = 'http://localhost:5055';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { console.log(`  ${c ? 'PASS' : 'FAIL'}  ${n}${x !== '' ? `   [${x}]` : ''}`); c ? pass++ : fail++; };
const post = (p, b) => fetch(STUB + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b || {}) }).then((r) => r.json()).catch(() => null);
const PACK = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-pack.json', import.meta.url), 'utf8'));
const HUB = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-hub.json', import.meta.url), 'utf8'));
const byId = new Map(PACK.players.map((p) => [p.id, p])), byName = new Map(PACK.players.map((p) => [p.name, p]));
const REQ = HUB.cfg.start;
const myIds = HUB.teams.find((t) => t.rosterId === HUB.myRosterId).players;
const myPlayers = myIds.map((id) => byId.get(id)).filter(Boolean);

const CFG = { teams: 12, rounds: 15, slot: 1, type: 'redraft', sf: false, tePremMult: 0, order: 'snake',
  start: { QB: 1, RB: 2, WR: 2, TE: 1, FLEX: 1, SUPER: 0, K: 1, DST: 1 }, scoring: { rec: 1 }, caps: {}, keepers: [] };
const c = { platform: 'sleeper', leagueId: 'hub-lg-1', username: 'trey', ownerUsername: 'trey' };
const L1 = { id: 'H1', name: 'Hub Fixture League', created: 'x', cfg: { ...CFG, name: 'Hub Fixture League', connect: c }, picks: [], preds: [], mocks: [], connect: c, sleeperLeagueId: 'hub-lg-1' };

const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const errs = [];
await post('/stub/reset'); await post('/stub/std', { mode: 'on' });
const page = await (await b.newContext({ viewport: { width: 1450, height: 1500 } })).newPage();
page.on('pageerror', (e) => errs.push(String(e)));
await page.goto(APP, { waitUntil: 'domcontentloaded' });
await page.evaluate((l) => {
  localStorage.clear(); localStorage.setItem('fdc:token', 't'); localStorage.setItem('fdcTourSeen', '1');
  localStorage.setItem('fdc:gs-state', JSON.stringify({ user: { email: 'trey.rose@pirates.com', paid: true, admin: true, rankSets: [], sleeperUsername: 'trey', sleeperUserId: 's1', homeView: 'season' }, leagues: [l], funMocks: [] }));
  sessionStorage.setItem('gs-nav', JSON.stringify({ route: 'teamHub', activeId: null, hubLeagueId: 'hub-lg-1' }));
}, L1);
await page.reload({ waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-hubnav]', { timeout: 30000 }); await page.waitForTimeout(2500);
const sec = async (k) => { await page.click('[data-hubgroup="moves"]'); await page.waitForTimeout(250); await page.click('[data-hubtabbtn="trades"]'); await page.waitForTimeout(400);
  await page.click(`[data-tsectab="${k}"]`); await page.waitForTimeout(700); };
const calcFair = async (theirTeam, give, get) => {
  await page.evaluate(() => {});
  await (await page.$('select[data-tbside-select="b"]')).selectOption({ label: theirTeam }); await page.waitForTimeout(500);
  for (const n of give) await page.click(`[data-tbcol="give"] [data-tbplayer="${n}"]`);
  for (const n of get) await page.click(`[data-tbcol="get"] [data-tbplayer="${n}"]`);
  await page.waitForTimeout(700);
  const f = await page.$eval('[data-tbresult]', (x) => Number(x.getAttribute('data-tbfair'))).catch(() => null);
  const g = await page.$eval('[data-tbgrade]', (x) => x.getAttribute('data-tbgrade')).catch(() => null);
  return { f, g };
};

/* ══ §1 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §1 Ideas: no emptied position, no padding, nothing that is a loss for me ==');
await sec('calc');
const targets = [];
for (const rid of [2, 5, 8]) {
  const t = HUB.teams.find((q) => q.rosterId === rid);
  const ps = t.players.map((id) => byId.get(id)).filter((p) => p && ['RB', 'WR'].includes(p.pos)).sort((a, b) => a.adp - b.adp);
  if (ps[0]) targets.push({ team: t.teamName, p: ps[0] });
}
let nIdeas = 0, holes = [], padded = [], losers = [];
for (const tg of targets) {
  await (await page.$('select[data-tbside-select="b"]')).selectOption({ label: tg.team }); await page.waitForTimeout(600);
  await page.click(`[data-tbcol="get"] [data-tbplayer="${tg.p.name}"]`); await page.waitForTimeout(300);
  await page.click('[data-tbideas]'); await page.waitForTimeout(2500);
  const costly = !!(await page.$('[data-tbideascostly]'));
  const ideas = await page.$$eval('[data-tbidea]', (xs) => xs.map((x) => ({ give: x.getAttribute('data-tbidea').split(' + '), g: x.querySelector('[data-ideagrade]').getAttribute('data-ideagrade') })));
  nIdeas += ideas.length;
  for (const idea of ideas) {
    const left = {}; myPlayers.filter((p) => !idea.give.includes(p.name)).forEach((p) => { left[p.pos] = (left[p.pos] || 0) + 1; });
    left[tg.p.pos] = (left[tg.p.pos] || 0) + 1;
    ['QB', 'RB', 'WR', 'TE'].forEach((pos) => { if ((left[pos] || 0) < (REQ[pos] || 0)) holes.push(`${idea.give.join('+')} leaves ${pos} ${left[pos] || 0}`); });
    if (!costly && ['D', 'F'].includes(idea.g)) losers.push(`${idea.g} ${idea.give.join('+')}`);
  }
  /* padding: price each member of a pair alone */
  for (const idea of ideas.filter((x) => x.give.length === 2 && x.give.every((n) => byName.has(n)))) {
    for (const one of idea.give) {
      await page.click(`[data-tbcol="get"] [data-tbplayer="${tg.p.name}"]`).catch(() => {});   // clear
      await page.evaluate(() => {});
      const { f } = await calcFair(tg.team, [one], [tg.p.name]);
      if (f != null && f >= 0.6) padded.push(`${idea.give.join('+')} (but ${one} alone is ${Math.round(f * 100)}% even)`);
      // reset both columns
      await page.$$eval('[data-tbon="1"]', (xs) => xs.forEach((x) => x.click())); await page.waitForTimeout(200);
    }
  }
  await page.$$eval('[data-tbon="1"]', (xs) => xs.forEach((x) => x.click())); await page.waitForTimeout(200);
}
ok('1 · (fixture) the Ideas button produced ideas for several targets', nIdeas >= 3, `${nIdeas} ideas over ${targets.length} targets`);
ok('1a · ⭐⭐⭐⭐⭐ no idea leaves me short of starters at a position (the two-QB offer)', holes.length === 0, holes.slice(0, 3).join(' | '));
ok('1b · ⭐⭐⭐⭐⭐ no padded pair: a pair is only offered when neither man alone is a fair price', padded.length === 0, padded.slice(0, 3).join(' | '));
ok('1c · ⭐⭐⭐⭐ no D or F for me unless the list says every fair price costs my lineup', losers.length === 0, losers.join(' | '));

/* ══ §2 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §2 click a position, get specific offers ==');
await sec('market');
ok('2 · the market says its positions are clickable', !!(await page.$('[data-mktclickhint]')));
let posDone = null;
for (const pos of ['RB', 'WR', 'QB', 'TE']) {
  if (!(await page.$(`[data-mktpos="${pos}"]`))) continue;
  await page.click(`[data-mktpos="${pos}"]`); await page.waitForTimeout(300);
  await page.waitForFunction(() => !document.querySelector('[data-posideasbusy]'), null, { timeout: 30000 }).catch(() => {});
  const rows = await page.$$eval('[data-posidea]', (xs) => xs.map((x) => ({ k: x.getAttribute('data-posidea'), g: (x.querySelector('[data-ideagrade]') || {}).getAttribute?.('data-ideagrade') })));
  if (rows.length) { posDone = { pos, rows }; break; }
  if (await page.$('[data-mktback]')) { await page.click('[data-mktback]'); await page.waitForTimeout(300); }
}
ok('2a · ⭐⭐⭐⭐⭐ clicking a position fills in specific, graded offers for it', !!posDone && posDone.rows.every((r) => r.g), posDone ? `${posDone.pos}: ${posDone.rows.map((r) => `${r.g} ${r.k}`).join(' | ')}` : 'none');
if (posDone) {
  const first = posDone.rows[0];
  await page.click('[data-posideaload]'); await page.waitForTimeout(1200);
  const g = await page.$eval('[data-tbgrade]', (x) => x.getAttribute('data-tbgrade')).catch(() => null);
  ok('2b · Load puts it in the calculator with the same grade', g === first.g, `${first.k}: ${first.g} → ${g}`);
}

/* ══ §3 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §3 team outlook on a Deals card ==');
await sec('deals');
const card0 = await page.$('[data-tbrec]');
const deal = await card0.evaluate((x) => ({ give: x.querySelector('[data-tbrecgive]').getAttribute('data-tbrecgive'), get: x.querySelector('[data-tbrecget]').getAttribute('data-tbrecget') }));
await (await card0.$('[data-teamoutlook]')).hover(); await page.waitForTimeout(500);
const oc = await page.$eval('[data-wkcard^="outlook-"]', (x) => ({ text: x.innerText, rows: [...x.querySelectorAll('tbody tr')].map((r) => [...r.querySelectorAll('td')].map((td) => td.innerText)) })).catch(() => null);
ok('3 · ⭐⭐⭐⭐⭐ hovering the team shows both rosters by position', !!oc && oc.rows.length >= 4, oc ? oc.rows.map((r) => r[0]).join(',') : 'no card');
if (oc) {
  const gp = byName.get(deal.get).pos, sp = byName.get(deal.give).pos;
  ok('3a · the positions in the deal come first', [gp, sp].includes(oc.rows[0][0]), `${oc.rows[0][0]} (deal: ${sp} for ${gp})`);
  const mineAt = (pos) => (oc.rows.find((r) => r[0] === pos) || [])[2] || '';
  ok('3b · ⭐⭐⭐⭐⭐ "You, after" is my room AFTER the deal: the man I send is gone, the man I get is there', !mineAt(sp).includes(deal.give) && mineAt(gp).includes(deal.get), `${sp}: ${mineAt(sp)} | ${gp}: ${mineAt(gp)}`);
}

/* ══ §4 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §4 Game Day as a popup ==');
await page.mouse.move(5, 5);
await page.click('[data-hubgroup="team"]'); await page.waitForTimeout(300);
await page.click('[data-hubtabbtn="gameday"]'); await page.waitForTimeout(2500);
const pop = await page.evaluate(() => ({ popup: !!document.querySelector('[data-gdpopup]'), screen: !!document.querySelector('[data-gdpopup] [data-screen="gameday"]'), hub: !!document.querySelector('[data-hubnav]') }));
ok('4 · ⭐⭐⭐⭐⭐ Game Day opens over the hub, which is still there underneath', pop.popup && pop.screen && pop.hub, JSON.stringify(pop));
await page.keyboard.press('Escape'); await page.waitForTimeout(300);
ok('4a · Escape closes it, back on the same hub', !(await page.$('[data-gdpopup]')) && !!(await page.$('[data-hubnav]')));

ok('5 · nothing threw', errs.length === 0, errs.slice(0, 2).join(' || ').slice(0, 160));
await b.close();
console.log(`\n  ${pass} PASS  ${fail} FAIL`);
process.exit(fail ? 1 : 0);
