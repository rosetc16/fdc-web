/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   YAHOO, GREYED UNTIL YAHOO SAYS YES — plan29bj
   Trey: "It looks like the Yahoo connection is still waiting for Yahoo to approve it. Can you add a note on
   there that grey's it out and states that we are working on connection."
   §1 not configured (today): the Yahoo tile is disabled, marked SOON, and the note says we're working on it.
   §2 configured (the day the Render keys go in): the same tile works, the note is gone. No build needed.
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import { chromium } from 'playwright';
const APP = 'http://localhost:4174/', STUB = 'http://localhost:5055';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { console.log(`  ${c ? 'PASS' : 'FAIL'}  ${n}${x !== '' ? `   [${x}]` : ''}`); c ? pass++ : fail++; };
const post = (p, b) => fetch(STUB + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b || {}) }).then((r) => r.json()).catch(() => null);
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const errs = [];
const openPicker = async () => {
  const page = await (await b.newContext({ viewport: { width: 1300, height: 1100 } })).newPage();
  page.on('pageerror', (e) => errs.push(String(e)));
  await page.goto(APP, { waitUntil: 'domcontentloaded' });
  await page.evaluate(() => { localStorage.clear(); localStorage.setItem('fdc:token', 't'); localStorage.setItem('fdcTourSeen', '1');
    localStorage.setItem('fdc:gs-state', JSON.stringify({ user: { email: 'trey.rose@pirates.com', paid: true, admin: true, rankSets: [], sleeperUsername: 'trey', sleeperUserId: 's1' }, leagues: [], funMocks: [] }));
    sessionStorage.setItem('gs-nav', JSON.stringify({ route: 'home' })); });
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-connecttop]', { timeout: 30000, state: 'attached' }); await page.waitForTimeout(800);
  await page.$eval('[data-connecttop]', (x) => x.click());
  await page.waitForSelector('[data-plat="yahoo"]', { timeout: 15000 }); await page.waitForTimeout(1200);
  return page;
};
const read = (page) => page.evaluate(() => { const y = document.querySelector('[data-plat="yahoo"]');
  return { disabled: y.disabled, pending: y.getAttribute('data-platpending'), soon: !!y.querySelector('[data-platsoon]'), note: (document.querySelector('[data-yahoopending]') || {}).textContent || '',
    sleeperOk: !document.querySelector('[data-plat="sleeper"]').disabled }; });

console.log('\n== §1 Yahoo not approved yet ==');
await post('/stub/reset');
let page = await openPicker();
let r = await read(page);
ok('1 · ⭐⭐⭐⭐⭐ the Yahoo tile is greyed out and cannot be picked', r.disabled && r.pending === '1' && r.soon, JSON.stringify({ disabled: r.disabled, soon: r.soon }));
ok('1a · ⭐⭐⭐⭐⭐ and the note says we are working on the connection', /working on the connection/.test(r.note), r.note.slice(0, 90));
ok('1b · the other platforms are untouched', r.sleeperOk);
ok('1c · the note has no long dashes (Trey\'s house style)', !/[—–]/.test(r.note));
await page.click('[data-plat="yahoo"]', { force: true }).catch(() => {});
await page.waitForTimeout(300);
ok('1d · clicking it anyway does nothing', !(await page.$('[data-platyahoo]')));
await page.context().close();

console.log('\n== §2 the day Yahoo approves ==');
await post('/stub/yahoo', { configured: true });
page = await openPicker();
r = await read(page);
ok('2 · ⭐⭐⭐⭐⭐ with the keys in, the tile is live and the note is gone, with no new build', !r.disabled && r.pending === '0' && !r.soon && !r.note, JSON.stringify(r));
await page.click('[data-plat="yahoo"]'); await page.waitForTimeout(300);
ok('2a · and it opens the Yahoo sign-in step', !!(await page.$('[data-platyahoo]')));
await page.context().close();
await post('/stub/reset');

ok('3 · nothing threw', errs.length === 0, errs.slice(0, 2).join(' || ').slice(0, 160));
await b.close();
console.log(`\n  ${pass} PASS  ${fail} FAIL`);
process.exit(fail ? 1 : 0);
