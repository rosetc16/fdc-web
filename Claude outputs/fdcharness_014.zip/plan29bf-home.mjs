/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   THE HOME PAGE SAYS "LOADING" WHILE IT IS LOADING — plan29bf-home
   Trey: "when you go to the home page of the site, it takes 2-4 seconds for the leagues that you're
   connected to to render on the screen. Can you show some kind of loading mechanism for a few seconds while
   that is waiting to come up. I want people to not just click other buttons if that's what they were
   looking for."
   Every /api/ answer is slowed to 2.5s by the stub (/stub/latency), which is the wait he described.
     §1 FRESH DEVICE — the leagues come from the server restore. While they do: a loader, and NOT the
        "0 leagues" / "Let's get you drafting" / "Connect Sleeper" onboarding that invited the wrong click.
        Afterwards: the leagues, and the loader gone.
     §2 RETURNING DEVICE — the leagues are local, the week's board is not. The strip's slot shows a
        skeleton instead of nothing, and it clears when the board answers.
     §3 A REAL NEW ACCOUNT — no leagues anywhere. The loader must END and hand over to the onboarding,
        or the fix has broken the first-run path it was hiding.
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import { chromium } from 'playwright';
const APP = 'http://localhost:4174/', STUB = 'http://localhost:5055';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { console.log(`  ${c ? 'PASS' : 'FAIL'}  ${n}${x !== '' ? `   [${x}]` : ''}`); c ? pass++ : fail++; };
const post = (p, b) => fetch(STUB + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b || {}) }).then((r) => r.json()).catch(() => null);
const putState = (st) => fetch(`${STUB}/api/state`, { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ state: st }) });

const CFG = { teams: 12, rounds: 15, slot: 1, type: 'redraft', sf: false, start: { QB: 1, RB: 2, WR: 2, TE: 1, FLEX: 1, K: 1, DST: 1 }, scoring: { rec: 1 }, caps: {}, keepers: [] };
const lg = (id, name, lid) => { const c = { platform: 'sleeper', leagueId: lid, username: 'trey', ownerUsername: 'trey' };
  return { id, name, created: 'x', cfg: { ...CFG, name, connect: c }, picks: [], preds: [], mocks: [], connect: c, sleeperLeagueId: lid }; };
const L = [lg('H1', 'Hub Fixture League', 'hub-lg-1'), lg('H2', 'Second League', 'hub-lg-3')];

const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const errs = [];
const open = async (localLeagues) => {
  const page = await (await b.newContext({ viewport: { width: 1300, height: 1100 } })).newPage();
  page.on('pageerror', (e) => errs.push(String(e)));
  await page.goto(APP, { waitUntil: 'domcontentloaded' });
  await page.evaluate((l) => { localStorage.clear(); localStorage.setItem('fdc:token', 't'); localStorage.setItem('fdcTourSeen', '1');
    localStorage.setItem('fdc:gs-state', JSON.stringify({ user: { email: 'trey.rose@pirates.com', paid: true, admin: true, rankSets: [], sleeperUsername: 'trey', sleeperUserId: 's1', homeView: 'season' }, leagues: l, funMocks: [] }));
    sessionStorage.setItem('gs-nav', JSON.stringify({ route: 'home' })); }, localLeagues);
  await page.reload({ waitUntil: 'domcontentloaded' });
  return page;
};
const snap = (page) => page.evaluate(() => {
  const vis = (el) => !!el && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== 'hidden';
  const txt = document.body.innerText;
  return {
    leagues: vis(document.querySelector('[data-homeloading="leagues"]')),
    week: vis(document.querySelector('[data-homeloading="week"]')),
    onboarding: /Let's get you drafting/.test(txt),
    newHere: /New here\? Get started/.test(txt),
    noLeagues: /No leagues yet/.test(txt),
    doors: document.querySelectorAll('[data-openseason]').length,
    home: !!document.querySelector('[data-homelibrary]'),
  };
});
/* Wait until the home page itself is on screen (past the boot splash), then return the first snapshot. */
const firstHome = async (page) => { await page.waitForSelector('[data-homelibrary]', { timeout: 30000, state: 'attached' }); return snap(page); };

/* ══ §1 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §1 fresh device: the leagues come from the server, 2.5s late ==');
{
  await post('/stub/reset'); await putState({ leagues: L, funMocks: [], feedback: [] }); await post('/stub/latency', { ms: 2500 });
  const page = await open([]);
  const s0 = await firstHome(page);
  ok('1 · (the wait is real) the home page is up before the leagues are', s0.doors === 0, `doors ${s0.doors}`);
  ok('1a · ⭐⭐⭐⭐⭐ a "loading your leagues" block is on screen while they come', s0.leagues);
  ok('1b · ⭐⭐⭐⭐⭐ and the onboarding is NOT — no "Let\'s get you drafting", no "New here?", no "No leagues yet"', !s0.onboarding && !s0.newHere && !s0.noLeagues,
    JSON.stringify({ onboarding: s0.onboarding, newHere: s0.newHere, noLeagues: s0.noLeagues }));
  const counts = await page.$$eval('.num', (xs) => xs.slice(0, 3).map((x) => x.textContent.trim()));
  ok('1c · the header does not claim 0 leagues while it does not know', !counts.includes('0') || counts[0] === '–', counts.join(' / '));
  await page.waitForFunction(() => document.querySelectorAll('[data-openseason]').length > 0, null, { timeout: 25000 }).catch(() => {});
  await page.waitForTimeout(600);
  const s1 = await snap(page);
  ok('1d · ⭐⭐⭐⭐ the leagues arrive and the loader goes', s1.doors >= 2 && !s1.leagues, `doors ${s1.doors}, loader ${s1.leagues}`);
  await page.context().close();
}

/* ══ §2 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §2 returning device: the leagues are known, this week\'s board is 2.5s late ==');
{
  await post('/stub/reset'); await putState({ leagues: L, funMocks: [], feedback: [] }); await post('/stub/latency', { ms: 2500 });
  const page = await open(L);
  const s0 = await firstHome(page);
  ok('2 · the leagues are on screen at once (no league loader on a device that has them)', s0.doors >= 2 && !s0.leagues, `doors ${s0.doors}`);
  let sawWeek = s0.week;
  for (let i = 0; i < 10 && !sawWeek; i++) { await page.waitForTimeout(150); sawWeek = (await snap(page)).week; }
  ok('2a · ⭐⭐⭐⭐⭐ the "This week" slot shows a loading skeleton instead of nothing', sawWeek);
  await page.waitForFunction(() => !document.querySelector('[data-homeloading="week"]'), null, { timeout: 20000 }).catch(() => {});
  const s1 = await snap(page);
  ok('2b · and it clears once the board answers', !s1.week);
  await page.context().close();
}

/* ══ §3 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §3 a genuinely new account: the loader must hand over to the onboarding ==');
{
  await post('/stub/reset'); await post('/stub/latency', { ms: 1500 });
  const page = await open([]);
  const s0 = await firstHome(page);
  ok('3 · the loader shows first here too (it cannot know yet)', s0.leagues && !s0.onboarding);
  await page.waitForFunction(() => /Let's get you drafting/.test(document.body.innerText), null, { timeout: 25000 }).catch(() => {});
  const s1 = await snap(page);
  ok('3a · ⭐⭐⭐⭐⭐ then the loader ENDS and the first-run guide appears', !s1.leagues && s1.onboarding, JSON.stringify(s1));
  await page.context().close();
}

await post('/stub/latency', { ms: 0 });
ok('4 · nothing threw', errs.length === 0, errs.slice(0, 2).join(' || ').slice(0, 160));
await b.close();
console.log(`\n  ${pass} PASS  ${fail} FAIL`);
process.exit(fail ? 1 : 0);
