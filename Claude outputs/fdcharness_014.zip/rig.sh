#!/bin/bash
# THE TEST RIG, started ONCE and VERIFIED — rebuilt b163.
#
# ⚠ THE CHECK AT THE BOTTOM IS THE WHOLE POINT. Starting the preview servers a second time without
#   killing the first leaves the ORIGINAL process holding the port, so `--outDir distb` appears on the
#   command line while the port is still serving `dist`. That cost an hour once: two suites went red with
#   eighteen failures that looked exactly like a code regression, and bisecting found nothing because
#   nothing was wrong. The asset hash the server hands out must match the folder it claims to serve.
set -u
cd /home/claude/work
for p in 4173 4174 5055; do fuser -k ${p}/tcp 2>/dev/null; done
sleep 2
( node hubstub/server.mjs > /tmp/stub.log 2>&1 & )
cd web/fdc-web
( npx vite preview --port 4173 --outDir dist  > /tmp/p73.log 2>&1 & )
( npx vite preview --port 4174 --outDir distb > /tmp/p74.log 2>&1 & )
sleep 7
ok=1
for pair in "4173 dist" "4174 distb"; do
  set -- $pair
  want=$(grep -o 'assets/index-[^"]*\.js' $2/index.html | head -1)
  got=$(curl -s localhost:$1/ | grep -o 'assets/index-[^"]*\.js' | head -1)
  if [ "$want" = "$got" ] && [ -n "$want" ]; then echo "  OK    :$1 serves $2 ($got)"; else echo "  WRONG :$1 serves $got, expected $2's $want"; ok=0; fi
done
curl -s -o /dev/null -w "  stub  :5055 -> %{http_code}\n" localhost:5055/api/health
[ $ok = 1 ] || { echo "RIG IS LYING TO YOU — fix before running any suite"; exit 1; }
echo "rig ready"
