import { chromium } from 'playwright';
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const p=await (await b.newContext({viewport:{width:1450,height:1600}})).newPage();
p.on('pageerror',e=>console.log('PAGEERR',String(e.message).slice(0,140)));
await p.goto('http://localhost:4173/',{waitUntil:'domcontentloaded'});
await p.evaluate(()=>{try{localStorage.clear();localStorage.setItem('fdcTourSeen','1');}catch{}});
await p.reload({waitUntil:'domcontentloaded'});
await p.waitForTimeout(14000);
console.log('buttons:', await p.evaluate(()=>[...document.querySelectorAll('button,a')].map(e=>(e.innerText||'').trim()).filter(t=>/demo|try|free/i.test(t)).slice(0,8)));
await p.evaluate(()=>{const t=[...document.querySelectorAll('button,a')].find(e=>/demo/i.test(e.innerText||''));if(t)t.click();});
await p.waitForTimeout(12000);
console.log('after demo:', await p.evaluate(()=>({
  boundary:/Something went wrong|Something hiccuped/i.test(document.body.innerText||''),
  cells:document.querySelectorAll('[data-cell],[data-boardcell],td').length,
  tb:document.querySelectorAll('[data-tbplayer],[data-comboslot]').length,
  text:(document.body.innerText||'').replace(/\s+/g,' ').slice(0,180)})));
await b.close();
