/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   TREY'S 29bm NOTES — plan29bm
     §1 Home "This week": "it isn't showing my record for each league", "my combined record through every
        league", "what do the red, yellow, and green dots... mean", "when you hover the projected score, I'd
        like to see a side by side of each team and the projected score".
     §2 Matchup: a starter traded away last week still in the lineup (Sleeper seeds the new week from the
        old one) must not show.
     §3 Hub free agents: "Higgins is on my IR... We should just ignore IR players for FA purposes."
     §4 My Week free agents: "I just lost... my 2 QBs... At a very minimum, that league should be
        recommending I pick up a QB."
     §5 My Week league activity: "show the trade grades next to each trade", the same letter the hub gives.
     §6 Game Day: "0-0-10... change these numbers to reflect the projections (and make it clear...)".
     §7 Review: hover the verdict chip for why; hover the result for both lineups side by side.
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import { chromium } from 'playwright';
const APP = 'http://localhost:4174/', STUB = 'http://localhost:5055';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { console.log(`  ${c ? 'PASS' : 'FAIL'}  ${n}${x !== '' ? `   [${x}]` : ''}`); c ? pass++ : fail++; };
const post = (p, b) => fetch(STUB + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b || {}) }).then((r) => r.json()).catch(() => null);
const CFG = { teams: 12, rounds: 15, slot: 1, type: 'redraft', sf: false, tePremMult: 0, order: 'snake',
  start: { QB: 1, RB: 2, WR: 2, TE: 1, FLEX: 1, SUPER: 0, K: 1, DST: 1 }, scoring: { rec: 1 }, caps: {}, keepers: [] };
const lg = (id, name, lid) => { const c = { platform: 'sleeper', leagueId: lid, username: 'trey', ownerUsername: 'trey' };
  return { id, name, created: 'x', cfg: { ...CFG, name, connect: c }, picks: [], preds: [], mocks: [], connect: c, sleeperLeagueId: lid }; };
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const errs = [];
const open = async (leagues, route, vp = { width: 1450, height: 1100 }) => {
  const page = await (await b.newContext({ viewport: vp })).newPage();
  page.on('pageerror', (e) => errs.push(String(e)));
  await page.goto(APP, { waitUntil: 'domcontentloaded' });
  await page.evaluate(([l, r]) => { localStorage.clear(); localStorage.setItem('fdc:token', 't'); localStorage.setItem('fdcTourSeen', '1');
    localStorage.setItem('fdc:gs-state', JSON.stringify({ user: { email: 'trey.rose@pirates.com', paid: true, admin: true, rankSets: [], sleeperUsername: 'trey', sleeperUserId: 's1', homeView: 'season' }, leagues: l, funMocks: [] }));
    sessionStorage.setItem('gs-nav', JSON.stringify(r)); }, [leagues, route]);
  await page.reload({ waitUntil: 'domcontentloaded' });
  return page;
};
/* My Week / Game Day / Review are not restored from the session, so walk in through the home menu. */
const inSeason = async (page, tab) => {
  await page.waitForSelector('button.menuitem', { state: 'attached', timeout: 30000 }); await page.waitForTimeout(800);
  await page.evaluate(() => {
    const btn = Array.from(document.querySelectorAll('button.menuitem')).find((e) => /my week/i.test((e.innerText || '').trim()))
      || Array.from(document.querySelectorAll('button')).find((e) => /^\s*My week\s*$/i.test(e.innerText || ''));
    if (btn) btn.click();
  });
  await page.waitForSelector('[data-inseasontabs]', { timeout: 30000 });
  if (tab) { await page.click(`button[data-inseasontab="${tab}"]`); }
  await page.waitForTimeout(1500);
};
const cardText = (page) => page.$eval('[data-wkcard]', (x) => x.innerText).catch(() => '');
const L1 = lg('H1', 'Hub Fixture League', 'hub-lg-1'), L2 = lg('H2', 'Superflex 3WR League', 'hub-lg-2'), LQ = lg('HQ', 'QB Crisis League', 'hub-lg-qb');

/* ══ §1 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §1 home This week: record per league, combined record, dot legend, projected side by side ==');
await post('/stub/reset'); await post('/stub/live', { mode: 'pregame' });
{
  const page = await open([L1, L2], { route: 'home' });
  await page.waitForSelector('[data-homeaheadrow]', { timeout: 30000 }); await page.waitForTimeout(800);
  const recs = await page.$$eval('[data-homeaheadrec]', (xs) => xs.map((x) => x.textContent.trim()));
  ok('1 · ⭐⭐⭐⭐⭐ every league row shows my record', recs.length === 2 && recs.every((r) => /^\d+-\d+/.test(r.replace(/[–−]/g, '-'))), recs.join(' | '));
  const comb = await page.$eval('[data-homecombined]', (x) => x.textContent.replace(/\s+/g, ' ').trim()).catch(() => '');
  ok('1a · ⭐⭐⭐⭐⭐ a combined record across every league sits under the table', /Across all 2 leagues/i.test(comb) && /12\D+4/.test(comb), comb);
  const leg = await page.$eval('[data-homedotlegend]', (x) => x.textContent.replace(/\s+/g, ' ').trim()).catch(() => '');
  ok('1b · ⭐⭐⭐⭐ the dots are explained (out, questionable, bye, clean)', /out/i.test(leg) && /question|check/i.test(leg) && /bye/i.test(leg) && /clean|good|set/i.test(leg), leg.slice(0, 120));
  await page.hover('[data-homeaheadproj]'); await page.waitForTimeout(400);
  const t = await cardText(page);
  ok('1c · ⭐⭐⭐⭐⭐ hovering the projected score shows both lineups side by side with projections', /you/i.test(t) && /them/i.test(t) && /Bo Nix/.test(t) && /Projected \d+(\.\d)? to \d+/.test(t) && (t.match(/\d+\.\d/g) || []).length >= 8, t.split('\n').slice(0, 4).join(' / '));
  await page.context().close();
}

/* ══ §2 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §2 a starter traded away last week does not show in Matchup ==');
await post('/stub/reset');
const hubQ = await (await fetch(`${STUB}/api/connect/sleeper/team-hub?league_id=hub-lg-qb`)).json();
const pack = await (await fetch(`${STUB}/api/player-pack`)).json();
const nameOf = (sid) => ((pack.players || []).find((p) => String(p.id) === String(sid)) || {}).name;
const meQ = hubQ.teams.find((t) => t.rosterId === hubQ.myRosterId);
const goneSid = meQ.starters[6], goneName = nameOf(goneSid);
ok('2 · (fixture) my lineup still holds a man who is on someone else\'s roster', !!goneName && !meQ.players.includes(goneSid), goneName);
{
  const page = await open([LQ], { route: 'teamHub', activeId: null, hubLeagueId: 'hub-lg-qb' });
  await page.waitForSelector('[data-hubnav]', { timeout: 30000 }); await page.waitForTimeout(2200);
  await page.click('[data-hubgroup="team"]'); await page.waitForTimeout(300);
  await page.click('[data-hubtabbtn="lineup"]'); await page.waitForTimeout(900);
  const body = await page.evaluate(() => document.body.innerText);
  ok('2a · ⭐⭐⭐⭐⭐ the traded player is not in my Matchup lineup', body.includes('Travis Hunter') && !body.includes(goneName), goneName);

  /* ══ §3 ═══════════════════════════════════════════════════════════════════════════════════════ */
  console.log('\n== §3 an IR player is never the drop or the comparison on the hub free agents ==');
  await page.click('[data-hubgroup="moves"]'); await page.waitForTimeout(300);
  await page.click('[data-hubtabbtn="freeagents"]'); await page.waitForTimeout(1200);
  const fa = await page.evaluate(() => document.body.innerText);
  ok('3 · (fixture) the free-agent list rendered', /pts\/wk/.test(fa));
  ok('3a · ⭐⭐⭐⭐⭐ Christian Kirk (IR) is never named as a drop candidate or the man a pickup is measured against', !/drop candidate: Christian Kirk/.test(fa) && !/vs Kirk/.test(fa));
  await page.context().close();
}

/* ══ §4 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §4 My Week free agents: both QBs out means a QB recommendation ==');
await post('/stub/reset');
{
  const page = await open([LQ, L1], { route: 'home' });
  await inSeason(page);
  await page.waitForSelector('[data-wkview="fa"]', { timeout: 30000 }); await page.waitForTimeout(1500);
  await page.click('[data-wkview="fa"]'); await page.waitForTimeout(700);
  const rows = await page.$$eval('[data-wkfarow]', (xs) => xs.map((x) => ({ who: x.getAttribute('data-wkfarow'), kind: (x.querySelector('[data-wkfakind]') || {}).getAttribute?.('data-wkfakind'), t: x.innerText.replace(/\s+/g, ' ') })));
  const qb = rows.find((r) => r.kind === 'hole');
  ok('4 · ⭐⭐⭐⭐⭐ a "Starter out" row recommends a free-agent QB', !!qb && /Aaron Rodgers/.test(qb.who) && /QB/.test(qb.t), qb ? qb.t.slice(0, 140) : rows.map((r) => r.kind + ':' + r.who).join(', '));
  ok('4a · ⭐⭐⭐⭐ and it says why: the starter is out and there is no healthy QB on the bench', !!qb && /Bo Nix is out/.test(qb.t) && /no healthy QB/i.test(qb.t));
  ok('4b · ⭐⭐⭐ the starter-out row comes first in its league', !!qb && rows.findIndex((r) => r.kind === 'hole') === 0);
  ok('4c · ⭐⭐⭐ the IR player is never offered as the one to replace', !rows.some((r) => /Christian Kirk/.test(r.t)));

  /* ══ §5 ═══════════════════════════════════════════════════════════════════════════════════════ */
  console.log('\n== §5 My Week league activity: a grade on each side of every trade ==');
  await page.click('[data-wkview="moves"]'); await page.waitForTimeout(3000);
  const mg = await page.$$eval('[data-wkmovegrade]', (xs) => xs.map((x) => x.getAttribute('data-wkmovegrade')));
  const tradeRows = await page.$$eval('[data-wkmove^="trade:complete"]', (xs) => xs.length);
  ok('5 · (fixture) my trades are listed', tradeRows >= 1, `${tradeRows} trades`);
  ok('5a · ⭐⭐⭐⭐⭐ every side of every two-team trade carries a letter grade', mg.length === tradeRows * 2 && mg.every((g) => /^\d+:[A-F][+-]?$/.test(g)), mg.join(' '));
  await page.context().close();
  /* the same trade in the hub's Recent activity */
  const hp = await open([L1], { route: 'teamHub', activeId: null, hubLeagueId: 'hub-lg-1' });
  await hp.waitForSelector('[data-hubnav]', { timeout: 30000 }); await hp.waitForTimeout(2200);
  await hp.click('[data-hubgroup="moves"]'); await hp.waitForTimeout(300);
  await hp.click('[data-hubtabbtn="txlog"]'); await hp.waitForTimeout(400);
  const recent = await hp.$('[data-tsectab="recent"]'); if (recent) { await recent.click(); }
  await hp.waitForTimeout(2500);
  const hg = await hp.$$eval('[data-txgrade]', (xs) => xs.map((x) => x.getAttribute('data-txgrade')));
  const mine = mg.filter((g) => hg.includes(g));
  ok('5b · ⭐⭐⭐⭐⭐ and the letters are the ones the league hub gives the same trade', mg.length > 0 && mine.length === mg.length, `My Week ${mg.join(' ')} · hub ${hg.join(' ')}`);
  await hp.context().close();
}

/* ══ §6 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §6 Game Day: the record is projected, and says so ==');
await post('/stub/reset'); await post('/stub/live', { mode: 'on' });
{
  const page = await open([L1, L2], { route: 'home' });
  await inSeason(page, 'gameday');
  await page.waitForSelector('[data-gdtotals]', { timeout: 30000 }); await page.waitForTimeout(700);
  const pr = await page.$eval('[data-gdprojrec]', (x) => ({ v: x.getAttribute('data-gdprojrec'), t: x.textContent })).catch(() => null);
  ok('6 · ⭐⭐⭐⭐⭐ the headline is the projected record (both matchups project as wins)', !!pr && pr.v === '2-0-0' && /^Projected 2-0 across 2 leagues/.test(pr.t.trim()), pr ? pr.t : 'none');
  const sub = await page.$eval('[data-gdliverec]', (x) => x.textContent).catch(() => '');
  ok('6a · ⭐⭐⭐⭐ it says it is based on projections, and still gives the live board', /projected final score/i.test(sub) && /right now/i.test(sub), sub.trim().slice(0, 140));
  await page.context().close();
}

/* ══ §7 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §7 Review: why the verdict, and the result side by side ==');
await post('/stub/reset');
{
  const page = await open([L1], { route: 'home' });
  await inSeason(page, 'review'); await page.waitForTimeout(1500);
  const wk2 = await page.$('[data-wkverdict]');
  ok('7 · (fixture) a finished week with a verdict chip', !!wk2);
  /* pick week 1 ("Got away with it") in the week picker if it is not already shown */
  let key = await page.$eval('[data-wkverdict]', (x) => x.getAttribute('data-wkverdict')).catch(() => '');
  await page.hover('[data-wkverdict]'); await page.waitForTimeout(400);
  const vt = await cardText(page);
  ok('7a · ⭐⭐⭐⭐⭐ hovering the verdict explains it: both scores and where they placed, the bench, the lineup mistake', /you scored/i.test(vt) && /they scored/i.test(vt) && /bench/i.test(vt) && /Bo Nix|Jameson Williams/.test(vt), `${key}: ${vt.split('\n').slice(0, 5).join(' / ')}`);
  await page.mouse.move(5, 5); await page.waitForTimeout(200);
  await page.hover('[data-wkresult]'); await page.waitForTimeout(400);
  const rt = await cardText(page);
  ok('7b · ⭐⭐⭐⭐⭐ hovering the result shows both lineups slot by slot with what each scored', /you/i.test(rt) && /them/i.test(rt) && /Jared Goff/.test(rt) && /Bo Nix/.test(rt) && /Total/.test(rt), rt.split('\n').slice(0, 3).join(' / '));
  await page.context().close();
}

ok('8 · nothing threw', errs.length === 0, errs.slice(0, 2).join(' || ').slice(0, 200));
await b.close();
console.log(`\n  ${pass} PASS  ${fail} FAIL`);
process.exit(fail ? 1 : 0);
