/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   THE WAIVER WIRE IN THE TRADE CALCULATOR — plan29bl
   Trey: "I lost Jayden Daniels and Jaxson Dart this week... I input a trade of Mike Evans for Joe Burrow, which
   gave me an A+... Jordan Love (19.5 points projected)... [is] on waivers... So it might make more sense to just
   pick up the free agent and keep Evans... I'd like you to explicitly show that in the trade calculator and
   make the suggestion / show the trade off." And: "I also want to check the 14.1 points a week."
   Rebuilt on the fixture: every QB I own marked out for the season (the injuries input), then my best receiver
   priced for another team's starting QB.
     §1 the calculator shows the free pickup beside the trade, with the three numbers (pickup, trade, trade over
        the pickup), and grades the trade on the last one
     §2 the slot-by-slot breakdown adds up to the headline lineup change
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import { chromium } from 'playwright';
import fs from 'node:fs';
const APP = 'http://localhost:4174/', STUB = 'http://localhost:5055';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { console.log(`  ${c ? 'PASS' : 'FAIL'}  ${n}${x !== '' ? `   [${x}]` : ''}`); c ? pass++ : fail++; };
const post = (p, b) => fetch(STUB + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b || {}) }).then((r) => r.json()).catch(() => null);
const PACK = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-pack.json', import.meta.url), 'utf8'));
const HUB = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-hub.json', import.meta.url), 'utf8'));
const byId = new Map(PACK.players.map((p) => [p.id, p]));
const mine = HUB.teams.find((t) => t.rosterId === HUB.myRosterId).players.map((id) => byId.get(id)).filter(Boolean);
const myQBs = mine.filter((p) => p.pos === 'QB');
const myWR1 = mine.filter((p) => p.pos === 'WR').sort((a, b) => a.adp - b.adp)[0];
const t2 = HUB.teams.find((t) => t.rosterId === 2);
const theirQB = t2.players.map((id) => byId.get(id)).filter((p) => p && p.pos === 'QB').sort((a, b) => a.adp - b.adp)[0];
const injuries = Object.fromEntries(myQBs.map((p) => [p.id, { status: 'season', weeks: 0, at: Date.now(), setWeek: HUB.week }]));

const CFG = { teams: 12, rounds: 15, slot: 1, type: 'redraft', sf: false, tePremMult: 0, order: 'snake',
  start: { QB: 1, RB: 2, WR: 2, TE: 1, FLEX: 1, SUPER: 0, K: 1, DST: 1 }, scoring: { rec: 1 }, caps: {}, keepers: [] };
const c = { platform: 'sleeper', leagueId: 'hub-lg-1', username: 'trey', ownerUsername: 'trey' };
const L1 = { id: 'H1', name: 'Hub Fixture League', created: 'x', cfg: { ...CFG, name: 'Hub Fixture League', connect: c }, picks: [], preds: [], mocks: [], connect: c, sleeperLeagueId: 'hub-lg-1' };
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const errs = [];
await post('/stub/reset'); await post('/stub/std', { mode: 'on' });
const page = await (await b.newContext({ viewport: { width: 1450, height: 1500 } })).newPage();
page.on('pageerror', (e) => errs.push(String(e)));
await page.goto(APP, { waitUntil: 'domcontentloaded' });
await page.evaluate(([l, inj]) => {
  localStorage.clear(); localStorage.setItem('fdc:token', 't'); localStorage.setItem('fdcTourSeen', '1');
  localStorage.setItem('fdc:gs-state', JSON.stringify({ user: { email: 'trey.rose@pirates.com', paid: true, admin: true, rankSets: [], sleeperUsername: 'trey', sleeperUserId: 's1', homeView: 'season' }, leagues: [l], funMocks: [], injuries: inj }));
  sessionStorage.setItem('gs-nav', JSON.stringify({ route: 'teamHub', activeId: null, hubLeagueId: 'hub-lg-1' }));
}, [L1, injuries]);
await page.reload({ waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-hubnav]', { timeout: 30000 }); await page.waitForTimeout(2500);
await page.click('[data-hubgroup="moves"]'); await page.click('[data-hubtabbtn="trades"]'); await page.click('[data-tsectab="calc"]'); await page.waitForTimeout(500);
await (await page.$('select[data-tbside-select="b"]')).selectOption({ label: t2.teamName }); await page.waitForTimeout(600);
await page.click(`[data-tbcol="give"] [data-tbplayer="${myWR1.name}"]`); await page.click(`[data-tbcol="get"] [data-tbplayer="${theirQB.name}"]`); await page.waitForTimeout(1200);
console.log(`\nThe trade: ${myWR1.name} for ${theirQB.name}, with ${myQBs.map((p) => p.name).join(' and ')} marked out for the season`);

console.log('\n== §1 the free pickup, shown beside the trade ==');
const w = await page.evaluate(() => {
  const el = document.querySelector('[data-tbwire]'); if (!el) return null;
  const n = (sel) => Number((el.querySelector(sel) || { getAttribute: () => null }).getAttribute(sel.slice(1, -1)));
  return { who: el.getAttribute('data-tbwire'), pickup: n('[data-tbwirepickup]'), trade: n('[data-tbwiretrade]'), over: n('[data-tbwireover]'),
    grade: document.querySelector('[data-tbgrade]').getAttribute('data-tbgrade'), call: document.querySelector('[data-tbgrade]').getAttribute('data-tbcall'),
    why: document.querySelector('[data-tbgrade]').textContent };
});
ok('1 · ⭐⭐⭐⭐⭐ with no healthy QB, the calculator names the free-agent QB you could add instead', !!w && !!w.who, w ? w.who : 'no wire block');
if (w) {
  const qbFA = PACK.players.find((p) => p.name === w.who.split('|')[0]);
  ok('1a · (check) that player really is a free agent, and a QB', !!qbFA && qbFA.pos === 'QB' && !HUB.teams.some((t) => t.players.includes(qbFA.id)), w.who);
  ok('1b · ⭐⭐⭐⭐⭐ all three numbers are there: the pickup, the trade, and the trade over the pickup', w.pickup > 0 && w.trade > 0 && Math.abs(w.over) >= 0 && w.over < w.trade, `pickup +${w.pickup}, trade +${w.trade}, over the pickup ${w.over} (season pts)`);
  ok('1c · ⭐⭐⭐⭐⭐ the grade is on the trade OVER the pickup, and says so', /over just picking up/.test(w.why), w.why.replace(/\s+/g, ' ').slice(0, 140));
  ok('1d · when the wire covers most of it, the call is to take the free agent', w.over / 17 >= 0.7 || w.call === 'wire', `${w.call}, over ${(w.over / 17).toFixed(1)}/wk`);
}

console.log('\n== §2 where the lineup number comes from ==');
const d = await page.evaluate(() => ({
  rows: [...document.querySelectorAll('[data-tbdiffrow]')].map((r) => ({ slot: r.getAttribute('data-tbdiffrow'), v: Number(r.querySelector('b.num').textContent) })),
  head: Number((document.querySelector('[data-tbside="me"] [data-tbdelta]') || { getAttribute: () => NaN }).getAttribute('data-tbdelta')) }));
const sum = d.rows.reduce((a, x) => a + x.v, 0);
ok('2 · ⭐⭐⭐⭐ the changed slots are listed: QB gains, the receiver slot pays for it', d.rows.some((r) => r.slot === 'QB' && r.v > 0) && d.rows.some((r) => r.v < 0), d.rows.map((r) => `${r.slot} ${r.v}`).join(', '));
ok('2a · ⭐⭐⭐⭐⭐ and they add up to the headline lineup change', Math.abs(sum - d.head / 17) <= 0.15 * d.rows.length, `rows sum ${sum.toFixed(1)}/wk, headline ${(d.head / 17).toFixed(1)}/wk`);

ok('3 · nothing threw', errs.length === 0, errs.slice(0, 2).join(' || ').slice(0, 160));
{ const bb = await (await page.$('[data-tbresult]')).boundingBox(); await page.screenshot({ path: '/tmp/claude-0/wire.png', clip: { x: bb.x, y: bb.y, width: bb.width, height: Math.min(700, bb.height) } }); }
await b.close();
console.log(`\n  ${pass} PASS  ${fail} FAIL`);
process.exit(fail ? 1 : 0);
