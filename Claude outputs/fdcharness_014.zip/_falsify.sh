#!/bin/bash
set -u
cd /home/claude/work
run(){ cd /home/claude/work/web/fdc-web && npm run build:test >/dev/null 2>&1 && cd /home/claude/work && node plan29ba.mjs 2>&1 | grep -E "^  FAIL|^  [0-9]+ PASS"; }

echo "═══ A — drop the waking screen (empty and unknown look identical again) ═══"
python3 - <<'PY'
import io
p='web/fdc-web/src/App.jsx'; s=io.open(p,encoding='utf-8').read()
a=s.index('  const wakingUp = hasBackend && hadTokenAtBoot.current')
b=s.index('  }\n', s.index('      </ThemeCtx.Provider>\n    );', a))+4
io.open(p,'w',encoding='utf-8').write(s[:a]+s[b:])
PY
run
cp /tmp/app.bak web/fdc-web/src/App.jsx

echo ""
echo "═══ B — stop stamping the league label (Yahoo rows go blank again) ═══"
python3 - <<'PY'
import io
p='web/fdc-web/src/screens/MyWeek.jsx'; s=io.open(p,encoding='utf-8').read()
s=s.replace("""      return (L.items || []).map((x) => ({ ...x, faab: L.faab, budget: L.budget,
        leagueId: x.leagueId || L.leagueId, leagueName: x.leagueName || nm }));""",
"""      return (L.items || []).map((x) => ({ ...x, faab: L.faab, budget: L.budget }));""")
io.open(p,'w',encoding='utf-8').write(s)
PY
run
cp /tmp/myweek.bak web/fdc-web/src/screens/MyWeek.jsx

echo ""
echo "═══ restored ═══"
run
