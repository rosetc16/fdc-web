/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   THE IN-SEASON HUB, IN A BROWSER, FOR THE FIRST TIME SINCE THE CONTAINER LOSS — plan29be
   ───────────────────────────────────────────────────────────────────────────────────────────────────
   Covers the three things this session changed on the hub, none of which any browser had seen:
     §1 the grouped menu (Summary · My Team · Transactions · League) and its doorways
     §2 Recent activity promoted out of Trades
     §3 values that blend season-to-date form (and say so), with the projections-only fallback
     §4 the Injuries tab end to end — mark a player through the UI, see the team block, the badge, the
        League banner, and the injury SURVIVE A RELOAD (the persistence path 29bb hand-edited in five places)
     §5 phone width
   Fixtures: hubstub/gen-hub-fixture.mjs (a 12-team league built from the app's own board).
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import { chromium } from 'playwright';
import fs from 'node:fs';
const APP = 'http://localhost:4174/', STUB = 'http://localhost:5055';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { console.log(`  ${c ? 'PASS' : 'FAIL'}  ${n}${x !== '' ? `   [${x}]` : ''}`); c ? pass++ : fail++; };
const post = (p, b) => fetch(STUB + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b || {}) }).then((r) => r.json()).catch(() => null);
const STD = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-std.json', import.meta.url), 'utf8'));

const CFG = { teams: 12, rounds: 15, slot: 1, type: 'redraft', sf: false, tePremMult: 0, order: 'snake',
  start: { QB: 1, RB: 2, WR: 2, TE: 1, FLEX: 1, SUPER: 0, K: 1, DST: 1 }, scoring: { rec: 1 }, caps: {}, keepers: [] };
const conn = { platform: 'sleeper', leagueId: 'hub-lg-1', username: 'trey', ownerUsername: 'trey' };
const LEAGUES = [{ id: 'H0', name: 'Hub Fixture League', created: 'x', cfg: { ...CFG, name: 'Hub Fixture League', connect: conn },
  picks: [], preds: [], mocks: [], connect: conn, sleeperLeagueId: 'hub-lg-1' }];

const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const errs = [];
const openHub = async (ctxOpts, { seed = true } = {}) => {
  const ctx = await b.newContext(ctxOpts || { viewport: { width: 1450, height: 1500 } });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => errs.push(String(e)));
  await page.goto(APP, { waitUntil: 'domcontentloaded' });
  if (seed) {
    await page.evaluate((l) => {
      localStorage.clear(); localStorage.setItem('fdc:token', 't'); localStorage.setItem('fdcTourSeen', '1');
      localStorage.setItem('fdc:gs-state', JSON.stringify({ user: { email: 'trey.rose@pirates.com', paid: true, admin: true, rankSets: [], sleeperUsername: 'trey', sleeperUserId: 's1', homeView: 'season' }, leagues: l, funMocks: [] }));
    }, LEAGUES);
  }
  await page.evaluate(() => sessionStorage.setItem('gs-nav', JSON.stringify({ route: 'teamHub', activeId: null, hubLeagueId: 'hub-lg-1' })));
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-hubnav]', { timeout: 30000 }).catch(() => {});
  await page.waitForTimeout(1500);
  const d = page.getByText('Dismiss', { exact: false }).first(); if (await d.count()) await d.click({ force: true }).catch(() => {});
  return page;
};
const boundary = (page) => page.evaluate(() => /Something hiccuped|Something went wrong|hit a snag/i.test(document.body.innerText || ''));
const pressed = (page, sel) => page.evaluate((s) => [...document.querySelectorAll(s)].filter((x) => x.getAttribute('aria-pressed') === 'true').map((x) => x.getAttribute('data-hubtabbtn') || x.getAttribute('data-hubgroup')), sel);

await post('/stub/reset');
await post('/stub/std', { mode: 'on' });
await fetch(`${STUB}/api/state`, { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ state: { leagues: LEAGUES, funMocks: [], feedback: [] } }) });

/* ══ §0 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §0 can this fixture fail? ==');
const page = await openHub();
{
  const t = await page.evaluate(() => document.body.innerText);
  ok('0 · ⭐⭐⭐⭐⭐ the real hub renders against the fixture (not an error, not an empty league)', /Yinzer Bombers/.test(t) && /playoff odds/i.test(t), (t.match(/\d+(\.\d+)?% ?\s*playoff odds/i) || [''])[0]);
  ok('0b · the fixture has a HOT and a COLD player on my team for §3 to see', !!(STD._hot && STD._cold), `${STD._hot} / ${STD._cold}`);
  ok('0c · no error boundary', !(await boundary(page)));
}

/* ══ §1 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §1 four groups, sub-tabs under each ==');
{
  const groups = await page.$$eval('[data-hubgroup]', (xs) => xs.map((x) => x.getAttribute('data-hubgroup')));
  ok('1 · ⭐⭐⭐⭐⭐ the top row is exactly Summary · My Team · Transactions · League', groups.join(',') === 'summary,team,moves,league', groups.join(','));
  ok('1b · Summary is a single tab with no sub-row', (await page.$$('[data-hubsubnav]')).length === 0 && (await pressed(page, '[data-hubgroup]')).join() === 'summary');
  const expect = { team: ['lineup', 'roster', 'review', 'gameday'], moves: ['freeagents', 'injuries', 'trades', 'txlog'], league: ['league', 'draft'] };
  for (const g of ['team', 'moves', 'league']) {
    await page.click(`[data-hubgroup="${g}"]`); await page.waitForTimeout(500);
    const subs = await page.$$eval('[data-hubtabbtn]', (xs) => xs.map((x) => x.getAttribute('data-hubtabbtn')));
    ok(`1c · ${g}: the sub-tabs are ${expect[g].join(' · ')}`, subs.join(',') === expect[g].join(','), subs.join(','));
    ok(`1d · ${g}: opening the group lands on its first real sub-tab, never a doorway`, (await pressed(page, '[data-hubtabbtn]'))[0] === expect[g][0], (await pressed(page, '[data-hubtabbtn]')).join());
    /* Every real sub-tab renders without an error boundary. */
    for (const k of expect[g].filter((k) => k !== 'gameday' && k !== 'draft')) {
      await page.click(`[data-hubtabbtn="${k}"]`); await page.waitForTimeout(700);
      const on = await pressed(page, '[data-hubtabbtn]');
      ok(`1e · ${g} › ${k} opens, is marked selected, and renders`, on.join() === k && !(await boundary(page)), on.join());
    }
  }
  /* The draft doorway opens its chooser rather than a tab. */
  await page.click('[data-hubgroup="league"]'); await page.waitForTimeout(300);
  await page.click('[data-hubtabbtn="draft"]'); await page.waitForTimeout(600);
  ok('1f · ⭐⭐⭐⭐ League › Draft is a doorway — it opens the draft chooser', (await page.$$('[data-hubdraftchoice]')).length >= 1);
  await page.keyboard.press('Escape'); await page.waitForTimeout(300);
  const x = page.getByRole('button', { name: /close|cancel|×/i }).first(); if (await x.count()) await x.click({ force: true }).catch(() => {});
  await page.waitForTimeout(300);
  ok('1g · and it is never shown as the selected tab', !(await pressed(page, '[data-hubtabbtn]')).includes('draft'));
  /* Existing jumps still land: a setTab("trades") from outside the menu must open Transactions. */
  await page.click('[data-hubgroup="summary"]'); await page.waitForTimeout(400);
  ok('1h · the group follows the tab (derived, not stored): Summary is selected again', (await pressed(page, '[data-hubgroup]')).join() === 'summary');
}

/* ══ §2 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §2 Recent activity moved up out of Trades ==');
{
  await page.click('[data-hubgroup="moves"]'); await page.waitForTimeout(300);
  await page.click('[data-hubtabbtn="trades"]'); await page.waitForTimeout(600);
  const secs = await page.$$eval('[data-tsectab]', (xs) => xs.map((x) => x.getAttribute('data-tsectab')));
  ok('2 · ⭐⭐⭐⭐⭐ Trades no longer lists Recent activity in its own section row', !secs.includes('recent') && secs.length === 4, secs.join(','));
  await page.click('[data-hubtabbtn="txlog"]'); await page.waitForTimeout(2500);
  const t = await page.evaluate(() => ({ h: [...document.querySelectorAll('.panel .disp')].map((x) => x.textContent.trim()), bar: !!document.querySelector('[data-tsec]') }));
  ok('2b · Transactions › Recent activity is headed "Recent activity"', t.h.includes('Recent activity'), t.h.slice(0, 3).join(' | '));
  ok('2c · …with no Trades section row above it', t.bar === false);
  ok('2d · …and the feed actually loads (a trade from the stub is on screen)', /traded|Trade/i.test(await page.evaluate(() => document.body.innerText)));
  await page.click('[data-hubtabbtn="trades"]'); await page.waitForTimeout(600);
  const back = await page.evaluate(() => (document.querySelector('[data-tsec]') || {}).getAttribute ? document.querySelector('[data-tsec]').getAttribute('data-tsec') : null);
  ok('2e · ⭐⭐⭐⭐ going back to Trades lands on the Calculator, not a hidden "recent" section', back === 'calc', back);
}

/* ══ §3 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §3 values move with what players have actually scored ==');
const calcValue = async (pg, name) => {
  await pg.click('[data-hubgroup="moves"]'); await pg.waitForTimeout(300);
  await pg.click('[data-hubtabbtn="trades"]'); await pg.waitForTimeout(500);
  const sels = await pg.$$('select');
  const partner = sels[sels.length - 1];
  /* ⚠ index 1 is MY OWN team (the list repeats "(you)") — trading with yourself lists nobody. */
  await partner.selectOption({ index: 2 }).catch(() => {});
  await pg.waitForTimeout(700);
  return pg.evaluate((n) => { const r = document.querySelector(`[data-tbplayer="${CSS.escape(n)}"]`); if (!r) return null; const nums = r.textContent.match(/(\d+)\s*$/); return nums ? Number(nums[1]) : null; }, name);
};
{
  const note = await page.evaluate(() => { const n = document.querySelector('[data-formnote]'); return n ? [n.getAttribute('data-formnote'), n.textContent] : null; });
  ok('3 · ⭐⭐⭐⭐⭐ the Trades tab says values blend actual results through week 8', note && note[0] === '8' && /through week 8/.test(note[1]), note && note[1].slice(0, 70));
  const hotOn = await calcValue(page, STD._hot), coldOn = await calcValue(page, STD._cold);
  await post('/stub/std', { mode: 'warming' });
  const p2 = await openHub(undefined);
  const hotOff = await calcValue(p2, STD._hot), coldOff = await calcValue(p2, STD._cold);
  /* Read AFTER calcValue has opened the Trades tab — the note lives in that panel. */
  const note2 = await p2.evaluate(() => { const n = document.querySelector('[data-formnote]'); return n ? n.textContent : ''; });
  ok('3b · with no actuals yet, it says values are projections only', /projections only/.test(note2), note2.slice(0, 60));
  ok(`3c · ⭐⭐⭐⭐⭐ ${STD._hot} (1.6× his projection for 8 games) is worth MORE in the calculator with form on`, hotOn != null && hotOff != null && hotOn > hotOff, `${hotOff} → ${hotOn}`);
  ok(`3d · ⭐⭐⭐⭐⭐ ${STD._cold} (0.45× for 8 games) is worth LESS`, coldOn != null && coldOff != null && coldOn < coldOff, `${coldOff} → ${coldOn}`);
  /* (8×1.6 + 6×1)/14 = 1.343× */
  ok('3e · …by the weighted amount (8 games at 1.6×, 6 of projection ≈ 1.34×)', hotOn && hotOff && Math.abs(hotOn / hotOff - 1.343) < 0.03, hotOn && hotOff ? (hotOn / hotOff).toFixed(3) + '×' : '');
  await p2.context().close();
  await post('/stub/std', { mode: 'on' });
}

/* ══ §4 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §4 the Injuries tab, end to end, and it survives a reload ==');
{
  const pg = await openHub(undefined);
  await pg.click('[data-hubgroup="moves"]'); await pg.waitForTimeout(300);
  await pg.click('[data-hubtabbtn="injuries"]'); await pg.waitForTimeout(500);
  ok('4 · the Injuries sub-tab starts empty', (await pg.$$('[data-injempty]')).length === 1);
  await pg.fill('[data-injsearch]', STD._myQB.split(' ').slice(-1)[0]); await pg.waitForTimeout(400);
  await pg.click(`[data-injhit="${STD._myQBid}"]`); await pg.waitForTimeout(300);
  await pg.click('[data-injchoice="season"]'); await pg.click('[data-injsave]'); await pg.waitForTimeout(900);
  const s = await pg.evaluate(() => ({
    row: !!document.querySelector('[data-injrow]'), mine: !!document.querySelector('[data-injmine]'),
    slot: (document.querySelector('[data-injslot]') || {}).textContent || '',
    week: (document.querySelector('[data-injcost-week]') || { getAttribute: () => null }).getAttribute('data-injcost-week'),
    badge: (document.querySelector('[data-hubgroup="moves"] [data-injtabcount]') || { getAttribute: () => null }).getAttribute('data-injtabcount') }));
  ok(`4b · ⭐⭐⭐⭐⭐ marking ${STD._myQB} out through the UI lists him and opens the team block`, s.row && s.mine);
  ok('4c · ⭐⭐⭐⭐ the team block names what happens to the QB slot', /QB/.test(s.slot) && /(steps in|empty)/.test(s.slot), s.slot.replace(/\s+/g, ' ').slice(0, 80));
  ok('4d · …and prints a real cost this week', Number(s.week) > 0, s.week);
  ok('4e · the Transactions group carries the injury count', s.badge === '1', s.badge);
  await pg.click('[data-hubgroup="league"]'); await pg.waitForTimeout(700);
  ok('4f · League › Standings says the table includes the injury', (await pg.$$('[data-injbanner]')).length === 1);
  await pg.waitForTimeout(1500);   // let the debounced save reach the stub
  const saved = await fetch(`${STUB}/api/state`).then((r) => r.json());
  const inj = saved.state && saved.state.injuries;
  ok('4g · ⭐⭐⭐⭐⭐ the injury reached the SERVER copy of his state (the key persistNow used to drop)', !!(inj && inj[STD._myQBid] && inj[STD._myQBid].status === 'season'), inj ? Object.keys(inj).join(',') : 'no injuries key');
  await pg.context().close();
  /* A different "device": fresh local storage, same account — the injury must come from the server. */
  const pg2 = await openHub({ viewport: { width: 1450, height: 1500 } }, { seed: true });
  await pg2.waitForTimeout(2500);
  const badge2 = await pg2.evaluate(() => (document.querySelector('[data-hubgroup="moves"] [data-injtabcount]') || { getAttribute: () => null }).getAttribute('data-injtabcount'));
  ok('4h · ⭐⭐⭐⭐⭐ on a fresh device the injury is restored from the server — it follows him', badge2 === '1', badge2);
  /* Clear it, and the clear must also stick (the tombstone). */
  await pg2.click('[data-hubgroup="moves"]'); await pg2.waitForTimeout(300);
  await pg2.click('[data-hubtabbtn="injuries"]'); await pg2.waitForTimeout(400);
  await pg2.click(`[data-injclear="${STD._myQBid}"]`); await pg2.waitForTimeout(2200);
  const after = await fetch(`${STUB}/api/state`).then((r) => r.json());
  const e2 = after.state && after.state.injuries && after.state.injuries[STD._myQBid];
  ok('4i · ⭐⭐⭐⭐ clearing it writes a tombstone, not a deletion, so another device cannot resurrect it', !!(e2 && e2.status === null && e2.at), JSON.stringify(e2));
  ok('4j · …and the hub is back to no injuries', (await pg2.$$('[data-injempty]')).length === 1);
  await pg2.context().close();
}

/* ══ §5 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §5 phone width ==');
{
  const pg = await openHub({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 });
  for (const g of ['team', 'moves', 'league']) {
    await pg.click(`[data-hubgroup="${g}"]`); await pg.waitForTimeout(500);
    const w = await pg.evaluate(() => ({ sw: document.documentElement.scrollWidth, iw: window.innerWidth,
      nav: (() => { const n = document.querySelector('[data-hubnav]'); return n ? Math.round(n.getBoundingClientRect().right) : 0; })() }));
    ok(`5 · ${g}: the menu fits a 390px phone with no sideways scroll`, w.sw <= w.iw + 1 && w.nav <= w.iw + 1, `scroll ${w.sw} / nav right ${w.nav} / ${w.iw}`);
  }
  await pg.screenshot({ path: '/tmp/hub-phone.png' });
  await pg.context().close();
}

/* ══ §6 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §6 the Game Day doorway, and the console ==');
{
  await page.click('[data-hubgroup="team"]'); await page.waitForTimeout(300);
  await page.click('[data-hubtabbtn="gameday"]'); await page.waitForTimeout(2500);
  /* 29bi — Trey asked for Game Day as a popup over the hub, so this doorway now OPENS OVER the hub
     (plan29bi §4 covers it in full); the full page is one button inside the popup. */
  ok('6 · My Team › Game Day opens over the hub (29bi: a popup, not a page change)', !!(await page.$('[data-gdpopup] [data-screen="gameday"]')) && (await page.$$('[data-hubnav]')).length > 0 && !(await boundary(page)));
  await page.click('[data-gdfull]'); await page.waitForTimeout(2500);
  ok('6a · …and its "Open full page" still leaves the hub for Game Day', (await page.$$('[data-hubnav]')).length === 0 && !(await boundary(page)));
  ok('6b · ⭐⭐⭐⭐ nothing threw in any context', errs.length === 0, errs.slice(0, 2).join(' || ').slice(0, 160));
}

await b.close();
console.log(`\n  ${pass} PASS  ${fail} FAIL`);
process.exit(fail ? 1 : 0);
