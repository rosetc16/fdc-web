/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   TREY'S FOUR TRADE NOTES — plan29bh
     §1 "Eagles defense for Josh Allen... A+" — no suggested trade anywhere carries a kicker or a defense.
     §2 "select a player from a different team and click a button for 'ideas'" — the Ideas button returns
        offers from MY roster, at fair value, graded, and Load puts one in the calculator.
     §3 "a grade for each team [in recent activity] based on the outlook at the time of the trade" — both
        sides of a two-team trade are graded on results rewound to the trade's week; three-way trades say
        why they are not.
     §4 "draft pick trading... in the trade calculator... based on value" — a dynasty league's future picks
        appear on both sides, traded picks sit with their new owner under their original team's name, and a
        pick moves the value check but never the lineup.
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import { chromium } from 'playwright';
import fs from 'node:fs';
const APP = 'http://localhost:4174/', STUB = 'http://localhost:5055';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { console.log(`  ${c ? 'PASS' : 'FAIL'}  ${n}${x !== '' ? `   [${x}]` : ''}`); c ? pass++ : fail++; };
const post = (p, b) => fetch(STUB + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b || {}) }).then((r) => r.json()).catch(() => null);
const PACK = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-pack.json', import.meta.url), 'utf8'));
const HUB = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-hub.json', import.meta.url), 'utf8'));
const posOf = new Map(PACK.players.map((p) => [p.name, p.pos]));
const STREAM = new Set(['K', 'DEF', 'DST']);
const streamedIn = (names) => names.filter((n) => STREAM.has(posOf.get(n)));

const CFG = { teams: 12, rounds: 15, slot: 1, type: 'redraft', sf: false, tePremMult: 0, order: 'snake',
  start: { QB: 1, RB: 2, WR: 2, TE: 1, FLEX: 1, SUPER: 0, K: 1, DST: 1 }, scoring: { rec: 1 }, caps: {}, keepers: [] };
const lg = (id, name, lid, type) => { const c = { platform: 'sleeper', leagueId: lid, username: 'trey', ownerUsername: 'trey' };
  return { id, name, created: 'x', cfg: { ...CFG, type: type || 'redraft', name, connect: c }, picks: [], preds: [], mocks: [], connect: c, sleeperLeagueId: lid }; };

const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const errs = [];
const openHub = async (L) => {
  const page = await (await b.newContext({ viewport: { width: 1450, height: 1500 } })).newPage();
  page.on('pageerror', (e) => errs.push(String(e)));
  await page.goto(APP, { waitUntil: 'domcontentloaded' });
  await page.evaluate((l) => {
    localStorage.clear(); localStorage.setItem('fdc:token', 't'); localStorage.setItem('fdcTourSeen', '1');
    localStorage.setItem('fdc:gs-state', JSON.stringify({ user: { email: 'trey.rose@pirates.com', paid: true, admin: true, rankSets: [], sleeperUsername: 'trey', sleeperUserId: 's1', homeView: 'season' }, leagues: [l], funMocks: [] }));
    sessionStorage.setItem('gs-nav', JSON.stringify({ route: 'teamHub', activeId: null, hubLeagueId: l.sleeperLeagueId }));
  }, L);
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-hubnav]', { timeout: 30000 }); await page.waitForTimeout(2500);
  return page;
};
const sec = async (page, k) => { await page.click('[data-hubgroup="moves"]'); await page.waitForTimeout(250); await page.click('[data-hubtabbtn="trades"]'); await page.waitForTimeout(400);
  if (k === 'recent') { await page.click('[data-hubtabbtn="txlog"]').catch(() => {}); await page.waitForTimeout(1500); return; }
  await page.click(`[data-tsectab="${k}"]`); await page.waitForTimeout(700); };
const T2 = HUB.teams.find((t) => t.rosterId === 2).teamName;

await post('/stub/reset'); await post('/stub/std', { mode: 'on' });
const page = await openHub(lg('H1', 'Hub Fixture League', 'hub-lg-1'));

/* ══ §1 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §1 no kicker or defense in any suggested trade ==');
await sec(page, 'deals');
const dealNames = await page.$$eval('[data-tbrecgive], [data-tbrecgive2], [data-tbrecget]', (xs) => xs.map((x) => x.getAttribute('data-tbrecgive') || x.getAttribute('data-tbrecgive2') || x.getAttribute('data-tbrecget')));
ok('1 · (fixture) Deals has players to check', dealNames.length > 0, `${dealNames.length} names`);
ok('1a · ⭐⭐⭐⭐⭐ no K or DEF in Deals', streamedIn(dealNames).length === 0, streamedIn(dealNames).join(', '));
await sec(page, 'league');
await page.$$eval('button[aria-expanded="false"]', (xs) => xs.filter((e) => e.closest('td') && /\d/.test(e.textContent)).forEach((e) => e.click()));
await page.waitForTimeout(700);
const lrNames = await page.$$eval('[data-lrdeal] b', (xs) => xs.map((x) => x.textContent.trim()));
ok('1b · ⭐⭐⭐⭐⭐ no K or DEF in the League read\'s ideas', lrNames.length > 0 && streamedIn(lrNames).length === 0, `${lrNames.length} names; ${streamedIn(lrNames).join(', ')}`);

/* ══ §2 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §2 Ideas for a player on another team ==');
await sec(page, 'calc');
const sels = await page.$$('select[data-tbside-select="b"]');
await sels[0].selectOption({ label: T2 }); await page.waitForTimeout(700);
const theirTop = await page.$eval('[data-tbcol="get"] [data-tbplayer]', (x) => x.getAttribute('data-tbplayer'));
await page.click(`[data-tbcol="get"] [data-tbplayer="${theirTop}"]`); await page.waitForTimeout(500);
ok('2 · picking their player offers an Ideas button', !!(await page.$('[data-tbideas]')), theirTop);
await page.click('[data-tbideas]'); await page.waitForTimeout(2500);
const ideas = await page.$$eval('[data-tbidea]', (xs) => xs.map((x) => ({ give: x.getAttribute('data-tbidea'), g: (x.querySelector('[data-ideagrade]') || {}).getAttribute?.('data-ideagrade'),
  fair: Number(x.getAttribute('data-tbideafair')) })));
ok('2a · ⭐⭐⭐⭐⭐ Ideas returns offers from my roster, each graded', ideas.length > 0 && ideas.every((x) => x.g), ideas.map((x) => `${x.g} ${x.give}`).join(' | '));
ok('2b · ⭐⭐⭐⭐ every idea is fair on value (≥60% even on the finder\'s scale)', ideas.every((x) => x.fair >= 60), ideas.map((x) => x.fair + '%').join(' '));
ok('2c · no idea offers a kicker or defense', ideas.every((x) => streamedIn(x.give.split(' + ')).length === 0));
if (ideas.length) {
  await page.click('[data-tbideaload]'); await page.waitForTimeout(900);
  const loaded = await page.$$eval('[data-tbcol="give"] [data-tbon="1"]', (xs) => xs.map((x) => x.getAttribute('data-tbplayer')));
  const g = await page.$eval('[data-tbgrade]', (x) => x.getAttribute('data-tbgrade')).catch(() => null);
  ok('2d · ⭐⭐⭐⭐⭐ Load puts the offer in the calculator and it grades the same', loaded.join(' + ') === ideas[0].give && g === ideas[0].g, `${loaded.join(' + ')} → ${g} (idea said ${ideas[0].g})`);
}

/* 29bh — a backup quarterback in a one-QB league has no price: the Ideas box says so instead of listing zeroes. */
{
  const T3n = HUB.teams.find((t) => t.rosterId === 3).teamName;
  const byId = new Map(PACK.players.map((p) => [p.id, p]));
  const qbs = HUB.teams.find((t) => t.rosterId === 3).players.map((id) => byId.get(id)).filter((p) => p && p.pos === 'QB').sort((a, b) => a.adp - b.adp);
  if (qbs.length >= 2) {
    await (await page.$('select[data-tbside-select="b"]')).selectOption({ label: T3n }); await page.waitForTimeout(700);
    await page.click(`[data-tbcol="get"] [data-tbplayer="${qbs[1].name}"]`); await page.waitForTimeout(400);
    await page.click('[data-tbideas]'); await page.waitForTimeout(1500);
    const w = !!(await page.$('[data-tbideasworthless]')), n0 = (await page.$$('[data-tbidea]')).length;
    ok(`2e · ⭐⭐⭐⭐ a backup QB (${qbs[1].name}) gets "worth no more than the wire", not a list of 0-for-0 ideas`, w && n0 === 0, `message ${w}, ideas ${n0}`);
    await page.click(`[data-tbcol="get"] [data-tbplayer="${qbs[1].name}"]`); await page.waitForTimeout(300);
  } else ok('2e · (fixture has no backup QB on team 3)', true);
}

/* ══ §3 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §3 Recent activity: a grade for each side ==');
await sec(page, 'recent');
await page.waitForTimeout(1500);
const rows = await page.$$eval('[data-txrow^="trade"]', (xs) => xs.map((x) => ({ grades: [...x.querySelectorAll('[data-txgrade]')].map((g) => g.getAttribute('data-txgrade')),
  note: (x.querySelector('[data-txgradenote]') || {}).getAttribute?.('data-txgradenote'), text: (x.querySelector('[data-txgradenote]') || {}).textContent || '' })));
const two = rows.filter((r) => r.note === 'graded'), three = rows.filter((r) => r.note === 'multi');
ok('3 · (fixture) the feed has trades', rows.length >= 3, `${rows.length} trades`);
ok('3a · ⭐⭐⭐⭐⭐ both sides of every two-team trade carry a grade', two.length >= 2 && two.every((r) => r.grades.length === 2), two.map((r) => r.grades.join(' ')).join(' | '));
ok('3b · ⭐⭐⭐⭐ the grade is on results as they stood at the trade (week 3 → through week 2)', two.some((r) => /through week 2/.test(r.text)), two.map((r) => r.text.slice(0, 70)).join(' | '));
ok('3c · a three-team trade says why it is not graded', three.length === 1 && three[0].grades.length === 0);
await page.context().close();

/* ══ §4 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §4 dynasty: future picks in the calculator ==');
const dp = await openHub(lg('HD', 'Dynasty Fixture League', 'hub-lg-dyn', 'dynasty'));
await sec(dp, 'calc');
const T3 = HUB.teams.find((t) => t.rosterId === 3).teamName, T12 = HUB.teams.find((t) => t.rosterId === 12).teamName;
await (await dp.$('select[data-tbside-select="b"]')).selectOption({ label: T3 }); await dp.waitForTimeout(700);
const myPicks = await dp.$$eval('[data-tbcol="give"] [data-tbpick]', (xs) => xs.map((x) => ({ n: x.getAttribute('data-tbpick'), v: Number(x.querySelector('.num').textContent) })));
const theirPicks = await dp.$$eval('[data-tbcol="get"] [data-tbpick]', (xs) => xs.map((x) => x.getAttribute('data-tbpick')));
ok('4 · ⭐⭐⭐⭐⭐ my future picks are in the calculator', myPicks.length >= 11, `${myPicks.length} picks`);
ok('4a · ⭐⭐⭐⭐⭐ a traded pick sits with its NEW owner under its ORIGINAL team\'s name', myPicks.some((p) => p.n === `2027 1st (${T12})`) && theirPicks.some((n) => /^2028 2nd \(/.test(n)) && !myPicks.some((p) => p.n === '2028 2nd'),
  `mine has "2027 1st (${T12})": ${myPicks.some((p) => p.n === `2027 1st (${T12})`)}; theirs: ${theirPicks.filter((n) => /\(/.test(n)).join(', ')}`);
const v = (n) => (myPicks.find((p) => p.n === n) || {}).v;
ok('4b · picks lose value down the draft and further out', v('2027 1st') > v('2027 2nd') && v('2027 2nd') > v('2027 3rd') && v('2028 1st') > v('2029 1st'), `27-1 ${v('2027 1st')} > 27-2 ${v('2027 2nd')} > 27-3 ${v('2027 3rd')}; 28-1 ${v('2028 1st')} > 29-1 ${v('2029 1st')}`);
/* I am first in the power table, so my own 2027 1st lands LATE; team 12's lands wherever team 12 finishes. */
const my1 = v('2027 1st'), t12 = v(`2027 1st (${T12})`);
ok('4b2 · ⭐⭐⭐⭐ next year\'s pick is placed by its ORIGINAL team\'s power rank — the #1 team\'s 1st is the cheapest 1st', t12 > my1, `team 12's ${t12} vs my ${my1}`);
/* A pick moves VALUE, never the lineup. */
const theirTop3 = await dp.$eval('[data-tbcol="get"] [data-tbplayer]', (x) => x.getAttribute('data-tbplayer'));
const myTop = await dp.$eval('[data-tbcol="give"] [data-tbplayer]', (x) => x.getAttribute('data-tbplayer'));
await dp.click(`[data-tbcol="give"] [data-tbplayer="${myTop}"]`); await dp.click(`[data-tbcol="get"] [data-tbplayer="${theirTop3}"]`); await dp.waitForTimeout(900);
const read = () => dp.evaluate(() => ({ d: Number(document.querySelector('[data-tbside="me"] [data-tbdelta]').getAttribute('data-tbdelta')),
  out: Number((document.querySelector('[data-tbverdict]').textContent.match(/Value out (\d+(\.\d+)?)/) || [])[1]) }));
const before = await read();
await dp.click('[data-tbcol="give"] [data-tbpick="2027 1st"]'); await dp.waitForTimeout(900);
const after = await read();
ok('4c · ⭐⭐⭐⭐⭐ adding my 2027 1st raises the value I send by its price, and leaves my lineup change alone',
  Math.abs(after.d - before.d) < 0.05 && Math.abs((after.out - before.out) - v('2027 1st')) <= 1.5, `lineup ${before.d}→${after.d}; value out ${before.out}→${after.out} (pick ${v('2027 1st')})`);
const why = await dp.$eval('[data-tbgrade]', (x) => x.textContent).catch(() => '');
ok('4d · ⭐⭐⭐⭐ the dynasty grade says which window it graded for', /graded as a (win-now|balanced|rebuilding) team/.test(why), (why.match(/graded as [^—]+— [^,.]+/) || [''])[0]);
await dp.context().close();

ok('5 · nothing threw', errs.length === 0, errs.slice(0, 2).join(' || ').slice(0, 160));
await b.close();
console.log(`\n  ${pass} PASS  ${fail} FAIL`);
process.exit(fail ? 1 : 0);
