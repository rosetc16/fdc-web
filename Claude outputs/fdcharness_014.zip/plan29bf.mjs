/* ═══════════════════════════════════════════════════════════════════════════════════════════════════
   THE TRADE CALCULATOR MUST AGREE WITH WHAT ACTUALLY HAPPENS — plan29bf
   ───────────────────────────────────────────────────────────────────────────────────────────────────
   Trey: "I tested a trade tonight, it told me I wouldn't move in the power rankings. Then I made the trade
   and I dropped 3 spots. It was also telling me I was going to lose points on my roster... then I tested
   out the calculator to see what would happen if I made the exact same trade back... it suggests I'd move
   down in power rankings more AND my lineup would lose points."
   Three properties, each one of his complaints turned into an assertion:
     §1 PREDICTION = OUTCOME  — the rank the calculator says you move to is the rank the League tab shows
                                after the trade is actually made (stub executes it, hub reloads).
     §1 SYMMETRY              — the reverse trade's lineup change is exactly the negative of the forward
                                one, and it predicts a return to the original rank.
     §2 A SECOND LEAGUE       — the same trade priced after the home page has loaded a league with a
                                different lineup shape gives the SAME numbers.
   ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import { chromium } from 'playwright';
import fs from 'node:fs';
const APP = 'http://localhost:4174/', STUB = 'http://localhost:5055';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { console.log(`  ${c ? 'PASS' : 'FAIL'}  ${n}${x !== '' ? `   [${x}]` : ''}`); c ? pass++ : fail++; };
const post = (p, b) => fetch(STUB + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b || {}) }).then((r) => r.json()).catch(() => null);

const HUB = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-hub.json', import.meta.url), 'utf8'));
const PACK = JSON.parse(fs.readFileSync(new URL('./hubstub/fixture-pack.json', import.meta.url), 'utf8'));
const byId = new Map(PACK.players.map((p) => [p.id, p]));
const teamOf = (rid) => HUB.teams.find((t) => t.rosterId === rid);
const best = (rid, pos, n = 0) => teamOf(rid).players.map((id) => byId.get(id)).filter((p) => p.pos === pos).sort((a, b) => a.adp - b.adp)[n];
/* ⚠ THE TRADE HAS TO BE ABLE TO MOVE THE RANK. The first version gave my WR2 for their RB1: my team is
   1st in the fixture and the deal HELPED it, so "stays #1" passed for the uninteresting reason that #1 has
   nowhere to go. This one sends my best receiver for their third back — it must cost real rank, and §1
   asserts that it does before trusting anything else. */
const GIVE = best(1, 'WR', 0), GET = best(2, 'RB', 2);
const T2 = teamOf(2).teamName;

const CFG = { teams: 12, rounds: 15, slot: 1, type: 'redraft', sf: false, tePremMult: 0, order: 'snake',
  start: { QB: 1, RB: 2, WR: 2, TE: 1, FLEX: 1, SUPER: 0, K: 1, DST: 1 }, scoring: { rec: 1 }, caps: {}, keepers: [] };
const lg = (id, name, lid, start) => { const c = { platform: 'sleeper', leagueId: lid, username: 'trey', ownerUsername: 'trey' };
  return { id, name, created: 'x', cfg: { ...CFG, ...(start ? { start, sf: true } : {}), name, connect: c }, picks: [], preds: [], mocks: [], connect: c, sleeperLeagueId: lid }; };
const L1 = lg('H1', 'Hub Fixture League', 'hub-lg-1');
const L2 = lg('H2', 'Superflex 3WR League', 'hub-lg-2', { QB: 1, RB: 1, WR: 3, TE: 1, FLEX: 2, SUPER: 1, K: 0, DST: 0 });

const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const errs = [];
const seed = async (page, leagues, route) => {
  await page.goto(APP, { waitUntil: 'domcontentloaded' });
  await page.evaluate(([l, r]) => {
    localStorage.clear(); localStorage.setItem('fdc:token', 't'); localStorage.setItem('fdcTourSeen', '1');
    localStorage.setItem('fdc:gs-state', JSON.stringify({ user: { email: 'trey.rose@pirates.com', paid: true, admin: true, rankSets: [], sleeperUsername: 'trey', sleeperUserId: 's1', homeView: 'season' }, leagues: l, funMocks: [] }));
    sessionStorage.setItem('gs-nav', JSON.stringify(r));
  }, [leagues, route]);
  await page.reload({ waitUntil: 'domcontentloaded' });
};
const newPage = async () => { const p = await (await b.newContext({ viewport: { width: 1450, height: 1500 } })).newPage(); p.on('pageerror', (e) => errs.push(String(e))); return p; };
const openHubDirect = async (leagues) => {
  const page = await newPage();
  await seed(page, leagues, { route: 'teamHub', activeId: null, hubLeagueId: 'hub-lg-1' });
  await page.waitForSelector('[data-hubnav]', { timeout: 30000 }); await page.waitForTimeout(1800);
  return page;
};
const shownRank = async (page) => {
  await page.click('[data-hubgroup="league"]'); await page.waitForTimeout(700);
  return page.evaluate(() => Number((document.querySelector('[data-mypowerrank]') || {}).getAttribute?.('data-mypowerrank')) || null);
};
const price = async (page, give, get) => {
  await page.click('[data-hubgroup="moves"]'); await page.waitForTimeout(300);
  await page.click('[data-hubtabbtn="trades"]'); await page.waitForTimeout(600);
  const sels = await page.$$('select');
  await sels[sels.length - 1].selectOption({ label: T2 });
  await page.waitForTimeout(700);
  await page.click(`[data-tbplayer="${give}"]`); await page.waitForTimeout(250);
  await page.click(`[data-tbplayer="${get}"]`); await page.waitForTimeout(900);
  return page.evaluate(() => {
    const me = document.querySelector('[data-tbside="me"]');
    const d = me && me.querySelector('[data-tbdelta]');
    const pw = (document.querySelector('[data-tbpower]') || {}).getAttribute?.('data-tbpower') || null;
    const [from, to] = pw ? pw.split('->').map(Number) : [null, null];
    return { delta: d ? Number(d.getAttribute('data-tbdelta')) : null, from, to };
  });
};

console.log(`\nThe trade: ${GIVE.name} (${GIVE.pos}, mine) for ${GET.name} (${GET.pos}, ${T2})`);

/* ══ §1 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §1 one league: prediction = outcome, and the reverse trade mirrors it ==');
let base = null;
{
  await post('/stub/reset'); await post('/stub/std', { mode: 'on' });
  const p = await openHubDirect([L1]);
  const r0 = await shownRank(p);
  const fwd = await price(p, GIVE.name, GET.name);
  base = { r0, fwd };
  ok('1 · the calculator\'s starting rank is the rank the League tab shows', fwd.from === r0, `calc ${fwd.from} / table ${r0}`);
  ok('1a · (the fixture can fail) this trade is predicted to MOVE my rank', fwd.to !== fwd.from, `#${fwd.from} → #${fwd.to}`);
  await p.context().close();
  await post('/stub/hub-trade', { a: 1, b: 2, give: [GIVE.id], get: [GET.id] });
  const p2 = await openHubDirect([L1]);
  const r1 = await shownRank(p2);
  ok(`1b · ⭐⭐⭐⭐⭐ PREDICTION = OUTCOME: it said #${fwd.from} → #${fwd.to}; after the trade the table shows #${r1}`, r1 === fwd.to, `lineup ${fwd.delta > 0 ? '+' : ''}${fwd.delta}`);
  const rev = await price(p2, GET.name, GIVE.name);
  ok(`1c · ⭐⭐⭐⭐⭐ SYMMETRY: the reverse trade changes the lineup by exactly the opposite amount`, rev.delta != null && Math.abs(rev.delta + fwd.delta) <= 0.15, `forward ${fwd.delta} / reverse ${rev.delta}`);
  ok('1d · ⭐⭐⭐⭐ and predicts a return to the original rank', rev.from === r1 && rev.to === r0, `#${rev.from} → #${rev.to}, started at #${r0}`);
  await p2.context().close();
}

/* ══ §2 ═════════════════════════════════════════════════════════════════════════════════════════ */
console.log('\n== §2 the same trade, after the home page has loaded a SECOND league with a different lineup ==');
{
  await post('/stub/reset'); await post('/stub/std', { mode: 'on' });
  const page = await newPage();
  await seed(page, [L1, L2], { route: 'home', activeId: null, hubLeagueId: null });
  /* Let the home page build both leagues' Power column — the loop that builds a pool per league. */
  await page.waitForTimeout(16000);
  const d = page.getByText('Dismiss', { exact: false }).first(); if (await d.count()) await d.click({ force: true }).catch(() => {});
  const doors = await page.$$eval('[data-openseason]', (xs) => xs.map((x) => x.getAttribute('data-openseason')));
  ok('2 · both leagues are on the home page', doors.includes('Hub Fixture League') && doors.includes('Superflex 3WR League'), doors.join(' | '));
  await page.$eval('[data-openseason="Hub Fixture League"]', (el) => el.click());
  await page.waitForSelector('[data-hubnav]', { timeout: 30000 }); await page.waitForTimeout(2500);
  const r0 = await shownRank(page);
  const fwd = await price(page, GIVE.name, GET.name);
  ok('2b · ⭐⭐⭐⭐⭐ the League tab shows the same rank as with one league', r0 === base.r0, `${r0} vs ${base.r0}`);
  ok('2c · ⭐⭐⭐⭐⭐ the calculator gives the SAME lineup change as with one league', fwd.delta === base.fwd.delta, `${fwd.delta} vs ${base.fwd.delta}`);
  ok('2d · …and the same predicted rank', fwd.from === base.fwd.from && fwd.to === base.fwd.to, `#${fwd.from}→#${fwd.to} vs #${base.fwd.from}→#${base.fwd.to}`);
  await page.context().close();
}

ok('3 · nothing threw', errs.length === 0, errs.slice(0, 2).join(' || ').slice(0, 160));
await b.close();
console.log(`\n  ${pass} PASS  ${fail} FAIL`);
process.exit(fail ? 1 : 0);
