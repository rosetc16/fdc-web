/* A MINIMAL STAND-IN BACKEND — rebuilt b163.
 * ═══════════════════════════════════════════════════════════════════════════════════════════════════
 * ⚠⚠⚠⚠⚠ THIS IS A REPLACEMENT, NOT THE ORIGINAL. The sandbox container was reclaimed mid-session and
 *   took the whole test harness with it — the old hubstub served about twenty routes off rich recorded
 *   fixtures and is gone. This serves only what the ACTIVITY FEED needs, which is where three of the
 *   five b163 features live. Every other in-season screen is unverified in a browser this build, and
 *   saying so is part of the file.
 *
 * ⚠ THE FIXTURE IS BUILT TO BE ABLE TO FAIL. Straight from the lesson the old harness paid for over and
 *   over: a tidy fixture proves a renderer can print a string. This one carries the shapes that
 *   separate a working build from a plausible one —
 *     · a THREE-TEAM trade, which a give/get pair cannot render;
 *     · a claim that DID NOT LAND, which must never count as a move made;
 *     · a FAAB league and a waiver-PRIORITY league, so a bid must be absent rather than $0;
 *     · a manager who STREAMS CONSTANTLY AND HAS NEVER TRADED, so a raw move-count ranking of "open to
 *       a deal" ranks him first and is caught;
 *     · and, on the Yahoo side, a PENDING and a REJECTED trade — the two things Sleeper cannot express.
 * ══════════════════════════════════════════════════════════════════════════════════════════════════ */
import http from 'http';
import fs from 'fs';
import path from 'path';
/* 29be — the league-hub fixtures (see gen-hub-fixture.mjs). Read at request time so regenerating them does
   not need a stub restart. `stdMode` lets a suite switch season-to-date off to see the projections-only path. */
const HERE = path.dirname(new URL(import.meta.url).pathname);
const fx = (f) => { try { return JSON.parse(fs.readFileSync(path.join(HERE, f), 'utf8')); } catch { return null; } };
let stdMode = 'on';
let hubLive = null;
let yahooConfigured = false;
let latencyMs = 0;   // 29bf — POST /stub/latency {ms}: every /api/ answer waits this long, like a real backend

const PORT = Number(process.env.PORT || 5055);
const json = (res, code, body) => {
  res.writeHead(code, { 'content-type': 'application/json',
    'access-control-allow-origin': '*', 'access-control-allow-headers': '*',
    'access-control-allow-methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS', 'cache-control': 'no-store' });
  res.end(JSON.stringify(body));
};

let state = { leagues: [], funMocks: [], feedback: [] };
let sleeperAccounts = [{ platform: 'sleeper', id: 's1', username: 'trey' }];
let yahooFail = false;
let meMode = 'ok';                 // ok | hang | error — a cold Render dyno, on demand
const USER = { id: 'u1', email: 'trey.rose@pirates.com', paid: true, admin: true, rankSets: [] };
const acct = () => ({ linked: sleeperAccounts.length > 0, accounts: sleeperAccounts,
  sleeperUserId: sleeperAccounts[0] ? sleeperAccounts[0].id : null,
  sleeperUsername: sleeperAccounts[0] ? sleeperAccounts[0].username : null });

const TEAMS = [
  [1, 'Yinzer Bombers', 'trey'], [2, 'Steel City Sharks', 'mike_d'], [3, 'Allegheny Anchors', 'jo'],
  [4, 'North Shore Nailers', 'bpalmer'], [5, 'Shadyside Slingers', 'rjay'],
  [6, 'Bloomfield Bruisers', 'streamer'], [7, 'Squirrel Hill Squad', 'dk'],
];
const NAME = Object.fromEntries(TEAMS.map(([id, n]) => [id, n]));
const OWNER = Object.fromEntries(TEAMS.map(([id, , o]) => [id, o]));
const MY = 1;
const DAY = 86400000;
const at = (n) => Date.UTC(2026, 8, 19) - n * DAY;
const P = (sid, name, pos, team) => ({ sid, name, pos, team });
const POOL = [
  P('100003', 'Justin Jefferson', 'WR', 'MIN'), P('100011', 'Ashton Jeanty', 'RB', 'LV'),
  P('100021', 'Bijan Robinson', 'RB', 'ATL'), P('100030', 'Bucky Irving', 'RB', 'TB'),
  P('100033', 'Courtland Sutton', 'WR', 'DEN'), P('100036', 'Quinshon Judkins', 'RB', 'CLE'),
  P('100041', 'Adonai Mitchell', 'WR', 'IND'), P('100044', 'Khalil Shakir', 'WR', 'BUF'),
  P('100047', 'Travis Hunter', 'WR', 'JAX'), P('100048', 'Jameson Williams', 'WR', 'DET'),
  P('100052', 'Tyler Allgeier', 'RB', 'ATL'), P('100053', 'Blake Corum', 'RB', 'LAR'),
  P('100054', 'Adam Thielen', 'WR', 'CAR'), P('100055', 'Dalton Kincaid', 'TE', 'BUF'),
  P('100056', 'Jared Goff', 'QB', 'DET'), P('100057', 'Bo Nix', 'QB', 'DEN'),
];
const side = (rosterId, got, gave, extra = {}) => ({
  rosterId, teamName: NAME[rosterId] || `Team ${rosterId}`, ownerName: OWNER[rosterId] || null,
  isMe: rosterId === MY, got, gave, picks: [], faabIn: 0, faabOut: 0, ...extra });

const trendsOf = (items) => {
  const counts = new Map();
  items.filter((r) => r.status === 'complete').forEach((r) => r.teams.forEach((t) => {
    if (!counts.has(t.rosterId)) counts.set(t.rosterId, { rosterId: t.rosterId, teamName: t.teamName,
      trades: 0, waivers: 0, freeAgents: 0, faabSpent: 0, failedClaims: 0 });
    const c = counts.get(t.rosterId);
    c[r.type === 'trade' ? 'trades' : r.type === 'waiver' ? 'waivers' : 'freeAgents'] += 1;
    if (r.type === 'waiver' && r.bid && t.got.length) c.faabSpent += r.bid;
  }));
  items.filter((r) => r.status === 'failed').forEach((r) => r.teams.forEach((t) => {
    if (!counts.has(t.rosterId)) counts.set(t.rosterId, { rosterId: t.rosterId, teamName: t.teamName,
      trades: 0, waivers: 0, freeAgents: 0, faabSpent: 0, failedClaims: 0 });
    counts.get(t.rosterId).failedClaims += 1;
  }));
  const rows = [...counts.values()].sort((a, b) =>
    (b.trades + b.waivers + b.freeAgents) - (a.trades + a.waivers + a.freeAgents));
  const mine = rows.find((r) => r.rosterId === MY) || null;
  return { rows, mine,
    totals: {
      trades: items.filter((r) => r.status === 'complete' && r.type === 'trade').length,
      waivers: items.filter((r) => r.status === 'complete' && r.type === 'waiver').length,
      freeAgents: items.filter((r) => r.status === 'complete' && r.type === 'free_agent').length,
      failed: items.filter((r) => r.status === 'failed').length,
      faabSpent: items.filter((r) => r.status === 'complete' && r.type === 'waiver' && r.bid)
        .reduce((a, r) => a + r.bid, 0) },
    myRank: mine && rows.length > 1 ? rows.indexOf(mine) + 1 : null,
    teams: rows.length };
};

/* 29bh — the hub fixture's own activity: trades between REAL fixture rosters, so the Recent tab can grade
   them. The rosters already reflect each trade (a team holds what it got), as Sleeper's would. */
const hubTxLeague = (leagueId) => {
  const hub = hubLive || fx('fixture-hub.json'), pack = fx('fixture-pack.json');
  if (!hub || !pack) return sleeperLeague(leagueId, false);
  const by = new Map(pack.players.map((p) => [String(p.id), p]));
  const P = (sid) => { const p = by.get(String(sid)) || {}; return { sid: String(sid), name: p.name || String(sid), pos: p.pos || '', team: p.team || '' }; };
  const team = (rid) => hub.teams.find((t) => t.rosterId === rid);
  const best = (rid, pos, n = 0) => team(rid).players.map((id) => by.get(String(id))).filter((p) => p && p.pos === pos).sort((a, b) => a.adp - b.adp)[n];
  const S = (rid, got, gave) => ({ rosterId: rid, teamName: team(rid).teamName, ownerName: team(rid).ownerName, isMe: rid === hub.myRosterId,
    got: got.map((p) => P(p.id)), gave: gave.map((p) => P(p.id)), picks: [], faabIn: 0, faabOut: 0 });
  const me = hub.myRosterId;
  const items = [
    /* I got my RB2 from team 3 for (what is now) their WR2. */
    { id: `${leagueId}-h1`, type: 'trade', status: 'complete', week: 3, at: at(1), mine: true, leagueId, leagueName: hub.leagueName,
      teams: [S(me, [best(me, 'RB', 1)], [best(3, 'WR', 1)]), S(3, [best(3, 'WR', 1)], [best(me, 'RB', 1)])], bid: null, note: null },
    /* Two other managers. */
    { id: `${leagueId}-h2`, type: 'trade', status: 'complete', week: 2, at: at(5), mine: false, leagueId, leagueName: hub.leagueName,
      teams: [S(5, [best(5, 'QB', 0)], [best(6, 'TE', 0)]), S(6, [best(6, 'TE', 0)], [best(5, 'QB', 0)])], bid: null, note: null },
    /* Three ways — not graded. */
    { id: `${leagueId}-h3`, type: 'trade', status: 'complete', week: 2, at: at(6), mine: false, leagueId, leagueName: hub.leagueName,
      teams: [S(7, [best(7, 'WR', 2)], [best(8, 'WR', 2)]), S(8, [best(8, 'WR', 2)], [best(9, 'WR', 2)]), S(9, [best(9, 'WR', 2)], [best(7, 'WR', 2)])], bid: null, note: null },
  ];
  return { leagueId, leagueName: hub.leagueName, myRosterId: me, ownerResolved: true, faab: false, budget: null,
    items, trends: trendsOf(items), platform: 'sleeper' };
};

const sleeperLeague = (leagueId, faab) => {
  const items = [
    { id: `${leagueId}-t1`, type: 'trade', status: 'complete', week: 3, at: at(1), mine: true,
      leagueId, leagueName: leagueId === 'stub-league-1' ? 'Pirates Dynasty Keeper' : `League ${leagueId}`,
      teams: [side(MY, [POOL[0]], [POOL[1]], { picks: [{ season: '2027', round: 2, from: 4, label: '2027 2nd rd' }] }),
        side(4, [POOL[1]], [POOL[0]])], bid: null, note: null },
    /* THREE SIDES — the reason `teams` is a list and not a pair. */
    { id: `${leagueId}-t2`, type: 'trade', status: 'complete', week: 2, at: at(4), mine: false,
      leagueId, leagueName: leagueId === 'stub-league-1' ? 'Pirates Dynasty Keeper' : `League ${leagueId}`,
      teams: [side(2, [POOL[2]], [POOL[3]]), side(5, [POOL[3]], [POOL[4]]), side(7, [POOL[4]], [POOL[2]])],
      bid: null, note: null },
    { id: `${leagueId}-w1`, type: 'waiver', status: 'complete', week: 3, at: at(2), mine: true,
      leagueId, leagueName: leagueId === 'stub-league-1' ? 'Pirates Dynasty Keeper' : `League ${leagueId}`,
      teams: [side(MY, [POOL[5]], [POOL[6]])], bid: faab ? 27 : null, note: null },
    /* A CLAIM I LOST — never a move made. */
    { id: `${leagueId}-w2`, type: 'waiver', status: 'failed', week: 3, at: at(2), mine: true,
      leagueId, leagueName: leagueId === 'stub-league-1' ? 'Pirates Dynasty Keeper' : `League ${leagueId}`,
      teams: [side(MY, [POOL[7]], [])], bid: faab ? 9 : null,
      note: faab ? 'Outbid — another claim was higher' : 'Another team had higher waiver priority' },
    /* THE STREAMER: five adds, two claims, never traded. A raw move-count ranking puts him first. */
    ...[8, 9, 10, 11, 12].map((n, i) => ({
      id: `${leagueId}-f${i}`, type: 'free_agent', status: 'complete', week: 3 - (i % 2), at: at(5 + i), mine: false,
      leagueId, leagueName: leagueId === 'stub-league-1' ? 'Pirates Dynasty Keeper' : `League ${leagueId}`,
      teams: [side(6, [POOL[n]], [])], bid: null, note: null })),
    ...[13, 14].map((n, i) => ({
      id: `${leagueId}-w3${i}`, type: 'waiver', status: 'complete', week: 3, at: at(10 + i), mine: false,
      leagueId, leagueName: leagueId === 'stub-league-1' ? 'Pirates Dynasty Keeper' : `League ${leagueId}`,
      teams: [side(6, [POOL[n]], [])], bid: faab ? 2 : null, note: null })),
  ];
  return { leagueId, leagueName: leagueId === 'stub-league-1' ? 'Pirates Dynasty Keeper' : `League ${leagueId}`,
    myRosterId: MY, ownerResolved: true, faab, budget: faab ? 100 : null, items, trends: trendsOf(items) };
};

const yahooLeague = (key) => {
  if (yahooFail) return { leagueId: key, leagueName: null, items: [], trends: null,
    platform: 'yahoo', error: 'Yahoo session expired.' };
  const items = [
    { id: `${key}.tr.11`, type: 'waiver', status: 'complete', week: 3, at: at(1), mine: true,
      teams: [side(MY, [POOL[4]], [POOL[6]])], bid: 17, note: null, platform: 'yahoo' },
    { id: `${key}.tr.12`, type: 'free_agent', status: 'complete', week: 3, at: at(2), mine: false,
      teams: [side(4, [POOL[5]], [])], bid: null, note: null, platform: 'yahoo' },
    { id: `${key}.tr.13`, type: 'trade', status: 'complete', week: 2, at: at(3), mine: true,
      teams: [side(MY, [POOL[0]], [POOL[1]]), side(5, [POOL[1]], [POOL[0]])], bid: null, note: null, platform: 'yahoo' },
    /* THE TWO SLEEPER CANNOT EXPRESS. */
    { id: `${key}.tr.14`, type: 'trade', status: 'pending', week: 3, at: at(0), mine: true,
      teams: [side(MY, [POOL[2]], [POOL[3]]), side(7, [POOL[3]], [POOL[2]])],
      bid: null, note: 'Waiting on a decision', platform: 'yahoo' },
    { id: `${key}.tr.15`, type: 'trade', status: 'failed', week: 2, at: at(4), mine: false,
      teams: [side(2, [POOL[8]], [POOL[9]]), side(3, [POOL[9]], [POOL[8]])],
      bid: null, note: "Didn't go through", platform: 'yahoo' },
  ];
  const settled = items.filter((x) => x.status !== 'pending');
  return { leagueId: key, leagueName: `Yahoo ${key}`, myRosterId: MY, ownerResolved: true,
    faab: items.some((x) => Number.isFinite(x.bid) && x.bid > 0), budget: null,
    items, trends: trendsOf(settled), platform: 'yahoo' };
};

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const p = url.pathname;
  if (req.method === 'OPTIONS') return json(res, 204, {});
  let body = {};
  if (req.method !== 'GET') {
    body = await new Promise((r) => { let b = ''; req.on('data', (c) => { b += c; }); req.on('end', () => { try { r(JSON.parse(b || '{}')); } catch { r({}); } }); });
  }

  if (latencyMs && p.startsWith('/api/') && p !== '/api/health') await new Promise((r) => setTimeout(r, latencyMs));
  if (p === '/api/health') return json(res, 200, { ok: true });
  if (p === '/stub/latency' && req.method === 'POST') { latencyMs = Number(body.ms) || 0; return json(res, 200, { latencyMs }); }

  /* ⚠ /me AND /signin MUST AGREE ABOUT THE LINK. The old stub's sign-in returned a hard-coded user with
     `sleeperUsername: 'trey'` forever, so a suite for "my Sleeper account did not come across to my
     phone" could not fail no matter how broken the app was. Both read the same place here. */
  if (p === '/api/auth/me') {
    if (meMode === 'hang') return;                       // never answers — a dyno waking up
    if (meMode === 'error') return json(res, 500, { error: 'boom' });
    return json(res, 200, { user: { ...USER, sleeperUserId: acct().sleeperUserId, sleeperUsername: acct().sleeperUsername } });
  }
  if (p === '/api/auth/signin' || p === '/api/auth/signup') {
    return json(res, 200, { token: 't', user: { ...USER, email: body.email || USER.email,
      sleeperUserId: acct().sleeperUserId, sleeperUsername: acct().sleeperUsername } });
  }
  if (p === '/api/state' && req.method === 'PUT') { state = body.state || state; return json(res, 200, { ok: true }); }
  if (p === '/api/state') return json(res, 200, { state, updatedAt: '2026-09-19T00:00:00Z' });
  if (p === '/api/connect/sleeper/account') return json(res, 200, acct());
  if (p === '/api/connect/sleeper/my-leagues') return json(res, 200, { accounts: sleeperAccounts, leagues: [] });

  if (p === '/api/connect/sleeper/transactions') {
    const ids = String(url.searchParams.get('league_ids') || '').split(',').map((x) => x.trim()).filter(Boolean);
    if (!ids.length) return json(res, 400, { error: 'league_ids required' });
    /* ⚠ ONE LEAGUE RUNS FAAB AND THE OTHER RUNS PRIORITY, so one screen carries both branches: a bid
       that is a number, and a league where a bid must be ABSENT rather than $0. */
    return json(res, 200, { season: '2026', week: 3, weeks: [1, 2, 3],
      leagues: ids.map((id, i) => (String(id).startsWith('hub-lg') ? hubTxLeague(id) : sleeperLeague(id, i === 0))),
      pendingSupported: false,
      note: 'Sleeper publishes a transaction only once it has gone through, so pending offers cannot be read.' });
  }
  if (p === '/api/connect/yahoo/transactions') {
    const keys = String(url.searchParams.get('league_keys') || '').split(',').map((x) => x.trim()).filter(Boolean);
    if (!keys.length) return json(res, 400, { error: 'league_keys required' });
    return json(res, 200, { season: '2026', leagues: keys.map(yahooLeague), pendingSupported: true,
      note: 'Yahoo publishes trades that are still waiting on a decision, and ones that were turned down.',
      attribution: 'Fantasy data provided by Yahoo Fantasy.' });
  }

  /* Test knobs. */
  if (p === '/stub/sleeper-account' && req.method === 'POST') {
    sleeperAccounts = Array.isArray(body.accounts)
      ? body.accounts.map((a) => (typeof a === 'string' ? { platform: 'sleeper', id: `id-${a}`, username: a } : a))
      : (body.sleeperUsername ? [{ platform: 'sleeper', id: body.sleeperUserId || 's1', username: body.sleeperUsername }] : []);
    return json(res, 200, acct());
  }
  if (p === '/stub/me-mode' && req.method === 'POST') { meMode = body.mode || 'ok'; return json(res, 200, { meMode }); }
  if (p === '/stub/yahoo' && req.method === 'POST') { yahooFail = body.txFail === true; if (body.configured != null) yahooConfigured = !!body.configured; return json(res, 200, { yahooFail, yahooConfigured }); }
  /* 29bj — Yahoo is not approved yet in production, so the stub's default is NOT configured. */
  if (p === '/api/connect/yahoo/status') return json(res, 200, { configured: yahooConfigured, linked: false });
  if (p === '/stub/reset' && req.method === 'POST') {
    state = { leagues: [], funMocks: [], feedback: [] };
    sleeperAccounts = [{ platform: 'sleeper', id: 's1', username: 'trey' }];
    yahooFail = false; yahooConfigured = false; meMode = 'ok'; stdMode = 'on'; hubLive = null; latencyMs = 0;
    return json(res, 200, { ok: true });
  }

  /* 29bf — the home strip's live board. A quiet week (nothing on, nothing final) is enough for the suite:
     what is under test is the WAIT before it answers, not the table it draws afterwards. */
  if (p === '/api/connect/sleeper/live') return json(res, 200, { season: '2026', week: 3,
    weekState: { known: true, anyLive: false, anyDone: false, games: 0, nextKickoff: null }, leagues: [], rooting: [], totals: {} });
  /* ---- 29be: the in-season hub ---- */
  if (p === '/api/player-pack') { const x = fx('fixture-pack.json'); return x ? json(res, 200, x) : json(res, 404, { error: 'run gen-hub-fixture.mjs' }); }
  /* 29bf — the hub is MUTABLE so a suite can make a trade the way Trey did in Sleeper and then reload,
     and a SECOND league with a different lineup shape exists so the app has to handle two leagues' slot
     rules at once (the global-SPEC bug). */
  if (p === '/api/connect/sleeper/team-hub') {
    if (!hubLive) hubLive = fx('fixture-hub.json');
    if (!hubLive) return json(res, 404, { error: 'run gen-hub-fixture.mjs' });
    const lid = url.searchParams.get('league_id') || '';
    /* 29bh — a DYNASTY copy of the fixture with future picks, one traded each way. */
    if (lid === 'hub-lg-dyn') {
      const ids = hubLive.teams.map((t) => t.rosterId);
      const picks = [];
      ['2027', '2028', '2029'].forEach((season) => { for (let round = 1; round <= 4; round++) ids.forEach((rid) => picks.push({ season, round, originalRosterId: rid, ownerRosterId: rid })); });
      const mv = (season, round, orig, owner) => { const p = picks.find((x) => x.season === season && x.round === round && x.originalRosterId === orig); if (p) p.ownerRosterId = owner; };
      mv('2027', 1, 12, hubLive.myRosterId);      // I hold team 12's 2027 1st
      mv('2028', 2, hubLive.myRosterId, 3);       // team 3 holds my 2028 2nd
      return json(res, 200, { ...hubLive, leagueName: 'Dynasty Fixture League', cfg: { ...hubLive.cfg, type: 'dynasty' },
        futurePicks: { enabled: true, seasons: ['2027', '2028', '2029'], rounds: 4, picks } });
    }
    if (lid === 'hub-lg-2') {
      return json(res, 200, { ...hubLive, leagueName: 'Superflex 3WR League',
        cfg: { ...hubLive.cfg, sf: true, start: { QB: 1, RB: 1, WR: 3, TE: 1, FLEX: 2, SUPER: 1, K: 0, DST: 0 } } });
    }
    return json(res, 200, hubLive);
  }
  if (p === '/stub/hub-trade' && req.method === 'POST') {
    if (!hubLive) hubLive = fx('fixture-hub.json');
    const A = hubLive.teams.find((t) => t.rosterId === body.a), B = hubLive.teams.find((t) => t.rosterId === body.b);
    const give = (body.give || []).map(String), get = (body.get || []).map(String);
    A.players = A.players.filter((x) => !give.includes(x)).concat(get);
    B.players = B.players.filter((x) => !get.includes(x)).concat(give);
    /* Starters follow the players: a traded starter's slot goes to whoever arrives, as Sleeper would. */
    A.starters = A.starters.map((x) => (give.includes(x) ? (get[give.indexOf(x)] || '0') : x));
    B.starters = B.starters.map((x) => (get.includes(x) ? (give[get.indexOf(x)] || '0') : x));
    return json(res, 200, { ok: true, a: A.players.length, b: B.players.length });
  }
  if (p === '/api/connect/season-to-date') {
    const x = fx('fixture-std.json');
    if (stdMode === 'warming' || !x) return json(res, 200, { season: 2026, week: 9, throughWeek: 8, players: {}, warming: true });
    /* 29bh — an EARLIER week (the Recent tab rewinding to a trade) gets the table as it stood then: same
       rates, fewer games — the fixture only has season totals, so the past is those totals scaled down. */
    const wq = Number(url.searchParams.get('week'));
    if (Number.isFinite(wq) && wq >= 1 && wq - 1 < x.throughWeek) {
      const tw = wq - 1;
      if (tw < 1) return json(res, 200, { season: x.season, week: wq, throughWeek: 0, players: {} });
      const f = tw / x.throughWeek, players = {};
      Object.entries(x.players).forEach(([id, r]) => {
        const gp = Math.round((r.gp || 0) * f); if (gp < 1) return;
        const k = gp / (r.gp || 1), st = {};
        Object.entries(r.s || {}).forEach(([a, v]) => { st[a] = Math.round(v * k * 10) / 10; });
        players[id] = { ...r, gp, s: st };
      });
      return json(res, 200, { season: x.season, week: wq, throughWeek: tw, players });
    }
    return json(res, 200, { season: x.season, week: x.week, throughWeek: x.throughWeek, players: x.players });
  }
  if (p === '/stub/std' && req.method === 'POST') { stdMode = body.mode || 'on'; return json(res, 200, { stdMode }); }

  /* Everything else this stub does not implement answers 404 rather than pretending. */
  return json(res, 404, { error: `stub has no route for ${p}` });
}).listen(PORT, () => console.log(`minimal stub on ${PORT}`));
