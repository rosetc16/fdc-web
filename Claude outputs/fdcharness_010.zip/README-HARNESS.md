# The Fantasy Draft Compass test harness

This is the thing that *verifies* the two shipped repos. It is not part of either of them, which is why
it needs its own zip — and why it was lost when the sandbox container was reclaimed on 2026-09-20,
taking about 1,100 accumulated checks with it. **Keep this zip.** From b163 on it ships with every build.

## What's here

| file | what it is |
|---|---|
| `hubstub/server.mjs` | a stand-in backend on :5055 — no database, no network, fixtures in code |
| `rig.sh` | starts the stub and two preview servers, and **verifies** each port serves the folder it claims |
| `plan29ba.mjs` | the b163 suite: 25 browser checks over that build's five features |
| `probe/plan29bb-cascade.mjs` | **29bb — 34 checks against the app's REAL scorer, in node, no browser** |
| `probe/plan29bb-team.mjs` | **29bc — 30 checks on `injuryImpact` / `hubWeekPts`: what an injury does to ONE team** |
| `probe/package.json` | `{"type":"module"}` plus a symlink to the web app's `node_modules` |
| `package.json` | pins playwright for the browser suites |

## Running it

```sh
# --- the fast half: no browser, no servers, ~3 seconds ---
cd web/fdc-web
node src/injuries.js --test                             # 44 unit checks on the injury model
for t in icons-check css-check screens-check hooks-check icons-scan; do node tools/$t.mjs; done
npx vite build -c vite.lib.config.js                    # builds probe/lib — App.jsx, importable by node
cd ../../probe && ln -sfn ../web/fdc-web/node_modules node_modules
node plan29bb-cascade.mjs                               # 34 checks against the real leaguePower
node plan29bb-team.mjs                                  # 30 checks: the backup inherits the slot, phased cost

# --- the browser half ---
cd ../web/fdc-web && npm install && npm run build:test  # builds dist (no backend) and distb (-> :5055)
cd ../.. && ./rig.sh                                    # must print "rig ready"
node plan29ba.mjs
```

## ⭐⭐⭐⭐⭐ NEW IN 29bb: node can now execute the app's scoring code

`vite.lib.config.js` (in `web/fdc-web`) builds `src/App.jsx` as an ES library with React left external,
so a plain node script can `import { leaguePower, hubPoolFor, injCtxFor } from "./lib/app-lib.js"` and
assert on real output. **This is the single most useful thing in this harness.** Until 29bb, every number
the app computes — power ratings, positional quality, trade values — was reachable only by starting a
browser, which is exactly why a wrong power rating survived 29w *and* 29y: there was no cheap way to ask
it a question. A check that used to need a rig, two preview servers and a stub now takes 1.1 seconds.

It is a test artefact and ships nothing: production still builds from `vite.config.js`.

⚠ Real Sleeper ids reach the pool only through `applyLivePack`, which needs the backend's player pack,
and this sandbox cannot reach the backend. `plan29bb-cascade.mjs` therefore stamps its own ids onto the
real pool entries — real projections, real VBD, real dynasty values, a key the fixture chose. Its §0
asserts the fixture can express the fault *before* anything else runs, which caught exactly this on the
suite's first execution rather than letting it pass against twelve zero-point rosters.

⚠ **Never rebuild `distb` while a suite is running.** `vite preview` serves off disk, so a rebuild swaps
the bundle under the browser mid-run: the preview server 500s and the suite dies with
`ERR_HTTP_RESPONSE_CODE_FAILURE`, which reads exactly like a product crash and is not one. This has cost
a full run twice.

## What this harness does NOT cover yet

The original had ~1,100 checks across `sim/*.js` (pure-JS model tests), `plan29cd`–`plan29cs` (browser
suites), a theme sweep over 13 screens and a legacy regression sweep. All of it is gone. What survived,
because it lived inside the shipped repos, is the backend's 287 checks (`api/fdc-backend && npm test`)
and the five build gates (`web/fdc-web/tools/*.mjs`).

**Not verified in a browser at the moment:** the in-season hub (matchup, rosters, league, free agents),
Game Day, the weekly review, the trade tab's calculator / league read / deals / positional market
sections, light-vs-dark across every screen, and the whole draft-room feature set beyond "it opens and
the board fills". Rebuilding those is the next job; the notes in memory record what each suite covered
and which trap it was written for.

**The stub still has no `team-hub` route**, which is why none of the above can be reached. That is the
single highest-value thing to add next: a twelve-team hub fixture would unlock the hub, the trade tab
and the Injuries tab's DOM in one go.

### 29bb — the Injuries feature, specifically

*Verified (node, 70 checks):* the injury arithmetic including the VBD-surplus transform and its negative
case; the weeks-remaining window; the expiry clock; dynasty damping; that a saved injury reaches
`leaguePower` and actually reorders the table; that no untouched roster moves; that nobody gains value
from an injury; that the shared format-cached pool is never mutated. Each of these was falsified — the
suite was deliberately broken six ways and went red each time, and one falsification (`wk = 1`, an
out-for-the-year player still projecting a full game) **passed 31/31 and exposed a real hole**, which is
now covered.

*NOT verified — needs a browser:* the Injuries tab's own DOM (search, the status buttons, the weeks
stepper, save/edit/clear), the before/after arrows, the count badge on the tab, the banner on the League
tab, the `OUT` chips on the lineup/roster/trade-calculator rows, and cross-device sync of the `injuries`
key through all five merge sites. The merge sites were read and edited by hand; they are the likeliest
place for a defect in this build.

### 29bc — "what does it do to my team", and the averaging bug it exposed

`plan29bb-team.mjs` runs the exact functions the Injuries tab's team block runs. Its first run went 23/27
and the four reds were two suite bugs and two real product bugs:
- *suite:* slots are named `RB1`/`RB2`, not `RB`; and the fixture's backup QB outscored a 70% star, so the
  optimizer was right to bench him. Both fixed in the suite.
- *product:* with no backup the solver leaves an out-for-the-year QB in his slot at 0.0, and the tab
  called that "still your best option at reduced value". Fixed (`selfAtZero`).
- *product, the important one:* "out 3 weeks" cost exactly what "out for the season" cost. Averaged over
  the window, a two-thirds star sits below his backup and a single season lineup benches him for all nine
  weeks. `phasedLineupValue` (in `src/injuries.js`) now cuts the window at every return date and solves a
  lineup per phase. It is injected everywhere a season roster is valued — the trade finder, the league
  read, partner costs, the calculator and the playoff sim — and is exactly `lineupValue` when nobody is
  marked.

Tracing the suite's rosters also found a double discount in `resolve`'s no-slate fallback (a limited man at
0.7 × 0.7 = 49%). That arithmetic is now `hubWeekPts`, exported and pinned by §5.

Falsified four ways (averaged mean, `selfAtZero` off, the double discount, a naive "his own points" cost);
all four go red.

*Still not verified in a browser:* the team block's DOM, the "Price it" buttons, and whether the phased
finder produces sensible offers on a real league. **The power table (`leaguePower` / `rosterScore`) still
uses the averaged values on purpose** — it is a roster-strength index, not a points forecast.

## 29be — the league hub is finally testable in a browser

`hubstub/gen-hub-fixture.mjs` builds three fixtures from the app's OWN built-in board (through the node
library build): a player pack with stable ids, a 12-team Sleeper-shaped team-hub payload (week 9 of 14,
snake-drafted by ADP) and season-to-date actuals with a named HOT and COLD player on my team. The stub
serves them at `/api/player-pack`, `/api/connect/sleeper/team-hub` and `/api/connect/season-to-date`
(`POST /stub/std {mode:'warming'}` switches actuals off). `verify.sh` regenerates them every run.

`plan29be.mjs` (47 checks) is the first browser suite to open the in-season hub since the container loss:
the grouped menu and its doorways, Recent activity moved out of Trades, form-blended values in the trade
calculator (Chase 330 → 443 at 1.6×, exactly the model's 1.34×), and the Injuries tab end to end — marked
through the UI, persisted to the server, **restored on a fresh device**, cleared as a tombstone. Falsified:
switching the blend off in the app turns §3 red (4 FAIL).

**Run `bash verify.sh` before packaging. All of it.** Current totals: 6 build gates, 44 + 20 model units,
34 + 30 + 14 node suites, 301 backend, 25 + 47 browser.

## 29bf — the trade calculator agrees with reality, and the home page says "loading"

Three new suites, all in `verify.sh`:

| file | checks | what it pins |
|---|---|---|
| `plan29bf.mjs` | 10 (browser) | the calculator's predicted power rank = the rank the League tab shows after the trade is actually made (`POST /stub/hub-trade` swaps players, then reload); the reverse trade is the exact negative; a second league loaded on the home page first changes nothing |
| `probe/plan29bf-grade.mjs` | 14 (node) | the trade grade (A+…F, per-week points) and the call (Make this offer / expect a no / small upgrade / not worth it / don't) on hand-computable trades; forward and reverse grade as mirror images |
| `plan29bf-home.mjs` | 11 (browser) | with every /api/ answer slowed to 2.5s: a "Loading your leagues…" block instead of the 0-leagues onboarding on a fresh device, a skeleton in the This-week slot on a returning one, and the onboarding still arriving for a real new account |

New stub knobs: `POST /stub/latency {ms}` (delays every /api/ except health; reset clears it),
`POST /stub/hub-trade {a,b,give,get}`, league `hub-lg-2` (superflex 3WR shape), and a quiet-week
`/api/connect/sleeper/live`. Falsified: with the loading states switched off, plan29bf-home goes 5 FAIL.

## 29bg — a grade on every trade idea

`plan29bg.mjs` (13 browser checks, in `verify.sh`): every Deals card carries the calculator's grade and call,
the cards run best-first by grade, and for the top three the card's letter, call AND lineup gain equal what
the calculator shows after "Price this deal". Long shots, the League table's ideas and the Market pathways
carry the pill too. ⭐ Falsified: with the old `tradeKey` (my roster only) the gain check goes 3 FAIL —
card +27 vs calculator 90 — because the trade lists were cached before this season's actual results
arrived and never recomputed.

## 29bh — Trey's four trade notes (web 29bh + backend 166)

| file | checks | what it pins |
|---|---|---|
| `probe/plan29bh-dst.mjs` | 3 (node) | ⭐ his exact case rebuilt: a defense 2 pts over the streaming line vs a star QB. The REAL `tradeBoard` never offers it and no idea carries a K/DEF. Falsified: with `tradeable` off and the old raw-points `tierShare` fallback → 2 FAIL (the pair is offered). The browser fixture cannot reproduce it (its defenses sit below replacement), which is why this is a node probe. |
| `probe/plan29bf-grade.mjs` | 18 (node) | + "they won't accept" call for a one-way deal, Eagles-for-Allen never "offer it", and the dynasty window: the same youth-for-vet trade grades A+ for a rebuilder and C− for a contender |
| `plan29bh.mjs` | 20 (browser) | no K/DEF in Deals / League read; the calculator's Ideas (graded, fair on value, Load grades the same; a backup QB gets "worth no more than the wire"); Recent activity grades both sides of two-team trades on results rewound to the trade week, three-way trades explain themselves; dynasty future picks (traded picks under their original team's name, value decays down the draft and years out, the #1 team's 1st is the cheapest, a pick moves value but never the lineup, the grade names its window) |
| backend `scripts/futurepicks.test.js` | 7 | `lib/futurePicks.js`: Sleeper's traded_picks laid over the default ownership, keyed by ORIGINAL owner |

Stub: `hub-lg-dyn` (dynasty copy with futurePicks), `/sleeper/transactions` for `hub-lg*` uses real fixture rosters
(two 2-team trades + a 3-way), `/season-to-date?week=N` below the fixture week returns the table as it stood then.

## 29bi — ideas quality, position ideas, team outlook, Game Day popup (web only; backend 166 current)

`plan29bi.mjs` (13 browser): Ideas never leave me short of starters at a position, never pad (a pair only when
neither man alone is fair, checked by pricing each single in the calculator), never a D/F for me unless the list
says every fair price costs my lineup; the Positional market says its chips are clickable and a click fills in
graded offers that Load into the calculator unchanged; the Deals card's team hover shows both rooms by position
(deal positions first, mine AFTER the deal); My Team > Game Day opens over the hub, Escape closes it.
Falsified: padding + loser rules off → 1b, 1c FAIL. ⚠ 1a (the two-QB offer) cannot be provoked on this fixture;
the rule is `leavesHole` in `buildIdeas`. plan29be §6 changed on purpose (Game Day is a popup now; its
"Open full page" still leaves the hub). `probe/plan29bf-grade.mjs` 21: + calibration (a 15-point give-back that
adds talent is not a D; a deal that fixes both rosters grades A/B for BOTH sides).

## 29bj — Yahoo greyed until Yahoo approves (web only)

`plan29bj.mjs` (8 browser): with `/api/connect/yahoo/status` answering `configured: false` (the stub default now,
matching production) the Yahoo tile in the connect picker is disabled with a SOON chip and the "we're working on the
connection" note; `POST /stub/yahoo {configured:true}` and the same tile is live with no rebuild.
